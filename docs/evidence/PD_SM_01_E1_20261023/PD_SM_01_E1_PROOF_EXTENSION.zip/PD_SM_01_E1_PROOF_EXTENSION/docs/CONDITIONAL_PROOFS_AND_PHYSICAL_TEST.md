# Conditional proofs and the physical-observation boundary

## F1 — Complete finite artifact-state comparison

The exact domain is declared in `PROOF_CONTRACT.md`: nine binary link switches and four binary evidence-admission choices, hence 2^9 × 2^4 = 8192 distinct inputs. All records outside those switches are fixed. Inputs that violate the desired invariant remain in the domain; they are not filtered out before checking. The evaluator is the unchanged E0 `independent_reference.py`, whose digest is recorded.

Let b0,...,b8 denote the switch bits in the declared order. Independently of the evaluator's code, the typed link condition in this profile is

    b0 = b3 = b4 = b7 = b8 = 0  AND  b1 = b5 = b6.

The tension selector b2 does not by itself invalidate the internal equalities: it changes which record must supply the evidence. Source-origin consistency remains a separate condition. All missing-source subsets have unresolved source justification; only the exact original source-derived carrier with all four admitted sources receives the original protected-subject proof. The exhaustive transcript contains every (assignment,evidence_mask) pair exactly once and records both the independently specified answer and the evaluator result.

**Obtained:** no discrepancies on all 8192 inputs. This is a finite exhaustive implementation check, not an unchecked extrapolation from eight examples and not a proof-assistant kernel certification. The quantified domain is explicit; richer value types, arbitrary size, alternative semantic definitions and real-system completeness are outside it.

## F2 — Grounded closure without a time premise

There are three propositions; the rule universe has six non-self unary implications and three rules requiring the other two propositions together. There are 512 rule subsets and 8 base subsets, hence 4096 systems. Every withdrawn sub-base is also checked (13824 comparisons).

For any such positive finite rule system, let L be the intersection of all rule-closed supersets of accepted base B. The family is nonempty because the whole proposition universe is closed. The intersection is itself closed: whenever all premises belong to the intersection, they belong to each member of the family, so the conclusion belongs to each member too. Therefore L is the least closed superset.

Starting from B and adding conclusions whose premises are present produces only elements of every closed superset (induction on derivation depth). Finiteness makes the process stabilize; the stable result is closed and thus equals L. This is a proof of the algorithmic closure characterization. Its derivation depth is not a mechanical time coordinate. A base-free p=>q=>p cycle supplies no grounded proof. Withdrawing the last external base requires the new least closure, not the previous mutually closed result.

**Obtained:** the implementation of bottom-up closure agrees with a separately computed intersection of every closed superset in all 4096 systems and 13824 withdrawal comparisons. This is a theorem about the selected proof language, not a physical law that creates relations.

## M — Conditional monitored-effect invariant

The selected MON-1 run uses a real scratch file, a broker in the controlling process, a separate monitor process and a restricted worker/delegate. It re-evaluates the actual E0 envelopes with the unchanged evaluator and binds the request to the input bytes, selected subject and assessment. The broker's source-admission Boolean is not accepted from the worker.

Assumptions:

1. The Linux kernel implements the installed seccomp filter; no kernel compromise or external privileged writer exists in scope.
2. The trusted coordinator/broker/monitor execute the recorded source. The worker starts after the descriptor-minimization and default-deny filter are applied. This is a single-threaded supervisor; only explicitly named pipe descriptors may be written by the worker. Forked descendants inherit the filter.
3. The only admitted sink-writing path is the broker. Its local fixture request is not a PULSEmech production release authorization.
4. The monitor acknowledges only after returning successfully from the audit write and fsync. The broker checks exact ACK contents and independently re-reads the exact audit record before writing.
5. Storage power-loss persistence, post-effect continuous telemetry, hostile broker/monitor compromise and arbitrary outside access are not asserted.

Claim for the admitted path:

    effect(req) => source_condition(req) AND exact_bound_request(req)
                   AND matching_recorded_intent(req) AND single_use(req).

Proof by control flow and capabilities: every sink `write` in the broker is dominated by all four checks; on a missing source condition, a request mismatch, duplicate identity, missing ACK, incorrect ACK or missing audit record that branch is not reached. The worker cannot acquire a path/descriptor to write the sink: unlisted syscalls default to EPERM; only the designated pipe numbers have a `write` grant, and opening/duplicating descriptors, execution, networking and cross-process access are ungranted. The known inherited-sink-FD probe likewise has no `write` grant. Fork does not remove the filter. Therefore an effect in this admitted model must traverse the broker's checked path. The useful positive cases show that this is not obtained by denying every operation.

**Observed:** 17 predeclared/refined cases match. Sixteen use the guarded path; one intentionally ablates the guard and produces an unmonitored scratch write. Direct, delegated, native-syscall, proc-FD and inherited-FD attempts receive real EPERM outcomes. Valid broker and delegated requests have exact sink bytes and an audit record. With absent or insufficient monitoring and with violated/unjustified source conditions, the sink remains unchanged. Replayed input writes once.

This combines a conditional source argument with observed intervention controls. It supports the specific software-mediated causal mechanism, not a universal causal law, a complete sandbox, full PULSEbox assurance or existing release-policy integration. The official kernel documentation explicitly cautions that seccomp by itself is not a complete sandbox.

## T — Why an order alone does not identify physical duration

Suppose a relation R admits a real labeling tau with x R y => tau(x)<tau(y), and no metric, calibrated interval or other quantitative structure has been supplied. For any strictly increasing f, f composed with tau preserves all those order facts. In particular a*tau+b for a>0 has the same order with different scale/origin. Thus the order facts alone cannot select a unique physical duration scale. This is an identifiability theorem for the stated unweighted structure, not a refutation of relationally derived time. Additional relational data or calibrated readout constraints can break that ambiguity; their sufficiency must be proved rather than silently assumed.

For a directed cycle, strict increase around the cycle yields tau(x)<tau(x), so that particular scalar representation is impossible. It does not rule out local, cyclic or multidimensional structures, nor does it turn a processing loop into physical time.

## Physical experiment to instantiate, not to pretend completed

First test enforcement as a physical engineering claim, separately from any emergence-of-time claim. A safe small demonstrator could use a low-voltage LED as actuator and an independent photodetector as the effect observer. The command broker, monitor acknowledgment path, hardware enable boundary and detector/logger must have separate identities and explicit accessible routes. There is no connected actuator or photodetector in this execution environment; no physical detector data are claimed.

Declare and freeze before acquisition: the protected effect, device/source firmware identities, permitted and alternate paths, monitor condition, target-bound request, independent effect observable and uncertainty. Include matched controls for valid operation, absent monitor, wrong target, missing evidence, delegating client, replay, interrupted acknowledgment and an intentionally removed enforcement boundary. Observe actual detector output, not just software return codes. A zero-effect conclusion requires an observer sensitivity/availability claim; silence from a broken sensor is not a block proof. A no-bypass assertion requires route coverage or a justified hardware boundary, not merely several failed attempts.

For an emergence-of-time claim, first specify a relational predictor of a *physical measurable quantity* and a comparison model that makes a different prediction on the same apparatus. Observation windows, sensor clocks and execution order are measurement metadata, not automatically foundational time in the model. Without a discriminating prediction, fitting the same recorded ordering does not distinguish the hypothesis from another description. The current T theorem establishes a precise additional requirement; it does not supply the missing physical data or assume that a single global time must emerge.

## Production authority

`authority_effect: none` records lack of production execution permission, not lack of mathematical correctness. A research result must not create that permission for itself. Future activation requires an owner-authorized adapter, exact subject/run/policy binding, declared policy, materialized required conditions and the existing strict checker and target-side enforcement. None is silently activated by this local proof extension.

## Primary references for platform assumptions

- Linux seccomp filter semantics and limits: https://docs.kernel.org/userspace-api/seccomp_filter.html
- Linux Landlock capability/version/descriptor limits: https://docs.kernel.org/userspace-api/landlock.html
- uv managed interpreter distribution provenance: https://docs.astral.sh/uv/guides/install-python/

These are methodological/platform references. The execution evidence is stored separately under `evidence/`.
