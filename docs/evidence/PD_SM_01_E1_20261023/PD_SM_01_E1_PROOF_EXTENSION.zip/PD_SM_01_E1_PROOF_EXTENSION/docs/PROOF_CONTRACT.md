# PD-SM-01-E1 — predeclared proof-extension boundary

Date: 2026-10-23. Status: experimental local extension; production authority effect: none.
Owner request: strengthen the previous result beyond an example-only local test.
No repository write, CI dispatch, device operation or production policy change is authorized by this file.

## Tracks and their success criteria

1. **F1 exact finite evaluator profile.** Keep the four-input nine-Atom/four-edge fixture. Exhaust all 512 assignments of nine declared link switches and all 16 subsets of its four admitted source premises, for 8192 evaluations of the unchanged E0 independent evaluator. Switches: edge source (gate/CPU Atom); edge destination (latency/CPU Atom); tension selection (latency/CPU tension); that tension's specific gate ID (gate/CPU); source alias (gate/CPU); specific metric ID (latency/CPU); destination alias (latency/CPU); edge severity (crit/warn); edge rule (declared/other). Keep the selected latency edge ID and protected latency subject. Compute the oracle from the declared equality/type predicate and exact data comparison, not evaluator outcome flags. Preserve counterexamples. This is complete for these finite inputs, not arbitrary Paradoxon mechanics.
2. **F2 grounding profile.** Three propositions, every subset of six non-self unary implications and three two-distinct-premise conjunctions (512 rule sets), every subset of three bases (8). Compare bottom-up closure with the intersection of *all* closed supersets. Check withdrawal on every sub-base. Separate derivability from factual truth.
3. **MON-1 observed local operation.** One real scratch-file sink, one trusted broker, a separate monitor process, a worker and forked delegates. Before starting worker code, close non-permitted descriptors and install default-deny seccomp. Only explicit pipe descriptors are writable. No path-opening, exec, descriptor duplication, networking, ptrace, process_vm or pidfd acquisition allowed. The worker may fork; children inherit restrictions. The broker may append the exact predeclared scratch payload only after exact request binding and a matching monitor acknowledgment backed by a re-read audit entry. The monitor fsyncs the intent record before acknowledging. Duplicate request is not executed twice.
4. **Compatibility.** Genuine interpreter executions only; do not spoof sys.version. Keep core evaluator bytes and semantic expectations fixed. Missing interpreter/download means NOT_RUN, not failure or compatibility. First tested environment is recorded exactly; no all-versions claim.

## MON-1 invariant and trust assumptions

The operation is an append to a fresh scratch regular file, not an external device command. The monitor records a bound pre-operation intent, not continuous post-operation telemetry. The invariant is: every effect through the admitted broker path has the exact bound request and a durable-returned intent record from the separate monitor. Kernel, broker, monitor and controlling parent are trusted; hostile root outside the process tree, kernel exploits, power-loss persistence and broker compromise are outside this boundary. Seccomp is not claimed to be a complete sandbox. No PULSEmech ALLOW or release gate is manufactured here: a fixed experiment request is local test input, not production authority.

Predeclared cases: guarded direct open, unguarded direct open (ablation must show unmonitored effect), guarded forked direct open, guarded proc-fd reopen, guarded raw native openat, guarded inherited-file-descriptor attempt, valid broker request, valid delegated broker request, missing monitor, monitor exits after durable intent without ACK, ACK without audit record, wrong ACK digest, wrong request payload, wrong request target, replayed request. Positive operation must still occur; blocking everything is not success.

## Claim boundaries that cannot be erased by tests

The finite result may close this F1/F2 profile only. Physical time emergence needs a distinct operational hypothesis and measurements not entailed by the software relation encoding. A monitor/broker experiment supplies evidence for a software-mediated causal mechanism under interventions; it does not prove a new physical law. Production authority effect remains none until a separately authorized, policy-bound integration is implemented and tested.

## MON-1 binding refinement before selected run monitor_03

The selected run repeats the fifteen predeclared cases and adds two explicit cases, M32 and M33. It re-evaluates the immutable E0 reference input of E20 (relation violated) and E30 (source evidence unavailable) with the unchanged E0 independent evaluator. Neither may reach a sink write even with an available monitor. Each admitted request binds exact reference-input bytes, subject and assessment. This is a test-only admission precondition, not a PULSE release verdict. The worker cannot set the broker's evidence-admission result.

The first exploratory run had a multi-threaded-fork warning. It is retained, not silently replaced. The selected supervisor requires one thread and is invoked with `-I -S -B`. The second exploratory run verified this clean environment. No case expectation was weakened. The selected code also distinguishes idle-monitor EOF from an unexpected monitor error and checks monitor process exit status.
