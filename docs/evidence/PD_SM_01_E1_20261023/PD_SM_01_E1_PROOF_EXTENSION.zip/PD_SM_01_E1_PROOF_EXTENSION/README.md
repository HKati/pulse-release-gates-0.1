# PD-SM-01-E1 proof extension

This is an evidence/implementation package, **not a repository upload ZIP**.
No original source, production policy, workflow or authority was changed.

## Actual selected results

- `evidence/finite_01/RESULTS.json`: complete F1 comparison on 8192 declared inputs, complete F2 comparison on 4096 rule/base systems and 13824 withdrawal checks; zero discrepancies.
- `evidence/monitor_03/RESULTS.json`: 17 real local process/monitor/scratch-file scenarios; all matched the explicit expectations. This includes one deliberately unguarded ablation which *does* create an unmonitored effect. Its expected MATCH is not a safety pass.
- `evidence/COMPATIBILITY_ENVIRONMENT.json`: extra interpreter acquisition failed; genuine cross-version execution remains incomplete. No version was spoofed.

Read `docs/PROOF_CONTRACT.md` and `docs/CONDITIONAL_PROOFS_AND_PHYSICAL_TEST.md` for exact domains, proofs, assumptions and remaining observations. The native monitor probe is a source-bound local prototype, not full PULSEbox or continuous post-operation telemetry. `authority_effect: none` is a production-permission boundary, not a mathematical verdict.

## Historical input and offline replay

`inputs/PD_SM_01_E0_PY3135_RESULT.zip` is the original E0 package, byte-identical. Its 694 SHA-256 inventory entries were verified. Unpack it into a fresh work directory using an archive reader that rejects absolute paths, traversal and symlinks. The archive member root is `PD_SM_01_E0_PY3135_RESULT`.

With `E0` set to that extracted root and an exact selected Python path `PYTHON`:

```sh
"$PYTHON" -I -S -B code/finite_profile.py --e0-root "$E0" --output /absolute/new/finite
"$PYTHON" -I -S -B code/enforcement_probe.py --e0-root "$E0" --output /absolute/new/monitor
```

Use new output directories. The observed run used CPython 3.13.5 on Linux x86_64 and the host `libseccomp.so.2`. The monitor supervisor must be single-threaded (`-S` avoids third-party site initialization), and stops before the experiment otherwise. No package installation, external inference or network access is used by these test programs. The experimental broker creates effects only in its new scratch sink files. It has no production release interface.

## Prepared, not yet executed multi-version matrix

`code/compatibility_matrix.py` accepts real interpreter paths. It makes a disposable E0 bundle copy for each, alters only the coordinator's explicit environment gate and corresponding description, records the exact diff, and keeps the evaluator, original producer/checker files, expectations and regression code unchanged. It compares actual scenario assessments, subjects, projections and process returns across completed runs. Missing runtimes do not become success. The runner performs no downloads and never modifies the original E0 copy.

```sh
python -I -S -B code/compatibility_matrix.py --e0-root "$E0" \
  --output /absolute/new/matrix \
  --interpreter /actual/path/to/python3.12 \
  --interpreter /actual/path/to/python3.13
```

The example paths must be replaced with installed executable paths. This matrix script has been parsed for syntax but has **not** produced a cross-version result in this delivery. It is not a claim of compatibility, nor an instruction to install a runner or alter CI.

## Development evidence

`monitor_01` and `monitor_02` are retained exploratory records, with their exact source snapshots. The first produced a Python multi-threaded-fork warning and idle monitor EOF exits; it is not the selected proof run. The second exercised a single-threaded `-S` supervisor and clean idle-monitor shutdown. The selected third run adds actual E0 source-assessment binding and the violated/missing-evidence controls. These are not independent third-party validations or 47 additional identical trials.

The physical test section is a concrete acquisition protocol, **NOT_RUN**. No LED/sensor/device is connected here. The time-label non-identifiability theorem is conditional mathematics, not a physical time-emergence experiment.

`SHA256SUMS` covers every supplied file except itself. Verify archive integrity and individual file digests before executing code. The new summary does not rewrite any old NOT_RUN or incomplete historical record.
