# PULSEmech / Paradoxon Diagram — bizonyítási kiterjesztés

**Azonosító:** PD-SM-01-E1  
**Dátum:** 2026-10-23  
**Státusz:** végrehajtott véges ellenőrzés és helyi kikényszerítési demonstrátor, feltételes matematikai levezetésekkel  
**Éles authority-hatás:** none  
**Repository-módosítás / CI-indítás:** nem történt

## 1. Mit zártunk le ténylegesen?

### F1: a kijelölt kapcsolati–bizonyítási profil teljes ellenőrzése

Nem újabb néhány példát adtunk az E0 eredményéhez. Előre megadtunk kilenc bináris kapcsolati változtatást és a négy elfogadott forrás minden részhalmazát: összesen **8192 konfigurációt**. Mindet kiértékelte a korábbi, változatlan referenciaértékelő. A külön megadott típus- és mezőegyezési feltételtől, származási és igazolási elvárástól **egyetlen eltérés sem volt**.

8128 értékelésben a kapcsolati követelmény sérült; 7680 értékelésben nem állt rendelkezésre a teljes forrásigazolás. Pontosan egy konfiguráció igazolta az eredeti, védett latency-tárgy teljes forrásszármaztatását. Ezek átfedő kategóriák, nem összeadandó tesztszámok.

Ez teljes körű eredmény a kimondott véges tartományra. Nem nevezzük át a teljes, tetszőleges méretű és jelentésű Paradoxon-mechanika bizonyításává. Az idő, okság, magasabb aritás vagy működési folyamat nem lett hallgatólagos előfeltétel.

### F2: bizonyítékkörök, közös feltételek és visszavonások

Három állítás minden részhalmaza, hat egyszerű és három kétpremisszás szabály minden szabályrendszere alapján **4096 rendszert** ellenőriztünk. A levezetési lezárást két eltérő eljárás számolta: következtetési szabályok ismételt alkalmazása, illetve minden zárt felülhalmaz metszete.

Ezenfelül **13 824 visszavonási összehasonlítás** történt. Nulla eltérés. A csomagban szerepel a véges pozitív szabályrendszerekre érvényes általános lezárási tétel levezetése is. A levezetési szintek nem mechanikai időpontok.

## 2. MON-1: ténylegesen történik-e tiltott művelet?

A cél már nem csupán JSON-értékelés volt. Külön Linux-folyamatként szerepelt a monitor, a dolgozó és szükség szerint annak delegált gyermeke; a megbízható közvetítő birtokolta egy friss, helyi célfájl írási lehetőségét.

A dolgozó és leszármazottja alapértelmezetten tiltó seccomp-szűrőt kapott. Csak a kijelölt csővezeték-fájlleírókra írhatott; nem kapott általános fájlmegnyitást, végrehajtást, hálózatot, fájlleíró-duplikálást vagy más folyamat elérését. A vizsgálat kizárólag új munkakönyvtárbeli fájlokra vonatkozott.

A közvetítő az E0 tényleges bemeneteit a változatlan értékelővel újra kiértékelte. A kiválasztott tárgy, bemenet és értékelés lenyomatához kötötte a helyi tesztkérést. Csak igazolt forrásfeltétel, pontos kéréskötés, egyszeri használat, valamint a külön monitortól kapott, ténylegesen visszaolvasott naplóval alátámasztott nyugta után írhatott a célfájlba.

**A kiválasztott, egyetlen szálú előkészítő folyamatból indult végleges futás: 17/17 egyező eset.** Ezek közül 16 védett, egy pedig szándékosan kikapcsolt védelmű ellenpróba.

| Beavatkozás | Megfigyelt eredmény |
|---|---|
| Közvetlen, delegált, natív rendszerhívásos, `/proc`-fájlleíróra irányuló és örökölt fájlleírós írási kísérlet | A védett dolgozó tényleges `EPERM` hibát kapott; a célfájl változatlan. |
| A védelem szándékos kivétele | Azonos művelettípus friss célfájlon monitorozás nélkül írni tudott. Ez a szükségességi ellenpróba elvárt sérülése, nem biztonsági PASS. |
| Érvényes monitorozott kérés, közvetlenül és delegálva | A pontos hasznos művelet végrehajtódott, a hozzá tartozó monitorrekord fennmaradt. |
| Hiányzó monitor; naplózás utáni, nyugta előtti kilépés; hibás nyugta; napló nélküli nyugta | Nem történt célfájlírás. |
| Más payload vagy célpont | A kéréskötés elutasította; nem történt írás. |
| A korábbi E20 sértő kapcsolata | A tényleges referenciaértékelés alapján nem volt megengedett helyi hatás. |
| A korábbi E30 hiányzó forrásbizonyítéka | A belső kapcsolat megfelelősége nem pótolta a forrásigazolást; nem történt írás. |
| Ugyanaz a kérés kétszer | Egyetlen hatás; az ismétlés külön elutasítva. |

A fájl tényleges tartalmát és a monitor naplóját a dolgozótól független felügyelő olvasta vissza. Nem a dolgozó saját sikerjelzése szolgált a hatás bizonyítékául.

**Ez a konkrét helyi művelet kikényszerítésének bizonyítéka**, nem általános sandbox- vagy kész PULSEbox-állítás. A monitor itt a védett művelethez kötött, a művelet előtt rögzített szándékot igazolja; nem folyamatos utólagos telemetriát. A kernel, közvetítő és monitor megbízhatósága feltétel. Külső rendszergazda, kernelhiba, áramszüneti tartósság és a közvetítő kompromittálása nincs lezárva.

## 3. A fizikai okság és idő kérdésében mi az új eredmény?

A helyi ellenpróba a megadott szoftveres beavatkozási mechanizmust támogatja: bekapcsolt korlátozásnál nincs közvetlen hatás, eltávolított korlátozásnál létrejön. Ez nem azonos egy új fizikai időtörvény igazolásával.

A matematikai részben egy konkrét azonosíthatósági korlátot vezettünk le: ha csak rendezési reláció áll rendelkezésre, minden szigorúan növekvő újracímkézés ugyanazt a rendet őrzi meg. Ezért pusztán a rendből nem adódik egyedi fizikai időskála. Ez nem cáfolja a relációkból származtatott idő hipotézisét; megmutatja, milyen többlet-relációs vagy mérési feltétel szükséges az erősebb állításhoz.

A csomag meghatározza a következő fizikai demonstrátor szerződését: például kisfeszültségű LED mint védett hatás, külön fényérzékelő mint független megfigyelő, pontos útvonal- és nyugtakötés, hibainjektálások és beavatkozásos kontrollok. Itt nincs csatlakoztatott aktuátor vagy érzékelő, ezért fizikai mérési eredmény nem keletkezett. Az időkeletkezési állításhoz előbb megkülönböztető mennyiségi előrejelzés is kell; az ugyanazokat az adatokat átnevező leírás nem elég.

## 4. Többverziós kompatibilitás: pontos fennmaradó akadály

A 3.11.14, 3.12.12 és 3.14.3 külön interpreterének elkülönített beszerzését megkíséreltem. A helyi letöltés DNS-feloldási hibával leállt; a külön letöltőeszköz sem készített interpreterarchívumot. Egyiket sem helyettesítettem verziószám-hamisítással. A ténylegesen használt interpreter továbbra is **CPython 3.13.5 / Linux**.

A kompatibilitási futtató elkészült. Valódi megadott interpretereken az eredeti E0-producer/ellenőrző programokat, az értékelőt, az elvárásokat és a regressziós teszteket használja. Csak egy külön munkapéldány környezeti kapuját igazítja a kifejezetten mért interpreterverzióhoz, teljes diff-fel. A kód szintaktikai ellenőrzése megtörtént; a többverziós mátrix még `NOT_RUN`. Ez konkrét végrehajtási hiány, nem bizonyított inkompatibilitás.

## 5. Miért marad az authority-hatás `none`?

Ez nem azt jelenti, hogy az eredmény nincs igazolva. Azt jelenti, hogy a kutatási eredmény nem ad magának éles kiadási vagy eszközjogosultságot.

A tesztközvetítő kizárólag a tulajdonos által kért helyi kísérlet friss célfájljára hat. Nem készít PULSEmech-ALLOW döntést, nem új release-engine, és nem módosítja a deklarált policyt. Az éles integráció külön tárgy-, futás-, policy- és jogosultságkötést, valamint a meglévő strict checker és a céloldali határ külön ellenőrzését igényli.

## 6. Megőrzés és ellenőrzési korlát

Az E0-archívum 694 fájl-lenyomatát ellenőriztem; eltérés nem volt. Az eredeti csomag bájtazonosan benne maradt az új csomagban. A F1/F2 referenciaértékelő változatlan.

A `monitor_01` és `monitor_02` fejlesztési próbák forrásai és eredményei megmaradtak. Az első több szál melletti fork-figyelmeztetést adott; a végleges változat egyetlen szálat követel és `-I -S -B` kapcsolókkal futott. A harmadik a kiválasztott, forrásbizonyítékhoz is kötött eredmény. A korábbi próbákat nem adjuk hozzá független validációként a 17 esethez.

A `verify_results.py` a fájllenyomatokon túl a teljes véges lefedettséget, az elvárt és megfigyelt értékeket, valamint a célfájl és auditnapló tartalmát is külön ellenőrzi. Ez ugyanazon munka keretében készített ellenőrzés; szervezetileg független külső auditot nem állítunk.

**Következtetés:** a kijelölt véges mechanikai/bizonyítási profil és a pontosan behatárolt monitorozott helyi művelet erősebb igazolást kapott. A többverziós futás és a független fizikai hatásmérés konkrét fennmaradó feladat; az általános elméletet nem minősítettük késznek a részállítások teljesüléséből.
