"""Read-only verifier of delivered result tables and local sink/audit evidence."""
from __future__ import annotations
import argparse,hashlib,json
from pathlib import Path

def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);a=ap.parse_args();r=a.root
    count=0
    for line in (r/'SHA256SUMS').read_text().splitlines():
        want,name=line.split('  ',1);p=r/name
        if p.is_symlink() or not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=want:raise ValueError('inventory mismatch '+name)
        count+=1
    rows=[json.loads(x) for x in (r/'evidence/finite_01/F1_all_assignments.jsonl').read_text().splitlines()]
    if len(rows)!=8192 or {(x['assignment'],x['evidence_mask']) for x in rows}!={(i,m) for i in range(512) for m in range(16)}:raise ValueError('F1 coverage')
    for x in rows:
        b=list(map(int,f"{x['assignment']:09b}"))
        if x['bits']!=b:raise ValueError('F1 bit ordering')
        link='SATISFIED' if b[0]==b[3]==b[4]==b[7]==b[8]==0 and b[1]==b[5]==b[6] else 'VIOLATED'
        origin='UNRESOLVED' if x['evidence_mask']!=15 else 'JUSTIFIED_WITHIN_FIXTURE_BOUNDARY' if x['assignment']==0 else 'CONTRADICTED'
        proof='JUSTIFIED_FOR_SELECTED_TARGET' if x['evidence_mask']==15 and x['assignment']==0 else 'NOT_JUSTIFIED'
        if x['expected']!=[link,origin,proof] or x['actual']!=[link,origin,proof] or x['match'] is not True:raise ValueError('F1 mismatch')
    f2=[json.loads(x) for x in (r/'evidence/finite_01/F2_all_profiles.jsonl').read_text().splitlines()]
    if len(f2)!=4096 or {(x['rules'],x['bases']) for x in f2}!={(i,m) for i in range(512) for m in range(8)}:raise ValueError('F2 coverage')
    universe=[(1<<p,c) for p in range(3) for c in range(3) if p!=c]+[(7^(1<<c),c) for c in range(3)]
    for x in f2:
        rules=[q for i,q in enumerate(universe) if x['rules']&(1<<i)]
        closed=[s for s in range(8) if s&x['bases']==x['bases'] and all(s&p!=p or s&(1<<c) for p,c in rules)]
        meet=7
        for s in closed:meet&=s
        result=[i for i in range(3) if meet&(1<<i)]
        if x['closure']!=result or x['independent_closed_set_intersection']!=result or x['match'] is not True:raise ValueError('F2 mismatch')
    mroot=r/'evidence/monitor_03';summary=json.loads((mroot/'RESULTS.json').read_text());pre=json.loads((mroot/'PREEXECUTION.json').read_text())
    if set(summary['case_results'])!=set(pre['cases']) or len(pre['cases'])!=17:raise ValueError('monitor case coverage')
    guarded_effects=0;rejected=0
    for name in pre['cases']:
        f=mroot/name;v=json.loads((f/'RESULT.json').read_text());sink=(f/'sink.bin').read_bytes();audit=(f/'monitor.jsonl').read_bytes();records=[json.loads(t) for t in audit.splitlines()]
        if v['sink_hex']!=sink.hex() or v['sink_sha256']!=hashlib.sha256(sink).hexdigest() or v['audit_sha256']!=hashlib.sha256(audit).hexdigest():raise ValueError('target mismatch')
        if sink.hex()!=v['expected_sink_hex'] or len(records)!=v['expected_audit_count']:raise ValueError('monitor expectation')
        if v['actor_status']['exit_code']!=0 or v['monitor_status']['exit_code']!=0 or v['comparison']!='MATCH':raise ValueError('process status')
        if any(flag is not True for flag in v['checks'].values()):raise ValueError('monitor check false')
        if v['actor_observation']['guard_installed']:
            if sink:
                guarded_effects+=1
                if v['source_assessment_admitted'] is not True or len(records)!=1 or records[0]['request']!=v['request']:raise ValueError('unmonitored effect')
                stages=[e['stage'] for e in v['broker_trace']]
                if stages.index('monitor')>=stages.index('effect'):raise ValueError('effect before monitoring')
            else:rejected+=1
    print(json.dumps({'status':'MATCH','inventory_files':count,'F1_rows_checked':len(rows),'F2_rows_checked':len(f2),'MON1_cases_checked':17,'guarded_cases_with_exact_monitored_effect':guarded_effects,'guarded_cases_without_effect':rejected,'deliberately_unguarded_ablation_cases':1,'authority_effect':'none'}))
if __name__=='__main__':main()
