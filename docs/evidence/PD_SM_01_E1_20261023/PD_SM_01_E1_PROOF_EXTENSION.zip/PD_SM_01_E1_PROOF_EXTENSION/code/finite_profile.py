"""Exhaustive tests of the declared F1/F2 profiles; no external operations."""
from __future__ import annotations
import argparse, copy, hashlib, importlib.util, itertools, json, platform, sys, time
from pathlib import Path

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):
    Path(p).write_text(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2)+'\n')
def load_subject(path):
    spec=importlib.util.spec_from_file_location('e0_subject_under_test',path)
    m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m

def maskset(mask): return {i for i in range(3) if mask & (1<<i)}
def bottom(bases,rules):
    value=set(bases)
    while True:
        nxt=value|{c for p,c in rules if p<=value}
        if nxt==value: return value
        value=nxt

def closed_intersection(bases,rules):
    models=[maskset(i) for i in range(8) if bases<=maskset(i) and all(not p<=maskset(i) or c in maskset(i) for p,c in rules)]
    return set.intersection(*models)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--e0-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
    a.output.mkdir(parents=True,exist_ok=False)
    path=a.e0_root/'pd_sm_01_e0/independent_reference.py'; ref=load_subject(path)
    original=json.loads((a.e0_root/'execution_03/workspace/cases/E00/reference_input.json').read_text())
    field0=original['field'];edges0=original['edges'];sub=original['subject'];evidence=original['evidence']
    atoms0={x['atom_id']:x for x in field0['paradox_field_v0']['atoms']}
    g=next(x['atom_id'] for x in atoms0.values() if x['type']=='gate_flip')
    met={x['evidence']['metric']['name']:x['atom_id'] for x in atoms0.values() if x['type']=='metric_delta'}
    ml,mc=met['p99_latency'],met['cpu_util']; tids={x['evidence']['metric_atom_id']:x['atom_id'] for x in atoms0.values() if x['type']=='gate_metric_tension'}
    rule='gate_flip × metric_delta(warn|crit)'; names=sorted(evidence); records=[];fails=[];start=time.monotonic(); justified=violations=unknown=0
    freeze={'subject_sha256':sha(path),'expectations':'docs/PROOF_CONTRACT.md F1/F2','input_sha256':sha(a.e0_root/'execution_03/workspace/cases/E00/reference_input.json'),'python':sys.version,'executable_sha256':sha(sys.executable),'script_sha256':sha(__file__)}
    put(a.output/'freeze.json',freeze)
    for index,bits in enumerate(itertools.product((0,1),repeat=9)):
        f=copy.deepcopy(field0); es=copy.deepcopy(edges0); atoms={x['atom_id']:x for x in f['paradox_field_v0']['atoms']};e=next(x for x in es if x['edge_id']==sub['edge_id'])
        e['src_atom_id']=(g,mc)[bits[0]];e['dst_atom_id']=(ml,mc)[bits[1]];e['tension_atom_id']=(tids[ml],tids[mc])[bits[2]]
        t=atoms[e['tension_atom_id']]; te=t['evidence'];te['gate_atom_id']=(g,mc)[bits[3]];te['src_atom_id']=(g,mc)[bits[4]];te['metric_atom_id']=(ml,mc)[bits[5]];te['dst_atom_id']=(ml,mc)[bits[6]]
        e['severity']=('crit','warn')[bits[7]];e['rule']=(rule,'other rule')[bits[8]]
        expected_link='SATISFIED' if (bits[0]==bits[3]==bits[4]==bits[7]==bits[8]==0 and bits[1]==bits[5]==bits[6]) else 'VIOLATED'
        exact_original=(f==field0 and es==edges0)
        for mask in range(16):
            ev={n:evidence[n] for j,n in enumerate(names) if mask & (1<<j)}
            result=ref.assess({'field':f,'edges':es,'subject':sub,'evidence':ev})
            expected_origin='UNRESOLVED' if mask!=15 else 'JUSTIFIED_WITHIN_FIXTURE_BOUNDARY' if exact_original else 'CONTRADICTED'
            expected_proof='JUSTIFIED_FOR_SELECTED_TARGET' if exact_original and mask==15 else 'NOT_JUSTIFIED'
            actual=[result['reference_relation_assessment'],result['reference_source_assessment'],result['proof_applicability_assessment']]
            expected=[expected_link,expected_origin,expected_proof]
            good=(actual==expected and result['coverage_status']=='COMPLETE_FOR_DECLARED_CASE')
            rec={'assignment':index,'bits':list(bits),'evidence_mask':mask,'expected':expected,'actual':actual,'match':good};records.append(rec)
            if not good:fails.append(rec)
            justified+=actual[2]=='JUSTIFIED_FOR_SELECTED_TARGET';violations+=actual[0]=='VIOLATED';unknown+=actual[1]=='UNRESOLVED'
    with (a.output/'F1_all_assignments.jsonl').open('w') as stream:
        for r in records:stream.write(json.dumps(r,sort_keys=True)+'\n')
    rule_universe=[(frozenset([p]),c) for p in range(3) for c in range(3) if p!=c]+[(frozenset(set(range(3))-{c}),c) for c in range(3)]
    f2=[];withdrawals=0
    for rm in range(512):
        rules=[r for i,r in enumerate(rule_universe) if rm&(1<<i)]
        for bm in range(8):
            base=maskset(bm);obtained=bottom(base,rules);expected=closed_intersection(base,rules)
            if obtained!=expected:fails.append({'F2_rules':rm,'bases':bm})
            for submask in range(8):
                if maskset(submask)<=base:
                    withdrawals+=1
                    if bottom(maskset(submask),rules)!=closed_intersection(maskset(submask),rules):fails.append({'F2_withdrawal':rm,'bases':bm,'sub':submask})
            f2.append({'rules':rm,'bases':bm,'closure':sorted(obtained),'independent_closed_set_intersection':sorted(expected),'match':obtained==expected})
    with (a.output/'F2_all_profiles.jsonl').open('w') as stream:
        for r in f2:stream.write(json.dumps(r,sort_keys=True)+'\n')
    result={'status':'MATCH' if not fails else 'MISMATCH','F1_evaluations':len(records),'F1_link_violations':violations,'F1_unresolved_origin':unknown,'F1_justified_proofs':justified,'F2_rule_and_base_profiles':len(f2),'F2_withdrawal_comparisons':withdrawals,'failures':fails,'seconds':time.monotonic()-start,'subject_unchanged':sha(path)==freeze['subject_sha256'],'repository_write':False,'authority_effect':'none','scope':'Complete only for enumerated F1/F2 domains; not all Paradoxon inputs.'}
    put(a.output/'RESULTS.json',result);print(json.dumps(result));return 0 if result['status']=='MATCH' else 1
if __name__=='__main__':raise SystemExit(main())
