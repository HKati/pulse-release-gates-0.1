"""Prepared genuine-interpreter compatibility runner. No downloads or repo writes.
Runs the unchanged E0 evaluator/tests and original six programs, with only an
explicit environment-gate adaptation of a scratch copy of the old coordinator.
Not executed for missing interpreters. Run after inspecting the complete bundle.
"""
from __future__ import annotations
import argparse,difflib,hashlib,json,os,shutil,subprocess,sys
from pathlib import Path

def h(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):Path(p).write_text(json.dumps(v,sort_keys=True,indent=2)+'\n')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--e0-root',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--interpreter',action='append',required=True,help='Exact executable path, repeat for each actual interpreter');a=ap.parse_args()
    a.output.mkdir(parents=True,exist_ok=False);results=[];semantic=[]
    for index,interpreter in enumerate(a.interpreter):
        p=Path(interpreter).resolve();folder=a.output/str(index);folder.mkdir()
        if not p.is_file():
            results.append({'interpreter':str(p),'status':'NOT_RUN','reason':'INTERPRETER_UNAVAILABLE'});continue
        probe=subprocess.run([str(p),'-I','-S','-B','-c','import platform,sys,json; print(json.dumps({"version":platform.python_version(),"implementation":platform.python_implementation(),"platform":platform.system()}))'],capture_output=True,text=True,timeout=10,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'})
        (folder/'probe.stdout').write_text(probe.stdout);(folder/'probe.stderr').write_text(probe.stderr)
        if probe.returncode:
            results.append({'interpreter':str(p),'status':'INCOMPLETE','reason':'VERSION_PROBE_FAILED'});continue
        info=json.loads(probe.stdout)
        if info['implementation']!='CPython' or info['platform']!='Linux':
            results.append({'interpreter':str(p),'status':'NOT_RUN','reason':'OUTSIDE_DECLARED_LINUX_CPYTHON_MATRIX','observed':info});continue
        local=folder/'bundle';local.mkdir()
        for sub in ('pd_sm_01_e0','preparation','source'):shutil.copytree(a.e0_root/sub,local/sub)
        revision=json.loads((a.e0_root/'ENVIRONMENT_PROFILE_REVISION.json').read_text());revision['profile_id']='PD-SM-01-E1-compat-'+info['version'];revision['change']['selected_value']=info['version'];revision['authorization_basis']='Separate local compatibility experiment; no production or original profile change.'
        put(local/'ENVIRONMENT_PROFILE_REVISION.json',revision)
        runner=local/'pd_sm_01_e0/run_cases.py';old=runner.read_text()
        # Transparent environment-only adaptation; semantic functions are untouched.
        if old.count("platform.python_version()!='3.13.5'")!=1:raise RuntimeError('unexpected original gate')
        new=old.replace("platform.python_version()!='3.13.5'","platform.python_version()!="+repr(info['version']))
        new=new.replace('this run profile requires CPython 3.13.5 Linux','this separate run profile requires CPython '+info['version']+' Linux')
        new=new.replace('Only CPython 3.13.5 Linux executed; no cross-version equivalence claim.','This record covers only CPython '+info['version']+' Linux; cross-record comparison is separate.')
        runner.write_text(new)
        (folder/'environment_gate.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='E0/run_cases.py',tofile='E1-scratch/run_cases.py')))
        core=['independent_reference.py','test_harness.py','case_expectations.json']
        if any(h(local/'pd_sm_01_e0'/x)!=h(a.e0_root/'pd_sm_01_e0'/x) for x in core):raise RuntimeError('core changed')
        put(folder/'PREFLIGHT.json',{'interpreter':str(p),'interpreter_sha256':h(p),'observed':info,'core_sha256':{x:h(local/'pd_sm_01_e0'/x) for x in core},'runner_sha256':h(runner),'source_snapshot':'102145d1f1c321811c52d9d20f92cc7289127b2b','authority_effect':'none'})
        argv=[str(p),'-I','-S','-B',str(runner),'--bundle-root',str(local),'--output',str(folder/'execution')]
        with (folder/'run.stdout').open('wb') as out,(folder/'run.stderr').open('wb') as err:
            # A new process group permits exact cleanup on timeout.
            child=subprocess.Popen(argv,stdout=out,stderr=err,start_new_session=True,env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8','LC_ALL':'C.UTF-8'})
            try:rc=child.wait(timeout=180)
            except subprocess.TimeoutExpired:
                import signal
                os.killpg(child.pid,signal.SIGKILL);child.wait();rc=None
        r=folder/'execution/RESULTS.json'
        if rc!=0 or not r.is_file():results.append({'interpreter':str(p),'observed':info,'status':'INCOMPLETE','returncode':rc});continue
        data=json.loads(r.read_text());view={}
        for sid,v in data['all_scenarios'].items():
            view[sid]={k:v[k] for k in ('reference_relation_assessment','reference_source_assessment','proof_applicability_assessment','carrier_assessment','semantic_projection_sha256','selected_subject')}
            view[sid]['program_returncodes']={k:vv['returncode'] for k,vv in v['program_observations'].items()}
        semantic.append((info['version'],view));results.append({'interpreter':str(p),'observed':info,'status':data['experiment_comparison'],'semantic_result_sha256':hashlib.sha256(json.dumps(view,sort_keys=True).encode()).hexdigest(),'core_sha256':{x:h(local/'pd_sm_01_e0'/x) for x in core}})
    minor={'.'.join(v.split('.')[:2]) for v,_ in semantic}
    good=len(semantic)==len(results) and len(minor)>=2 and all(v==semantic[0][1] for _,v in semantic) and all(r['status']=='MATCH' for r in results)
    report={'status':'MATCH' if good else 'INCOMPLETE_OR_DIFFERENT','results':results,'distinct_executed_minor_versions':sorted(minor),'all_semantic_views_equal':bool(semantic) and all(v==semantic[0][1] for _,v in semantic),'authority_effect':'none','scope':'Exact supplied interpreters and fixed E0 inputs only; not every Python release/OS.'}
    put(a.output/'MATRIX.json',report);print(json.dumps(report));return 0 if good else 1
if __name__=='__main__':raise SystemExit(main())
