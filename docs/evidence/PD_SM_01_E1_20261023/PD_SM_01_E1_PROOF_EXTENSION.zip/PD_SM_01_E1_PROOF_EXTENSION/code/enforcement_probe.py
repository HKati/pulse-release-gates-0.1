"""MON-1: real, bounded scratch-file enforcement with a separate monitor.
Not production PULSE authority. Trusted broker/kernel/monitor; adversarial worker
routes are restricted by default-deny seccomp and descriptor minimization.
"""
from __future__ import annotations
import argparse, ctypes, errno, hashlib, importlib.util, json, os, select, signal, stat, sys, time
from pathlib import Path

LIB=ctypes.CDLL('libseccomp.so.2',use_errno=True)
LIB.seccomp_init.argtypes=[ctypes.c_uint32];LIB.seccomp_init.restype=ctypes.c_void_p
LIB.seccomp_syscall_resolve_name.argtypes=[ctypes.c_char_p];LIB.seccomp_syscall_resolve_name.restype=ctypes.c_int
LIB.seccomp_rule_add_array.argtypes=[ctypes.c_void_p,ctypes.c_uint32,ctypes.c_int,ctypes.c_uint,ctypes.c_void_p];LIB.seccomp_rule_add_array.restype=ctypes.c_int
LIB.seccomp_load.argtypes=[ctypes.c_void_p];LIB.seccomp_load.restype=ctypes.c_int
LIB.seccomp_release.argtypes=[ctypes.c_void_p]
LIBC=ctypes.CDLL(None,use_errno=True);LIBC.syscall.restype=ctypes.c_long
class Cmp(ctypes.Structure):_fields_=[('arg',ctypes.c_uint),('op',ctypes.c_int),('a',ctypes.c_uint64),('b',ctypes.c_uint64)]
def enc(o):return json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
def digest(b):return hashlib.sha256(b).hexdigest()
def write_json(p,v):Path(p).write_bytes(json.dumps(v,ensure_ascii=False,sort_keys=True,indent=2).encode()+b'\n')
def close_except(fds):
    for name in os.listdir('/proc/self/fd'):
        fd=int(name)
        if fd not in fds:
            try:os.close(fd)
            except OSError:pass

def restrict_worker(write_fds):
    """No opens or general writes. Existing pipe endpoints are the capabilities."""
    for fd in write_fds:
        if not stat.S_ISFIFO(os.fstat(fd).st_mode):raise ValueError('non-pipe output capability')
    ctx=LIB.seccomp_init(0x00050000|errno.EPERM)
    if not ctx:raise RuntimeError('seccomp init failed')
    allowed=['exit','exit_group','close','brk','munmap','mremap','mprotect','madvise','futex','rt_sigaction','rt_sigprocmask','rt_sigreturn','sigaltstack','getpid','getppid','gettid','getrandom','clock_gettime','wait4','fork','clone','set_robust_list','rseq','restart_syscall']
    try:
        def add(name,cmp=None):
            nr=LIB.seccomp_syscall_resolve_name(name.encode())
            if nr<0:raise RuntimeError('unknown syscall '+name)
            rc=LIB.seccomp_rule_add_array(ctx,0x7fff0000,nr,1 if cmp is not None else 0,ctypes.byref(cmp) if cmp is not None else None)
            if rc:raise RuntimeError('seccomp rule failed '+name+':'+str(rc))
        for name in allowed:add(name)
        for fd in write_fds:add('write',Cmp(0,4,fd,0))
        add('mmap',Cmp(4,4,2**64-1,0))  # anonymous memory only
        if LIB.seccomp_load(ctx):raise RuntimeError('seccomp load failed')
    finally:LIB.seccomp_release(ctx)

def frame(fd,obj):
    raw=enc(obj)+b'\n'
    if len(raw)>3500:raise ValueError('oversized local frame')
    if os.write(fd,raw)!=len(raw):raise RuntimeError('short pipe write')

def read_frame(fd,timeout=1.0):
    if not select.select([fd],[],[],timeout)[0]:raise TimeoutError('no frame')
    data=b''
    while not data.endswith(b'\n'):
        p=os.read(fd,1)
        if not p:raise EOFError('pipe closed')
        data+=p
        if len(data)>3500:raise ValueError('oversized frame')
    return json.loads(data)

def child_status(pid):
    _,status=os.waitpid(pid,0)
    return {'normal_exit':os.WIFEXITED(status),'exit_code':os.WEXITSTATUS(status) if os.WIFEXITED(status) else None,'signal':os.WTERMSIG(status) if os.WIFSIGNALED(status) else None}

def monitor_main(request_fd,ack_fd,audit_path,mode):
    try:
        close_except({request_fd,ack_fd})
        if mode=='absent':os._exit(0)
        request=read_frame(request_fd)
        if mode!='ack_without_record':
            raw=enc({'event':'INTENT','request':request,'request_sha256':digest(enc(request))})+b'\n'
            fd=os.open(audit_path,os.O_WRONLY|os.O_APPEND|os.O_CREAT,0o600)
            try:
                if os.write(fd,raw)!=len(raw):raise RuntimeError('short audit write')
                os.fsync(fd)
            finally:os.close(fd)
        if mode=='exit_after_record':os._exit(0)
        frame(ack_fd,{'recorded':True,'request_sha256':'0'*64 if mode=='wrong_ack' else digest(enc(request))})
        os._exit(0)
    except EOFError:os._exit(0)  # No request was admitted; idle monitor closes cleanly.
    except BaseException:os._exit(90)

def worker_main(request_fd,result_fd,sink_path,broker_pid,sink_fd,action,request,guard,leak_fd):
    try:
        # Include leak only in the descriptor probe; write is still not granted to it.
        keep={request_fd,result_fd}
        if leak_fd is not None:keep.add(leak_fd)
        close_except(keep)
        if guard:restrict_worker({request_fd,result_fd})
        def attempt():
            report={'pid':os.getpid(),'guard_installed':guard,'action':action}
            try:
                if action=='direct' or action=='delegate_direct':
                    fd=os.open(sink_path,os.O_WRONLY|os.O_APPEND)
                    try:os.write(fd,b'UNMONITORED')
                    finally:os.close(fd)
                elif action=='proc_reopen':
                    fd=os.open('/proc/'+str(broker_pid)+'/fd/'+str(sink_fd),os.O_WRONLY)
                    try:os.write(fd,b'UNMONITORED')
                    finally:os.close(fd)
                elif action=='native_open':
                    nr=LIB.seccomp_syscall_resolve_name(b'openat')
                    fd=LIBC.syscall(ctypes.c_long(nr),ctypes.c_int(-100),ctypes.c_char_p(sink_path.encode()),ctypes.c_int(os.O_WRONLY|os.O_APPEND),ctypes.c_int(0))
                    if fd<0:raise OSError(ctypes.get_errno(),'native openat')
                    try:os.write(fd,b'UNMONITORED')
                    finally:os.close(fd)
                elif action=='inherited_fd':os.write(leak_fd,b'UNMONITORED')
                elif action in ('request','delegate_request','replay'):
                    frame(request_fd,request)
                    if action=='replay':frame(request_fd,request)
                    report['request_sent']=True
                else:raise ValueError('unknown action')
                report.update(operation_returned=True,errno=None)
            except OSError as exc:report.update(operation_returned=False,errno=exc.errno)
            frame(result_fd,report)
        if action.startswith('delegate_'):
            pid=os.fork()
            if pid==0:
                attempt();os._exit(0)
            child_status(pid)
        else:attempt()
        os._exit(0)
    except BaseException as exc:
        try:frame(result_fd,{'setup_error':type(exc).__name__+': '+str(exc),'guard_installed':False})
        except BaseException:pass
        os._exit(91)

CASES=[
 ('M00_direct_guarded','direct','normal',True,None,False,0,0),
 ('M01_direct_unguarded_ablation','direct','normal',False,None,False,11,0),
 ('M02_delegated_direct','delegate_direct','normal',True,None,False,0,0),
 ('M03_proc_descriptor','proc_reopen','normal',True,None,False,0,0),
 ('M04_native_syscall','native_open','normal',True,None,False,0,0),
 ('M05_inherited_descriptor','inherited_fd','normal',True,None,True,0,0),
 ('M10_monitored_operation','request','normal',True,None,False,None,1),
 ('M11_monitored_delegation','delegate_request','normal',True,None,False,None,1),
 ('M20_monitor_absent','request','absent',True,None,False,0,0),
 ('M21_monitor_exit_before_ack','request','exit_after_record',True,None,False,0,1),
 ('M22_ack_without_record','request','ack_without_record',True,None,False,0,0),
 ('M23_wrong_ack','request','wrong_ack',True,None,False,0,1),
 ('M30_payload_mismatch','request','normal',True,'payload',False,0,0),
 ('M31_target_mismatch','request','normal',True,'target',False,0,0),
 ('M32_relation_violation','request','normal',True,None,False,0,0),
 ('M33_missing_source_evidence','request','normal',True,None,False,0,0),
 ('M40_replayed_request','replay','normal',True,None,False,None,1),
]

def one_case(root,row,ref,e0):
    name,action,mode,guard,mutate,leak,expected_size,expected_audits=row
    folder=root/name;folder.mkdir();sink=folder/'sink.bin';audit=folder/'monitor.jsonl';sink.write_bytes(b'');audit.write_bytes(b'')
    source_case='E20' if name=='M32_relation_violation' else 'E30' if name=='M33_missing_source_evidence' else 'E00'
    source_path=e0/'execution_03/workspace/cases'/source_case/'reference_input.json'
    source_envelope=ref.strict_json(source_path.read_bytes())
    assessment=ref.assess(source_envelope)
    evidence_admitted=(assessment.get('coverage_status')=='COMPLETE_FOR_DECLARED_CASE' and
        assessment.get('reference_relation_assessment')=='SATISFIED' and
        assessment.get('reference_source_assessment')=='JUSTIFIED_WITHIN_FIXTURE_BOUNDARY' and
        assessment.get('proof_applicability_assessment')=='JUSTIFIED_FOR_SELECTED_TARGET')
    write_json(folder/'source_assessment.json',assessment)
    request={'operation':'append','target':'scratch_sink_only','payload':'BOUND_MONITORED_EFFECT','request_id':name+'-one-shot','source_profile':'PD-SM-01-E1-MON1','source_envelope_sha256':digest(source_path.read_bytes()),'source_assessment_sha256':digest(enc(assessment)),'subject_sha256':digest(enc(assessment['selected_subject']))}
    submitted=dict(request)
    if mutate=='payload':submitted['payload']='DIFFERENT'
    if mutate=='target':submitted['target']='some_other_target'
    sinkfd=os.open(sink,os.O_WRONLY|os.O_APPEND);extra=os.dup(sinkfd) if leak else None
    qr,qw=os.pipe();rr,rw=os.pipe();mr,mw=os.pipe();ar,aw=os.pipe()
    pid_m=os.fork()
    if pid_m==0:monitor_main(mr,aw,str(audit),mode)
    pid_a=os.fork()
    if pid_a==0:worker_main(qw,rw,str(sink),os.getppid(),sinkfd,action,submitted,guard,extra)
    for fd in (qw,rw,mr,aw):os.close(fd)
    if extra is not None:os.close(extra)
    events=[];used=set();request_count=2 if action=='replay' else 1 if 'request' in action else 0
    for i in range(request_count):
        try:
            incoming=read_frame(qr)
            if enc(incoming)!=enc(request):
                events.append({'stage':'request_binding','accepted':False,'reason':'BOUND_REQUEST_MISMATCH'});continue
            if not evidence_admitted:
                events.append({'stage':'source_assessment','accepted':False,'reason':'SOURCE_CONDITION_NOT_JUSTIFIED'});continue
            if incoming['request_id'] in used:
                events.append({'stage':'replay','accepted':False,'reason':'ALREADY_CONSUMED'});continue
            used.add(incoming['request_id'])
            events.append({'stage':'request_binding','accepted':True,'request_sha256':digest(enc(incoming))})
            try:
                frame(mw,incoming);ack=read_frame(ar,0.5)
            except (OSError,EOFError,TimeoutError) as exc:
                events.append({'stage':'monitor','accepted':False,'reason':type(exc).__name__});continue
            if enc(ack)!=enc({'recorded':True,'request_sha256':digest(enc(incoming))}):
                events.append({'stage':'monitor','accepted':False,'reason':'ACK_MISMATCH'});continue
            records=[json.loads(x) for x in audit.read_bytes().splitlines()]
            required={'event':'INTENT','request':incoming,'request_sha256':digest(enc(incoming))}
            if records!=[required]:
                events.append({'stage':'monitor','accepted':False,'reason':'NO_EXACT_AUDIT_RECORD'});continue
            events.append({'stage':'monitor','accepted':True,'audit_sha256':digest(audit.read_bytes())})
            raw=incoming['payload'].encode()
            n=os.write(sinkfd,raw);os.fsync(sinkfd)
            events.append({'stage':'effect','bytes_written':n,'exact_payload':n==len(raw)})
        except BaseException as exc:events.append({'stage':'unexpected_error','error':repr(exc)})
    # Closing broker-to-monitor request pipe lets unused monitors exit (no blocking leak).
    os.close(mw)
    actor_record=read_frame(rr)
    sa=child_status(pid_a);sm=child_status(pid_m)
    for fd in (qr,rr,ar,sinkfd):os.close(fd)
    actual=sink.read_bytes();raw_audit=audit.read_bytes();observed_audit=[json.loads(x) for x in raw_audit.splitlines()]
    expected_payload=request['payload'].encode() if expected_size is None else b'UNMONITORED' if expected_size else b''
    required_errno=errno.EPERM if guard and action in ('direct','delegate_direct','proc_reopen','native_open','inherited_fd') else None
    tests={'monitor_normal_exit':sm['exit_code']==0,'sink_exact_bytes':actual==expected_payload,'audit_count':len(observed_audit)==expected_audits,'actor_normal_exit':sa['exit_code']==0,'actor_filter_loaded':actor_record.get('guard_installed')==guard,'exact_syscall_denial':required_errno is None or actor_record.get('errno')==required_errno,'no_unexpected_broker_error':all(e['stage']!='unexpected_error' for e in events)}
    if action=='replay':tests['duplicate_rejected']=any(x.get('reason')=='ALREADY_CONSUMED' for x in events)
    if expected_size is None:tests['monitored_useful_effect']=any(x['stage']=='effect' for x in events) and observed_audit[0]['request']==request
    record={'case_id':name,'source_input_relative_to_e0':str(source_path.relative_to(e0)),'source_input_sha256':digest(source_path.read_bytes()),'source_assessment_admitted':evidence_admitted,'request':request,'submitted':submitted,'actor_observation':actor_record,'actor_status':sa,'monitor_status':sm,'broker_trace':events,'sink_hex':actual.hex(),'sink_sha256':digest(actual),'audit_sha256':digest(raw_audit),'audit_records':observed_audit,'expected_sink_hex':expected_payload.hex(),'expected_audit_count':expected_audits,'checks':tests,'comparison':'MATCH' if all(tests.values()) else 'MISMATCH','authority_effect':'none','production_gate_eligible':False}
    write_json(folder/'RESULT.json',record);return record

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--output',required=True,type=Path);ap.add_argument('--e0-root',required=True,type=Path);a=ap.parse_args();a.output.mkdir(parents=True,exist_ok=False)
    if len(os.listdir('/proc/self/task')) != 1:
        write_json(a.output/'ENVIRONMENT_UNAVAILABLE.json',{'reason':'single-threaded supervisor required; invoke with -I -S -B'})
        return 2
    subject_path=a.e0_root/'pd_sm_01_e0/independent_reference.py'
    spec=importlib.util.spec_from_file_location('e0_evaluator_under_test',subject_path)
    ref=importlib.util.module_from_spec(spec);spec.loader.exec_module(ref)
    write_json(a.output/'PREEXECUTION.json',{'script_sha256':digest(Path(__file__).read_bytes()),'e0_evaluator_sha256':digest(subject_path.read_bytes()),'python':sys.version,'python_sha256':digest(Path(sys.executable).resolve().read_bytes()),'kernel':list(os.uname()),'uid':os.getuid(),'thread_count':len(os.listdir('/proc/self/task')),'python_flags':repr(sys.flags),'cases':[r[0] for r in CASES],'expected':[list(r) for r in CASES],'scope':'scratch-file MON1 only; no production authority'})
    signal.signal(signal.SIGALRM,lambda *_: (_ for _ in ()).throw(TimeoutError('case deadline')))
    records=[]
    for row in CASES:
        signal.alarm(4)
        try:
            result=one_case(a.output,row,ref,a.e0_root);records.append(result);print(row[0],result['comparison'],flush=True)
        finally:signal.alarm(0)
    summary={'status':'MATCH' if all(r['comparison']=='MATCH' for r in records) else 'MISMATCH','case_count':len(records),'matched':sum(r['comparison']=='MATCH' for r in records),'case_results':{r['case_id']:r['comparison'] for r in records},'authority_effect':'none','repository_write':False,'production_integration':False,'interpretation':'Real scratch-file effects and actual kernel denials; not full PULSEbox or continuous monitoring proof.'}
    write_json(a.output/'RESULTS.json',summary);print(json.dumps(summary));return 0 if summary['status']=='MATCH' else 1
if __name__=='__main__':raise SystemExit(main())
