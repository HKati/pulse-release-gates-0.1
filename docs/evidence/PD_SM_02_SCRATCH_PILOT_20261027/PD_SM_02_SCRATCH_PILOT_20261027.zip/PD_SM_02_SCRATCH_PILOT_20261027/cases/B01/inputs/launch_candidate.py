def candidate():
    rid = 'request-0'
    dst = 'scratch_sink_only'
    body = 'BOUND_MONITORED_EFFECT'
    proof_need = 'source.justified'
    principal = 'primary'
    actor(principal)
    bind_request(rid, dst, body)
    require_source(proof_need)
    require_request_match(rid)
    require_unused(rid)
    reserve(rid)
    broker_request(principal, rid)
    require_ack_match(rid)
    require_audit_match(rid)
    append_sink(rid)
