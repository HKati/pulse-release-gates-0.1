def candidate():
    request_token = 'request-0'
    target_name = 'scratch_sink_only'
    payload_value = 'BOUND_MONITORED_EFFECT'
    source_requirement = 'source.justified'
    actor_name = 'primary'
    actor(actor_name)
    bind_request(request_token, target_name, payload_value)
    require_source(source_requirement)
    require_request_match(request_token)
    require_unused(request_token)
    reserve(request_token)
    broker_request(actor_name, request_token)
    require_ack_present(request_token)
    require_audit_match(request_token)
    append_sink(request_token)
