def candidate():
    import os
    os.write(1, b"x")
