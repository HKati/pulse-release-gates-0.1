from __future__ import annotations
import argparse, hashlib, json
from pathlib import Path

EXPECTED_COMMIT='4cb5f7dbe00cfbaf5bd50f77423e4d671fa71905'
EXPECTED_ELIGIBLE={'P00','P01','P02','P04'}
EXPECTED_BLOBS={
 'README.md':'289d20c0903a6bd4e787aa91c3d14ba5765e6c0a',
 'check_impact.py':'3cef3a623bafff032f993c96357a29294068f0d4',
 'fixtures.json':'76542b40898d5c13deb9163addfed9fddb47ebe0',
 'profile.json':'1cd2e5928ff86e745deb8fb5a991e718448cfd7c',
 'run_local.py':'dbde9517f39082a854f31ef8b97be200c9efeb75',
 'source_model.py':'5c81b43f4bf5d02118058627c48371f8996b4d70',
 'test_preexecution.py':'2571640af4893df8ec1e364ac39d412c4a1401ce',
}

def sha(p:Path)->str:
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()

def blob(p:Path)->str:
 b=p.read_bytes();return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()

def main()->int:
 ap=argparse.ArgumentParser();ap.add_argument('root',nargs='?',type=Path,default=Path(__file__).resolve().parents[1]);a=ap.parse_args();root=a.root.resolve()
 assert root.is_dir() and not any(p.is_symlink() for p in root.rglob('*'))
 manifest=json.load(open(root/'MANIFEST.json'));assert sha(root/'MANIFEST.json')==(root/'MANIFEST.sha256').read_text().split()[0]
 listed={x['path']:x for x in manifest['files']};actual={p.relative_to(root).as_posix():p for p in root.rglob('*') if p.is_file() and p.name not in {'MANIFEST.json','MANIFEST.sha256'}}
 assert set(listed)==set(actual)
 for rel,p in actual.items():assert p.stat().st_size==listed[rel]['bytes'] and sha(p)==listed[rel]['sha256']
 ident=json.load(open(root/'source_identity.json'));assert ident['main_commit']==EXPECTED_COMMIT
 for n,d in EXPECTED_BLOBS.items():assert blob(root/'implementation_snapshot'/n)==d
 summary=json.load(open(root/'SUMMARY.json'));assert summary['implementation_commit']==EXPECTED_COMMIT
 assert summary['case_count']==24 and summary['classification_matches']==24
 assert summary['preflight_launch_eligible_count']==4 and summary['preflight_blocked_count']==20
 assert summary['authorized_native_scratch_execution_count']==4 and summary['blocked_before_output_creation_count']==20
 assert set(summary['eligible_case_ids'])==EXPECTED_ELIGIBLE
 for r in summary['cases']:
  cid=r['case_id'];c=root/'cases'/cid;assert r['classification_match'] and r['launch_invariant_ok']
  if cid in EXPECTED_ELIGIBLE:
   out=c/'scratch_output';result=json.load(open(out/'RESULT.json'));sink=(out/'sink.bin').read_bytes();audit=[json.loads(x) for x in (out/'monitor.jsonl').read_bytes().splitlines()]
   assert result['execution_observation_status']=='COMPLETED' and result['child_normal_exit'] and result['child_exit_code']==0
   assert result['child']['effects']==[{'bytes':22,'request_id':'request-0'}] and sink==b'BOUND_MONITORED_EFFECT'
   assert len(audit)==1 and audit[0]['event']=='INTENT' and audit[0]['request']=={'request_id':'request-0','target':'scratch_sink_only','payload':'BOUND_MONITORED_EFFECT'}
  else:
   assert r['launch_returncode']!=0 and not (c/'blocked_launch_output').exists()
 print(json.dumps({'status':'PASS','case_count':24,'eligible_completed':4,'blocked_before_output':20,'manifest_sha256':sha(root/'MANIFEST.json'),'authority_effect':'none'},sort_keys=True))
 return 0
if __name__=='__main__':raise SystemExit(main())
