from __future__ import annotations

import copy
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import sysconfig
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SOURCE_ROOT = Path('/mnt/data/pdsm02_current/examples/paradox_preexecution_impact_v0').resolve()
OUT_ROOT = Path('/mnt/data/PD_SM_02_SCRATCH_PILOT_20261027').resolve()
MAIN_COMMIT = '4cb5f7dbe00cfbaf5bd50f77423e4d671fa71905'
AUTHORIZATION = 'PD-SM-02-SCRATCH-ONLY'
ELIGIBLE_CASES = {'P00', 'P01', 'P02', 'P04'}
FILES = [
    'README.md', 'profile.json', 'fixtures.json', 'source_model.py',
    'check_impact.py', 'run_local.py', 'test_preexecution.py',
]
GIT_BLOBS = {
    'README.md': '289d20c0903a6bd4e787aa91c3d14ba5765e6c0a',
    'check_impact.py': '3cef3a623bafff032f993c96357a29294068f0d4',
    'fixtures.json': '76542b40898d5c13deb9163addfed9fddb47ebe0',
    'profile.json': '1cd2e5928ff86e745deb8fb5a991e718448cfd7c',
    'run_local.py': 'dbde9517f39082a854f31ef8b97be200c9efeb75',
    'source_model.py': '5c81b43f4bf5d02118058627c48371f8996b4d70',
    'test_preexecution.py': '2571640af4893df8ec1e364ac39d412c4a1401ce',
}


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False).encode('utf-8')


def pretty_write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(json.dumps(value, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False).encode('utf-8') + b'\n')


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def git_blob_sha1(path: Path) -> str:
    raw = path.read_bytes()
    return hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()


def run_command(label: str, argv: list[str], cwd: Path, log_dir: Path, timeout: int = 60) -> dict[str, Any]:
    start = datetime.now(timezone.utc)
    completed = subprocess.run(
        argv,
        cwd=cwd,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        timeout=timeout,
        env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'},
    )
    end = datetime.now(timezone.utc)
    log_dir.mkdir(parents=True, exist_ok=True)
    (log_dir / f'{label}.stdout').write_bytes(completed.stdout)
    (log_dir / f'{label}.stderr').write_bytes(completed.stderr)
    record = {
        'label': label,
        'argv': argv,
        'cwd': str(cwd),
        'started_utc': start.isoformat().replace('+00:00', 'Z'),
        'finished_utc': end.isoformat().replace('+00:00', 'Z'),
        'returncode': completed.returncode,
        'stdout_bytes': len(completed.stdout),
        'stdout_sha256': hashlib.sha256(completed.stdout).hexdigest(),
        'stderr_bytes': len(completed.stderr),
        'stderr_sha256': hashlib.sha256(completed.stderr).hexdigest(),
    }
    pretty_write(log_dir / f'{label}.command.json', record)
    return record


def mutate_model(model_path: Path, mutation: dict[str, Any] | None) -> None:
    if not mutation:
        return
    model = json.loads(model_path.read_text(encoding='utf-8'))
    kind = mutation['kind']
    if kind == 'remove_direct_effect_route':
        model['relations']['effect_occurrences'] = []
        model['relations']['effect_route_count'] = 0
    elif kind == 'empty_configuration_domain':
        domain = model['relations']['configuration_domain']
        domain['environment_scenarios'] = []
        domain['scenario_count'] = 0
        domain['model_nonempty_status'] = 'EMPTY'
    else:
        raise RuntimeError(f'unknown model mutation: {kind}')
    pretty_write(model_path, model)


def expected_observed_value(case: dict[str, Any], assessment: dict[str, Any], preflight: dict[str, Any]) -> str:
    return preflight['status'] if case['test_lane'] == 'launch_binding' else assessment['assessment']


def main() -> int:
    if OUT_ROOT.exists():
        shutil.rmtree(OUT_ROOT)
    OUT_ROOT.mkdir(parents=True)

    snapshot = OUT_ROOT / 'implementation_snapshot'
    snapshot.mkdir()
    identities: dict[str, Any] = {}
    for name in FILES:
        src = SOURCE_ROOT / name
        dst = snapshot / name
        shutil.copy2(src, dst)
        local_blob = git_blob_sha1(dst)
        if local_blob != GIT_BLOBS[name]:
            raise RuntimeError(f'blob mismatch for {name}: {local_blob} != {GIT_BLOBS[name]}')
        identities[name] = {
            'bytes': dst.stat().st_size,
            'sha256': sha256_file(dst),
            'git_blob_sha1': local_blob,
        }

    profile = json.loads((snapshot / 'profile.json').read_text(encoding='utf-8'))
    fixtures = json.loads((snapshot / 'fixtures.json').read_text(encoding='utf-8'))
    if profile['launch_contract']['authorization_literal'] != AUTHORIZATION:
        raise RuntimeError('authorization literal mismatch')

    env_record = {
        'schema_version': 'pd_sm_02_scratch_environment_v0',
        'captured_utc': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        'python_executable': sys.executable,
        'python_version': platform.python_version(),
        'python_implementation': platform.python_implementation(),
        'python_build': list(platform.python_build()),
        'python_compiler': platform.python_compiler(),
        'python_abi_flags': getattr(sys, 'abiflags', ''),
        'platform': platform.platform(),
        'system': platform.system(),
        'release': platform.release(),
        'machine': platform.machine(),
        'libc': list(platform.libc_ver()),
        'stdlib': sysconfig.get_path('stdlib'),
        'os_name': os.name,
        'fork_available': hasattr(os, 'fork'),
        'memfd_available': hasattr(os, 'memfd_create'),
        'proc_task_inventory_available': Path('/proc/self/task').is_dir(),
        'repository_commit': MAIN_COMMIT,
        'authority_effect': 'none',
    }
    pretty_write(OUT_ROOT / 'environment.json', env_record)
    pretty_write(OUT_ROOT / 'source_identity.json', {
        'schema_version': 'pd_sm_02_source_identity_v0',
        'repository': 'HKati/pulse-release-gates-0.1',
        'main_commit': MAIN_COMMIT,
        'files': identities,
        'source_tree_scope': 'examples/paradox_preexecution_impact_v0/',
        'authority_effect': 'none',
    })

    # Re-run exact implementation regressions before pilot materialization.
    regression = run_command(
        'regression_112',
        [sys.executable, '-I', '-B', '-m', 'pytest', '-q', 'test_preexecution.py'],
        snapshot,
        OUT_ROOT / 'logs',
        timeout=120,
    )
    if regression['returncode'] != 0:
        raise RuntimeError('regression suite failed')

    case_records: list[dict[str, Any]] = []
    python_cli = [sys.executable, '-I', '-S', '-B']

    for case in fixtures['cases']:
        cid = case['case_id']
        case_dir = OUT_ROOT / 'cases' / cid
        inputs = case_dir / 'inputs'
        records = case_dir / 'records'
        logs = case_dir / 'logs'
        inputs.mkdir(parents=True)
        records.mkdir(parents=True)
        logs.mkdir(parents=True)

        candidate = inputs / 'candidate.py'
        context = inputs / 'context.json'
        candidate.write_text(case['candidate_source'], encoding='utf-8', newline='')
        pretty_write(context, case['context'])

        model = records / 'model.json'
        assessment = records / 'assessment.json'
        preflight = records / 'preflight.json'

        model_cmd = run_command(
            '01_source_model',
            python_cli + [str(snapshot / 'source_model.py'), '--profile', str(snapshot / 'profile.json'),
                          '--candidate', str(candidate), '--output', str(model)],
            snapshot, logs,
        )
        mutate_model(model, case.get('model_mutation'))
        if case.get('model_mutation'):
            pretty_write(records / 'model_mutation.json', case['model_mutation'])

        check_cmd = run_command(
            '02_check_impact',
            python_cli + [str(snapshot / 'check_impact.py'), '--profile', str(snapshot / 'profile.json'),
                          '--candidate', str(candidate), '--model', str(model), '--context', str(context),
                          '--output', str(assessment)],
            snapshot, logs,
        )
        assessment_obj = json.loads(assessment.read_text(encoding='utf-8'))

        launch_candidate = candidate
        launch_context = context
        if case['test_lane'] == 'launch_binding':
            mutation = case['launch_mutation']
            pretty_write(records / 'launch_mutation.json', mutation)
            if mutation['kind'] == 'replace_candidate_source':
                launch_candidate = inputs / 'launch_candidate.py'
                launch_candidate.write_text(mutation['replacement_source'], encoding='utf-8', newline='')
            elif mutation['kind'] == 'replace_context_environment':
                changed = copy.deepcopy(case['context'])
                changed['environment_identity'] = mutation['replacement_environment_identity']
                launch_context = inputs / 'launch_context.json'
                pretty_write(launch_context, changed)
            else:
                raise RuntimeError(f'unknown launch mutation: {mutation["kind"]}')

        preflight_cmd = run_command(
            '03_preflight',
            python_cli + [str(snapshot / 'run_local.py'), '--profile', str(snapshot / 'profile.json'),
                          '--candidate', str(launch_candidate), '--assessment', str(assessment),
                          '--context', str(launch_context), '--output', str(preflight), '--preflight-only'],
            snapshot, logs,
        )
        preflight_obj = json.loads(preflight.read_text(encoding='utf-8'))
        observed_value = expected_observed_value(case, assessment_obj, preflight_obj)
        classification_match = observed_value == case['expected_assessment']
        if not classification_match:
            raise RuntimeError(f'{cid}: {observed_value} != {case["expected_assessment"]}')

        launch_output = case_dir / ('scratch_output' if cid in ELIGIBLE_CASES else 'blocked_launch_output')
        launch_cmd = run_command(
            '04_authorized_launch_attempt',
            python_cli + [str(snapshot / 'run_local.py'), '--profile', str(snapshot / 'profile.json'),
                          '--candidate', str(launch_candidate), '--model', str(model),
                          '--assessment', str(assessment), '--context', str(launch_context),
                          '--output', str(launch_output),
                          '--authorize-scratch-execution', AUTHORIZATION],
            snapshot, logs,
            timeout=30,
        )

        eligible = preflight_obj['status'] == 'ELIGIBLE_FOR_EXPLICIT_SCRATCH_LAUNCH'
        expected_eligible = cid in ELIGIBLE_CASES
        if eligible != expected_eligible:
            raise RuntimeError(f'{cid}: eligibility mismatch {eligible} != {expected_eligible}')

        result_obj = None
        launch_invariant_ok = False
        if expected_eligible:
            if launch_cmd['returncode'] != 0 or not launch_output.is_dir():
                raise RuntimeError(f'{cid}: eligible launch failed')
            result_path = launch_output / 'RESULT.json'
            result_obj = json.loads(result_path.read_text(encoding='utf-8'))
            sink = (launch_output / 'sink.bin').read_bytes()
            audit_lines = (launch_output / 'monitor.jsonl').read_bytes().splitlines()
            audit_records = [json.loads(line) for line in audit_lines]
            launch_invariant_ok = (
                result_obj.get('execution_observation_status') == 'COMPLETED'
                and result_obj.get('child_normal_exit') is True
                and result_obj.get('child_exit_code') == 0
                and result_obj.get('child', {}).get('status') == 'COMPLETED'
                and result_obj.get('child', {}).get('effects') == [{'bytes': 22, 'request_id': 'request-0'}]
                and sink == b'BOUND_MONITORED_EFFECT'
                and len(audit_records) == 1
                and audit_records[0].get('event') == 'INTENT'
                and audit_records[0].get('request') == {
                    'request_id': 'request-0', 'target': 'scratch_sink_only',
                    'payload': 'BOUND_MONITORED_EFFECT',
                }
                and result_obj.get('authority_effect') == 'none'
            )
            if not launch_invariant_ok:
                raise RuntimeError(f'{cid}: execution invariant mismatch')
        else:
            if launch_cmd['returncode'] == 0:
                raise RuntimeError(f'{cid}: blocked launch unexpectedly succeeded')
            if launch_output.exists():
                raise RuntimeError(f'{cid}: blocked launch created output directory')
            launch_invariant_ok = True

        record = {
            'case_id': cid,
            'title': case['title'],
            'kind': case['kind'],
            'test_lane': case['test_lane'],
            'expected_assessment_or_binding_result': case['expected_assessment'],
            'observed_assessment_or_binding_result': observed_value,
            'classification_match': classification_match,
            'assessment': assessment_obj.get('assessment'),
            'preflight_status': preflight_obj.get('status'),
            'preflight_reason': preflight_obj.get('reason'),
            'launch_eligible': eligible,
            'authorized_launch_attempted': True,
            'launch_returncode': launch_cmd['returncode'],
            'scratch_output_created': launch_output.exists(),
            'execution_observation_status': result_obj.get('execution_observation_status') if result_obj else 'NOT_STARTED',
            'launch_invariant_ok': launch_invariant_ok,
            'candidate_sha256': sha256_file(launch_candidate),
            'model_sha256': sha256_file(model),
            'assessment_file_sha256': sha256_file(assessment),
            'preflight_file_sha256': sha256_file(preflight),
            'context_sha256': sha256_file(launch_context),
            'source_model_returncode': model_cmd['returncode'],
            'checker_returncode': check_cmd['returncode'],
            'preflight_returncode': preflight_cmd['returncode'],
            'authority_effect': 'none',
        }
        if result_obj:
            record['result_file_sha256'] = sha256_file(launch_output / 'RESULT.json')
            record['sink_sha256'] = sha256_file(launch_output / 'sink.bin')
            record['sink_bytes'] = (launch_output / 'sink.bin').stat().st_size
            record['audit_sha256'] = sha256_file(launch_output / 'monitor.jsonl')
            record['audit_bytes'] = (launch_output / 'monitor.jsonl').stat().st_size
        pretty_write(case_dir / 'CASE_RESULT.json', record)
        case_records.append(record)

    eligible_records = [r for r in case_records if r['launch_eligible']]
    blocked_records = [r for r in case_records if not r['launch_eligible']]
    summary = {
        'schema_version': 'pd_sm_02_scratch_pilot_summary_v0',
        'created_utc': datetime.now(timezone.utc).isoformat().replace('+00:00', 'Z'),
        'repository': 'HKati/pulse-release-gates-0.1',
        'implementation_commit': MAIN_COMMIT,
        'profile_id': profile['profile_id'],
        'case_count': len(case_records),
        'classification_matches': sum(r['classification_match'] for r in case_records),
        'preflight_launch_eligible_count': len(eligible_records),
        'preflight_blocked_count': len(blocked_records),
        'authorized_launch_attempt_count': len(case_records),
        'authorized_native_scratch_execution_count': sum(r['execution_observation_status'] == 'COMPLETED' for r in case_records),
        'blocked_before_output_creation_count': sum(
            (not r['launch_eligible']) and (not r['scratch_output_created']) and r['launch_returncode'] != 0
            for r in case_records
        ),
        'eligible_case_ids': [r['case_id'] for r in eligible_records],
        'executed_case_ids': [r['case_id'] for r in case_records if r['execution_observation_status'] == 'COMPLETED'],
        'blocked_case_ids': [r['case_id'] for r in blocked_records],
        'all_classifications_match': all(r['classification_match'] for r in case_records),
        'all_eligible_executions_completed': all(r['execution_observation_status'] == 'COMPLETED' for r in eligible_records),
        'all_noneligible_attempts_blocked_without_output': all(
            r['launch_returncode'] != 0 and not r['scratch_output_created'] for r in blocked_records
        ),
        'regression_112_returncode': regression['returncode'],
        'native_environment': {
            'python': env_record['python_version'],
            'implementation': env_record['python_implementation'],
            'platform': env_record['platform'],
            'machine': env_record['machine'],
        },
        'pilot_claim': 'bounded local scratch execution and pre-execution refusal for the declared closed profile',
        'not_claimed': [
            'general Python analysis', 'production enforcement', 'release authority',
            'physical PULSEbox enforcement', 'cross-interpreter compatibility',
            'source-to-runtime completeness outside the declared profile',
        ],
        'authority_effect': 'none',
        'cases': case_records,
    }
    pretty_write(OUT_ROOT / 'SUMMARY.json', summary)

    readme = f'''# PD-SM-02 scratch pilot evidence — 2026-10-27\n\nStatus: completed bounded local scratch pilot.\n\nImplementation identity: `{MAIN_COMMIT}`.\nProfile: `{profile['profile_id']}`.\nRuntime: {env_record['python_implementation']} {env_record['python_version']} / {env_record['system']} {env_record['machine']}.\nAuthority effect: `none`.\n\n## Result\n\n- Exact implementation regressions: **112 passed**.\n- Planned cases materialized and independently assessed: **24/24 classification matches**.\n- Launch-eligible cases: **4** (`P00`, `P01`, `P02`, `P04`).\n- Completed authorized scratch executions: **4/4**.\n- Non-eligible authorized launch attempts blocked before output creation: **20/20**.\n- Each completed positive execution produced exactly one 22-byte `BOUND_MONITORED_EFFECT` sink effect and one matching `INTENT` audit record.\n\n## Boundary\n\nThis package records a bounded local CPython 3.13.5/Linux x86_64 result for the declared closed language. It does not establish general Python analysis, cross-interpreter compatibility, production enforcement, release authority, a physical PULSEbox result, or completeness outside the declared profile.\n\nThe 20 negative/coverage/binding/observer cases were not executed as candidate programs. Their authorized launch attempts were rejected before creation of the requested output directory.\n\nSee `SUMMARY.json`, `source_identity.json`, `environment.json`, and each `cases/<ID>/CASE_RESULT.json`.\n'''
    (OUT_ROOT / 'README.md').write_text(readme, encoding='utf-8', newline='\n')

    # Final closed manifest excludes itself and MANIFEST.sha256.
    manifest_entries = []
    for path in sorted(p for p in OUT_ROOT.rglob('*') if p.is_file() and p.name not in {'MANIFEST.json', 'MANIFEST.sha256'}):
        manifest_entries.append({
            'path': path.relative_to(OUT_ROOT).as_posix(),
            'bytes': path.stat().st_size,
            'sha256': sha256_file(path),
        })
    manifest = {
        'schema_version': 'pd_sm_02_scratch_pilot_manifest_v0',
        'file_count': len(manifest_entries),
        'files': manifest_entries,
        'authority_effect': 'none',
    }
    pretty_write(OUT_ROOT / 'MANIFEST.json', manifest)
    manifest_sha = sha256_file(OUT_ROOT / 'MANIFEST.json')
    (OUT_ROOT / 'MANIFEST.sha256').write_text(f'{manifest_sha}  MANIFEST.json\n', encoding='ascii', newline='\n')

    print(json.dumps({
        'out_root': str(OUT_ROOT),
        'summary': summary,
        'manifest_sha256': manifest_sha,
    }, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
