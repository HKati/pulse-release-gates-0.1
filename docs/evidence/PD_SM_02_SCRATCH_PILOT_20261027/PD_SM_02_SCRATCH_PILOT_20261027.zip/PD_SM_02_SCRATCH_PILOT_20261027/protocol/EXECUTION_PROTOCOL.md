# PD-SM-02 bounded scratch pilot execution protocol

Implementation identity: `4cb5f7dbe00cfbaf5bd50f77423e4d671fa71905`  
Profile: `PD-SM-02-preexecution-impact-v0`  
Execution date: 2026-10-27  
Authority effect: `none`

## Fixed sequence

1. Verify all seven implementation files against the Git blob identities of the
   merged `main` commit.
2. Copy those exact bytes into `implementation_snapshot/`.
3. Run the exact implementation regression suite and require `112 passed`.
4. Materialize each of the 24 declared fixture cases into a separate directory.
5. Build the source-derived model by invoking `source_model.py` as an isolated
   process. Apply only the two explicitly declared model-tamper fixtures after
   recording the generated model.
6. Invoke `check_impact.py` as a separate isolated process and retain the full
   assessment record, process exit, stdout and stderr.
7. Invoke `run_local.py --preflight-only` for every case. For the two launch
   binding cases, apply the declared source or environment substitution only
   after the original assessment has been produced.
8. Require all 24 observed classifications or binding outcomes to match the
   fixture obligations.
9. Invoke the owner-authorized scratch launch path for all 24 cases using the
   exact authorization literal declared in `profile.json`.
10. Permit candidate execution only where the launcher's own preflight returns
    `ELIGIBLE_FOR_EXPLICIT_SCRATCH_LAUNCH` and the independent checker replay is
    byte-equivalent to the supplied assessment.
11. For every eligible execution, require a normal child exit, exactly one
    `request-0` effect, the exact 22-byte sink payload
    `BOUND_MONITORED_EFFECT`, and exactly one matching `INTENT` audit record.
12. For every non-eligible case, require a nonzero launcher exit and absence of
    the requested output directory. Such cases are launch-refusal observations,
    not native candidate executions.
13. Preserve inputs, models, assessments, preflights, execution outputs, command
    records and raw stdout/stderr for each case.
14. Close the package with a SHA-256 manifest.

## Isolation and effects

The pilot ran only in the model working container on Linux x86_64 with CPython
3.13.5. Positive effects were written only to newly created case-local scratch
files inside this evidence package. No repository file, Git branch, workflow,
policy, gate registry, `status.json`, DOI or Software Heritage surface was
modified. No archived E1 program was executed.

## Claim boundary

The result supports only the declared closed-language profile and this recorded
runtime. It does not establish general Python-program analysis, cross-runtime
compatibility, production enforcement, release authority, physical PULSEbox
isolation, or source-to-runtime completeness outside the declared profile.

## Read-only package verification

After checksum-verifying and safely extracting the outer archive:

```sh
python3 -I -S -B protocol/verify_package.py .
```

Expected status: `PASS`, with 24 cases, four completed eligible scratch
executions and twenty blocked-before-output launch attempts.
