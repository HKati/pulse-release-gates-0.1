# PD-SM-02 scratch pilot evidence — 2026-10-27

Status: completed bounded local scratch pilot.

Implementation identity: `4cb5f7dbe00cfbaf5bd50f77423e4d671fa71905`.
Profile: `PD-SM-02-preexecution-impact-v0`.
Runtime: CPython 3.13.5 / Linux x86_64.
Authority effect: `none`.

## Result

- Exact implementation regressions: **112 passed**.
- Planned cases materialized and independently assessed: **24/24 classification matches**.
- Launch-eligible cases: **4** (`P00`, `P01`, `P02`, `P04`).
- Completed authorized scratch executions: **4/4**.
- Non-eligible authorized launch attempts blocked before output creation: **20/20**.
- Each completed positive execution produced exactly one 22-byte `BOUND_MONITORED_EFFECT` sink effect and one matching `INTENT` audit record.

## Boundary

This package records a bounded local CPython 3.13.5/Linux x86_64 result for the declared closed language. It does not establish general Python analysis, cross-interpreter compatibility, production enforcement, release authority, a physical PULSEbox result, or completeness outside the declared profile.

The 20 negative/coverage/binding/observer cases were not executed as candidate programs. Their authorized launch attempts were rejected before creation of the requested output directory.

See `SUMMARY.json`, `source_identity.json`, `environment.json`, and each `cases/<ID>/CASE_RESULT.json`.
