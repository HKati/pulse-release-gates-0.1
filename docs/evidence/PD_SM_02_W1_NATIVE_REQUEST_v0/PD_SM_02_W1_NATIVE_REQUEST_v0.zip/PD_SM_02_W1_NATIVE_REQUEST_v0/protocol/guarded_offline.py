#!/usr/bin/env python3
"""Record one offline W1 operation while refusing process and network creation.

This preparation/review helper has no execute, Docker, or authorization mode.
The repository controller remains the request/record validator.
"""
from __future__ import annotations

import argparse
import contextlib
import hashlib
import io
import json
from pathlib import Path
import platform
import runpy
import sys

CONTROLLERS = {
    "prepare": ("run_paradox_w1_native_v0.py", "bff5759aaee32e93362829084b8867fb078d1e390c31aaad73c7255493d1aa3f"),
    "verify": ("run_paradox_w1_native_v0.py", "bff5759aaee32e93362829084b8867fb078d1e390c31aaad73c7255493d1aa3f"),
    "verify-admission": ("run_paradox_w1_admission_v0.py", "3bc509339b0a746f4a7f27695feac1b90677f5dd04df727e419f787d96c28e54"),
}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--operation", choices=tuple(CONTROLLERS), required=True)
    parser.add_argument("--controller", type=Path, required=True)
    parser.add_argument("--receipt-dir", type=Path, required=True)
    parser.add_argument("controller_args", nargs=argparse.REMAINDER)
    args = parser.parse_args()
    forwarded = args.controller_args
    if forwarded[:1] == ["--"]:
        forwarded = forwarded[1:]
    expected_name, expected_sha = CONTROLLERS[args.operation]
    controller = args.controller.resolve(strict=True)
    if controller.name != expected_name or hashlib.sha256(controller.read_bytes()).hexdigest() != expected_sha:
        parser.error("reviewed controller identity mismatch")
    args.receipt_dir.mkdir(parents=True, exist_ok=False)
    denied = []

    def audit(event, values):
        if (event.startswith("subprocess.") or event.startswith("socket.")
                or event in {"os.system", "os.fork", "os.forkpty", "os.exec", "os.posix_spawn"}
                or event.startswith("os.spawn")):
            denied.append(event)
            raise RuntimeError("offline operation refused: " + event)

    sys.dont_write_bytecode = True
    sys.addaudithook(audit)
    stdout, stderr = io.StringIO(), io.StringIO()
    argv = [str(controller), args.operation, *forwarded]
    old_argv = sys.argv
    rc = 0
    error = None
    try:
        sys.argv = argv
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            try:
                runpy.run_path(str(controller), run_name="__main__")
            except SystemExit as exc:
                rc = exc.code if isinstance(exc.code, int) else (0 if exc.code is None else 1)
            except Exception as exc:
                rc = 1
                error = type(exc).__name__ + ": " + str(exc)
    finally:
        sys.argv = old_argv
    (args.receipt_dir / "stdout.json").write_text(stdout.getvalue(), encoding="utf-8")
    (args.receipt_dir / "stderr.txt").write_text(stderr.getvalue(), encoding="utf-8")
    (args.receipt_dir / "exitcode.txt").write_text(str(rc) + "\n", encoding="ascii")
    receipt = {
        "schema_version": "pd_sm_02_w1_offline_operation_receipt_v0",
        "operation": args.operation,
        "controller_sha256": expected_sha,
        "argv": argv,
        "controller_python": platform.python_version(),
        "exit_code": rc,
        "exception": error,
        "denied_process_or_socket_events": denied,
        "guard_scope": "Python audit process/network events in this offline operation; not a platform sandbox or external attestation",
        "execution_authorization_granted": False,
        "authority_effect": "none",
    }
    (args.receipt_dir / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"operation": args.operation, "exit_code": rc, "denied_events": denied, "receipt_dir": str(args.receipt_dir)}))
    return rc


if __name__ == "__main__":
    raise SystemExit(main())
