# Actual preparation and review procedure

This is an offline preparation/replay procedure. The native controller and its four helpers are copied unchanged from the reviewed source. No candidate is imported or invoked by these operations.

## 1. Source identification

1. Reuse the already verified admission run `41362257003`, attempt 1, and its original artifact `13105004906`.
2. Read the reviewed commit/tree and selected file identities from GitHub. The root tree is `f46fbd1ad35dd9251fb0b0e4377a29e8db240dd0` at commit `6343d4e54ec8628f033400518fe08a81aa75d9b9`.
3. Reuse existing local committed file bytes only after comparing the Git blob SHA-1 and byte length with those recorded identities. Record the SHA-256 as well. This produced the twenty rows in `provenance/REVIEWED_SOURCE_FILES.json`.
4. Put those bytes in a separate preparation snapshot. No existing worktree is reset or edited. The native controller reads its five-file tool closure from its own directory; its `--repo-root` selects the frozen input files.

The source record is an observed repository lookup and byte comparison, not a new upstream attestation. The final request's v0 `preparation_base` constant is preserved; the current-commit link is kept in the outer provenance record.

## 2. Request preparation

The actual preparation used CPython 3.11.16, `-I -S -B`, and `guarded_offline.py --operation prepare`. The helper invokes only the named offline CLI branch with Python process/network audit events denied. Its exact arguments, output, exit code and denied-event list are in `validation/prepare/`.

The equivalent native CLI is:

```sh
python3 -I -S -B /path/to/reviewed-source/tools/run_paradox_w1_native_v0.py prepare \
  --repo-root /path/to/reviewed-source \
  --output /path/outside-source/fresh-native-package \
  --image-id sha256:38e57556b63539e63344b97f802e7cbd85b70e2087ee703e360fcdfe337cbbb3 \
  --run-id pd-sm-02-w1-native-after-41362257003-01
```

The output path must not exist and must be outside the reviewed source directory. Reproduction of a preparation is not an authorization to duplicate an execution attempt.

The actual result was `REQUEST_PREPARED_NOT_AUTHORIZED`. Rehashing the canonical `request.json` produced:

```text
655910d465b68cd58425d10d2e1bf6050079a47ac4468422468b03560442383a
```

The strict native directory contains twenty payloads plus the request. Exact case order, image ID, one-attempt budget, retry=false, no CLAIM/capture and zero-execution status were checked separately.

## 3. Positive request verification

From the root of this unpacked delivery, the existing offline verifier can be invoked as follows:

```sh
python3 -I -S -B package/tools/run_paradox_w1_native_v0.py verify \
  --package package \
  --request-sha256 655910d465b68cd58425d10d2e1bf6050079a47ac4468422468b03560442383a
```

Expected result: `REQUEST_VALID_NOT_AUTHORIZED`, exit 0. This verifies the source closure, request, fixed selection and every bound payload. It starts no container or candidate. The `-B` flag prevents extra bytecode files inside the strict package. Write any new receipt outside that package and outside an immutable copy of this delivery.

The actual guarded verification receipt is under `validation/native-request/`. Its controller is the copy delivered in `package/tools/`.

## 4. Prior admission preservation and replay

The admission ZIP was downloaded from GitHub and checked against the provider-recorded size and SHA-256. The included ZIP is that original archive, not a reconstruction or renamed preparation wrapper.

Its admission request digest is:

```text
1ea09a5a26cd2d375183dabbc3e7c8b3f64d257132f410ae65313418293fa8c2
```

Replay uses the six reviewed admission tool files and `verify-admission` against the ZIP's extracted inner `package/`. The six tools were previously compared with the actual run's repository source. During this preparation `guarded_offline.py --operation verify-admission` recorded a successful replay in `validation/admission-replay/`. The request and source identities, exact 76-member admission inventory, both controls, command bindings and cleanup records were accepted. Its status remains `ADMISSION_COMPLETED_UNATTESTED` / `NOT_EXTERNALLY_VERIFIED`.

No historical archive program is executed. Paths recorded in original host evidence remain data; they are not opened as instructions to the replay host.

## 5. Bounded negative controls

`check_negative_controls.py` is the exact method used on disposable copies. It verifies the original 21-file package before and after, with actual results in `validation/negative-controls.json`.

The only mutations are in those copies: a wrong expected request digest; an added LF in P00's case-input file; and swapped P00/N01 request entries with a correctly recalculated request digest. All three were refused, by different binding checks. No original package byte was changed and no process/network/runtime/Docker entry was attempted by the verifier.

## 6. Delivery archive verification

The delivery uses an outer closed length/hash manifest. It excludes only `MANIFEST.json` and `MANIFEST.sha256` from its own member list. The native directory remains the separate, strict 21-file package.

An assembled ZIP is extracted safely to another path. The extracted native package is verified using its own copied controller and the same request SHA-256; the original prior-admission ZIP is rehashed there. `validation/relocated-package/` retains the actual successful offline verification receipt. The final ZIP is then rebuilt with that receipt, unpacked again, and checked for exact manifest membership, matching bytes, unchanged native request and successful native verification. This final read-only check does not alter the artifact or add an execution claim.

## 7. Subsequent live execution boundary

There is no native W1 Actions workflow at the reviewed commit. The owner normally uses GitHub Actions; the next hosted implementation must be reviewed separately. It must consume this exact request, preserve its fixed case sequence/budget, acquire the pinned image, repeat the native path's live controls and retain complete or stopped evidence.

The existing `execute` interface requires a separately supplied `I_AUTHORIZE_PD_SM_02_W1:<exact-native-request-digest>` acknowledgment. Neither this procedure, the successful admission, the offline verification nor the preparation receipts supply that authorization. A future run uses a fresh writable package copy; the original preparation archive remains preserved.
