#!/usr/bin/env python3
"""Check only the frozen W1 request and three offline rejection controls.

This script never calls the native execution path, imports the candidate runtime,
or starts a child process. Mutations are confined to fresh disposable copies.
Run with Python -I -S -B. Both report and scratch destinations must be new.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import stat
import sys


EXPECTED_SHA256 = "655910d465b68cd58425d10d2e1bf6050079a47ac4468422468b03560442383a"
EXPECTED_RUN_ID = "pd-sm-02-w1-native-after-41362257003-01"
EXPECTED_IMAGE_ID = "sha256:38e57556b63539e63344b97f802e7cbd85b70e2087ee703e360fcdfe337cbbb3"
EXPECTED_ORDER = ["P00", "N01", "N07", "N08", "N02"]
BUNDLE = Path(__file__).resolve().parents[1]
PACKAGE = BUNDLE / "package"


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def inventory(root):
    files = {}
    directories = []
    for path in sorted(root.rglob("*")):
        name = path.relative_to(root).as_posix()
        mode = path.lstat().st_mode
        if stat.S_ISDIR(mode):
            directories.append(name)
        elif stat.S_ISREG(mode):
            raw = path.read_bytes()
            files[name] = {"bytes": len(raw), "sha256": digest(raw)}
        else:
            raise ValueError("nonregular_package_entry:" + name)
    return {"files": files, "directories": directories}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scratch-root", type=Path, default=BUNDLE.parent / "negative-controls")
    parser.add_argument("--report", type=Path, default=BUNDLE / "validation/negative-controls.json")
    args = parser.parse_args()
    sys.dont_write_bytecode = True
    started = datetime.now(timezone.utc).isoformat()
    package = PACKAGE.resolve(strict=True)
    scratch = args.scratch_root.absolute()
    report_path = args.report.absolute()
    if (scratch.exists() or scratch.is_symlink() or report_path.exists()
            or report_path.is_symlink()):
        raise ValueError("fresh_scratch_and_report_required")
    if (scratch.resolve().is_relative_to(package) or package.is_relative_to(scratch.resolve())
            or report_path.resolve().is_relative_to(package)):
        raise ValueError("original_package_must_remain_read_only")

    forbidden_attempts = []
    blocked_events = {"subprocess.Popen", "os.system", "os.fork", "os.forkpty",
                      "os.posix_spawn", "os.exec", "os.spawn", "pty.spawn"}

    def audit(name, values):
        runtime_exec = name == "exec" and (
            values[0].co_filename.endswith("paradox_w1_native_runtime_v0.py")
            or values[0].co_filename == "<w1-exact-utf8-candidate>")
        if name in blocked_events or name.startswith("socket.") or runtime_exec:
            forbidden_attempts.append(name)
            raise RuntimeError("offline_control_forbids:" + name)

    sys.addaudithook(audit)
    before = inventory(package)
    raw = (package / "request.json").read_bytes()
    request = json.loads(raw)
    expected_files = set(request["payloads"]) | {"request.json"}
    expected_directories = sorted({str(parent) for name in expected_files
                                   for parent in Path(name).parents if str(parent) != "."})
    original_checks = {
        "request_sha256_matches": digest(raw) == EXPECTED_SHA256,
        "canonical_request": canonical(request) == raw,
        "run_id_matches": request["run_id"] == EXPECTED_RUN_ID,
        "image_id_matches": request["image_id"] == EXPECTED_IMAGE_ID,
        "case_order_matches": [row["case_id"] for row in request["cases"]] == EXPECTED_ORDER,
        "twenty_payloads": len(request["payloads"]) == 20,
        "exact_twenty_one_regular_files": len(before["files"]) == 21 and set(before["files"]) == expected_files,
        "exact_expected_directories": before["directories"] == expected_directories,
        "payload_inventory_matches": all(before["files"].get(name) == binding
                                         for name, binding in request["payloads"].items()),
        "no_claim": not (package / "CLAIM.json").exists(),
        "no_capture": not (package / "capture").exists(),
        "execution_not_authorized": request["execution_authorized"] is False,
        "authority_none": request["authority_effect"] == "none",
        "single_attempt_no_retry": type(request["attempt"]) is int and request["attempt"] == 1
                                   and request["automatic_retry"] is False,
        "candidate_budget_five": type(request["maximum_candidate_invocations"]) is int
                                 and request["maximum_candidate_invocations"] == 5,
    }
    if not all(original_checks.values()):
        raise ValueError("original_package_precondition_failed:" +
                         ",".join(name for name, ok in original_checks.items() if not ok))

    controller = package / "tools/run_paradox_w1_native_v0.py"
    spec = importlib.util.spec_from_file_location("offline_native_negative_controls", controller)
    native = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(native)

    def forbidden(*args, **kwargs):
        forbidden_attempts.append("native_execution_or_docker_entrypoint")
        raise RuntimeError("offline_control_forbids_native_execution_or_docker")

    native.execute = forbidden
    native.one_container = forbidden
    native.B.Docker = forbidden
    scratch.mkdir(mode=0o700)
    controls = []
    specifications = [
        ("wrong_expected_digest", "request_digest_mismatch"),
        ("changed_case_payload", "payload_binding:cases/P00.json"),
        ("reordered_cases_rehashed_request", "request_case_inventory"),
    ]
    for name, expected_reason in specifications:
        copied = scratch / name
        shutil.copytree(package, copied)
        supplied_sha = EXPECTED_SHA256
        if name == "wrong_expected_digest":
            supplied_sha = "0" + EXPECTED_SHA256[1:]
            mutation = "Only the supplied expected digest changes; all copied package bytes are unchanged."
        elif name == "changed_case_payload":
            target = copied / "cases/P00.json"
            target.write_bytes(target.read_bytes() + b"\n")
            mutation = "Append one LF to cases/P00.json; request bytes and supplied request digest stay unchanged."
        else:
            target = copied / "request.json"
            changed = json.loads(target.read_bytes())
            changed["cases"][0], changed["cases"][1] = changed["cases"][1], changed["cases"][0]
            changed_raw = canonical(changed)
            target.write_bytes(changed_raw)
            supplied_sha = digest(changed_raw)
            mutation = "Swap request cases P00 and N01, recanonicalize request.json, and supply its new SHA256."
        mutated = inventory(copied)
        changed_files = sorted(path for path, binding in mutated["files"].items()
                               if binding != before["files"].get(path))
        item = {"control": name, "mutation": mutation, "disposable_copy": str(copied),
                "changed_files": changed_files, "supplied_request_sha256": supplied_sha,
                "actual_request_sha256": digest((copied / "request.json").read_bytes()),
                "expected_rejection_reason": expected_reason}
        try:
            native.validate_package(copied, supplied_sha)
        except Exception as exc:
            item.update(accepted=False, exception_type=type(exc).__name__, reason=str(exc),
                        passed=isinstance(exc, native.O.CaptureError) and str(exc) == expected_reason)
        else:
            item.update(accepted=True, exception_type=None, reason=None, passed=False)
        item["no_claim_or_capture_created"] = (not (copied / "CLAIM.json").exists()
                                                and not (copied / "capture").exists())
        item["verifier_left_copy_unchanged"] = inventory(copied) == mutated
        item["passed"] = (item["passed"] and item["no_claim_or_capture_created"]
                          and item["verifier_left_copy_unchanged"])
        controls.append(item)

    after = inventory(package)
    unchanged = before == after
    all_passed = all(item["passed"] for item in controls) and unchanged and not forbidden_attempts
    result = {
        "schema_version": "pd_sm_02_w1_native_offline_negative_validation_v0",
        "status": "PASSED" if all_passed else "FAILED",
        "started_at_utc": started, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
        "python_version": sys.version, "python_executable": sys.executable,
        "method_script_sha256": digest(Path(__file__).read_bytes()),
        "controller_source_sha256": digest(controller.read_bytes()),
        "request_sha256": EXPECTED_SHA256, "run_id": EXPECTED_RUN_ID,
        "original_package": str(package), "original_checks": original_checks,
        "original_inventory_before": before, "original_inventory_after": after,
        "original_package_unchanged": unchanged, "controls": controls,
        "forbidden_operation_attempts": forbidden_attempts,
        "new_candidate_executions": 0, "execution_authorized": False,
        "native_witness_observed": None, "containment_observed": None,
        "authority_effect": "none",
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open("x", encoding="utf-8") as stream:
        json.dump(result, stream, sort_keys=True, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")
    print(json.dumps({"status": result["status"], "controls_passed": sum(x["passed"] for x in controls),
                      "controls_total": len(controls), "original_package_unchanged": unchanged,
                      "new_candidate_executions": 0, "report": str(report_path)}, sort_keys=True))
    return 0 if all_passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
