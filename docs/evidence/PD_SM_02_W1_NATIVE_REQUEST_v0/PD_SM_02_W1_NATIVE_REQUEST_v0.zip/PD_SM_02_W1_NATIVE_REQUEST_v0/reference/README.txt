These are unmodified reference-source copies from reviewed commit
6343d4e54ec8628f033400518fe08a81aa75d9b9.

Their historical preparation bases and NOT_RUN / NOT_SELECTED statements
retain the original bytes and describe those documents' delivery state.
Use the outer README and provenance records for this package's current state.
Repository-relative links in these original copies refer to the upstream
repository layout; the pinned upstream URLs are provided in the outer README.
