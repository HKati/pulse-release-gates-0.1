# PD-SM-02-W1 — final native request preparation v0

Status: **REQUEST_VALID_NOT_AUTHORIZED**. Five native cases are prepared; their new execution status is **NOT_RUN**.

This package freezes the next W1 diagnostic request after the successful, candidate-free environment admission. It contains the complete native request and its twenty payloads, the original admission artifact, source provenance, actual offline validation receipts and the preparation/review procedure.

## 1. Exact request

| Item | Value |
|---|---|
| Reviewed repository | `HKati/pulse-release-gates-0.1` |
| Reviewed source commit | `6343d4e54ec8628f033400518fe08a81aa75d9b9` |
| Request file | `package/request.json` |
| Request SHA-256 | `655910d465b68cd58425d10d2e1bf6050079a47ac4468422468b03560442383a` |
| Request run ID | `pd-sm-02-w1-native-after-41362257003-01` |
| Attempt / candidate budget | Attempt 1; at most five invocations, once per case |
| Case order | `P00`, `N01`, `N07`, `N08`, `N02` |
| Required container runtime | CPython 3.13.5, Linux x86_64 |
| Exact local image/config ID | `sha256:38e57556b63539e63344b97f802e7cbd85b70e2087ee703e360fcdfe337cbbb3` |
| Image pull reference | `docker.io/library/python@sha256:a7cb177dc60dfa77b223192cd0d9e6ce1aac7cf9a569023d68e7c91b6371a718` |
| Automatic retry | `false` |
| Execution authorization | `false` |
| Authority effect | `none` |

The local image ID and registry manifest digest identify different objects. The native request binds the local image ID shown above. It does not accept a moving tag and its execution adapter uses `--pull=never`.

The reviewed source commit and all selected repository-file identities are recorded in `provenance/REVIEWED_SOURCE_FILES.json`. Twenty existing source/reference/license files were checked against Git blob identities obtained from that exact commit. Fifteen of those repository files supply the native tools and frozen inputs; five case-input files are deterministically derived from the preserved selection.

## 2. Prior admission and the next measurement

The prior [admission run 41362257003, attempt 1](https://github.com/HKati/pulse-release-gates-0.1/actions/runs/41362257003) completed at the reviewed source commit. Both `probe-time` and `probe-output` completed and replayed, with zero candidate invocations.

Its original archive is included byte-for-byte:

```text
evidence/pd-sm-02-w1-admission-41362257003-1.zip
bytes: 99214
SHA-256: 95347f71c309222205bb439ab4fc20b2a897194a70e5c30bfdd08372d72617fc
```

Its final status was `ADMISSION_COMPLETED_UNATTESTED`. A fresh offline check during this preparation returned `ADMISSION_RECORDS_REPLAYED` with that same admission status and 76 manifest members. The receipt is retained under `validation/admission-replay/`.

This evidence establishes the recorded environment's two control results within the reviewed implementation's trust assumptions. A later native acquisition uses a new host instance and must perform its own live readiness, timeout and output controls. The prior admission grants no candidate-execution permission and supplies no native case result.

## 3. Five preregistered expectations

The following are the unchanged predictions from the frozen selection. They are not newly observed results.

| Order | Case | Diagnostic role and expected observation |
|---:|---|---|
| 1 | P00 | Positive control: one 22-byte effect, preceded by matching intent persistence and ACK. |
| 2 | N01 | Primary witness: one 22-byte effect without a monitor request, intent, ACK or audit support. |
| 3 | N07 | Primary witness: two actual writes, 44 bytes total, following one reservation and one intent. |
| 4 | N08 | Primary witness: the write completes before the monitor request; later intent/ACK cannot repair the earlier unsupported prefix. |
| 5 | N02 | Primitive-refusal control: `direct_sink_write` refuses with `direct_effect_route_not_admitted`; zero effects. |

The experiment tests native correspondence for these fixed cases and the selected healthy scenario. It does not implement general cyclic fault-propagation recognition. The ordinary pre-execution admission lane and its refusals remain unchanged; the diagnostic native path is separate and requires its own exact-request authorization.

The two benign supervision controls precede P00 on the actual execution host. A failed control, positive control, observation, cleanup or prediction check stops the remaining plan. Unstarted cases stay `NOT_RUN`; incomplete observations remain incomplete. There is no automatic retry, resume, substitution or top-up.

## 4. Actual preparation and validation

The existing native controller produced `REQUEST_PREPARED_NOT_AUTHORIZED`. Its verifier then produced `REQUEST_VALID_NOT_AUTHORIZED` using the delivered tool files. Preparation and verification ran under CPython 3.11.16; this is the offline controller's version, not a new 3.13.5 native runtime observation.

The preparation/review runner refused process and network audit events. No such operation was attempted. The strict native package has exactly **21 regular files**: twenty payloads and `request.json`; it has no `CLAIM.json`, `capture/`, symlink or generated bytecode.

Three disposable-copy negative controls were performed:

| Modified input | Actual refusal |
|---|---|
| Wrong expected request digest | `request_digest_mismatch` |
| Changed P00 case payload | `payload_binding:cases/P00.json` |
| Swapped P00/N01 order, with the request correctly rehashed | `request_case_inventory` |

All three refused the change. The original request package's before/after inventory remained identical. The final ZIP is additionally unpacked into a different directory and verified from that unpacked copy before delivery. Actual receipts and exact check methods are included in `validation/` and `protocol/`.

No native candidate, Docker container, image pull, CI rerun, workflow dispatch or remote repository mutation was performed while creating this package.

## 5. Source identities and historical fields

The native v0 schema has no field for the current reviewed Git commit. Its `preparation_base` remains the frozen implementation constant `2890469ee82333f4d34872bbe711cda6ad9b49aa`. The preserved checker/source binding has its own historical source reference. These fields have not been rewritten.

The link to the actual reviewed commit `6343d4e...`, the prior admission, the selected image and this final request digest is recorded outside the strict native package in `provenance/REQUEST_REVIEW.json`. This companion record is a review/provenance record; it does not alter the controller's schema or create a new authority decision.

Likewise, historical `NOT_RUN`, `NOT_SELECTED` and similar fields inside frozen inputs/reference documents retain their original bytes. The current preparation status is stated in this README and the companion records. Historical source files and original archives are data to preserve, not instructions to execute.

## 6. Package layout

| Path | Purpose |
|---|---|
| `START_HU.txt` | Hungarian owner handoff. |
| `package/` | The strict, unchanged native request and its twenty bound payloads. |
| `REQUEST_SHA256.txt` | Digest of `package/request.json`. |
| `provenance/` | Reviewed source lookup, native request review and prior admission binding. |
| `evidence/` | The unmodified original admission ZIP. |
| `validation/` | Actual preparation, verification, admission replay and negative-control receipts. |
| `protocol/` | Exact preparation/validation method and offline-only helpers. |
| `reference/` | Byte-identical historical implementation/reference documents and selected admission target. |
| `MANIFEST.json` | Length and SHA-256 for every delivered file except the manifest and its checksum. |
| `MANIFEST.sha256` | SHA-256 of the outer manifest. |
| `LICENSE` | Unmodified repository license. |

Do not place notes or receipts inside `package/`; its validator rejects extra files. Keep the original preparation ZIP unchanged. A future authorized capture must use a separate working copy and be preserved as a new capture artifact.

## 7. Operational handoff

The offline request is complete and ready for owner review. The reviewed repository contains the native controller but **does not contain a hosted native W1 execution workflow**. The existing manual admission workflow cannot accept this native request or execute its five cases.

For the owner's GitHub Actions operating route, the next implementation task is a separately reviewed manual native runner that consumes these exact request bytes, acquires the pinned image, enforces owner/source/request identity, preserves failures, and publishes the original capture. This package does not add or dispatch that workflow.

The later native `execute` interface also requires the explicit literal `I_AUTHORIZE_PD_SM_02_W1:<exact native request digest>`. Delivery and verification of this request do not supply that authorization. A concrete hosted execution path must be reviewable before any live-run decision.

Primary source: [native acquisition implementation at the reviewed commit](https://github.com/HKati/pulse-release-gates-0.1/blob/6343d4e54ec8628f033400518fe08a81aa75d9b9/docs/experiments/PD_SM_02_W1_NATIVE_CAPTURE_v0.md). The [separate admission document](https://github.com/HKati/pulse-release-gates-0.1/blob/6343d4e54ec8628f033400518fe08a81aa75d9b9/docs/experiments/PD_SM_02_W1_ADMISSION_v0.md) defines the boundary between the completed environment admission and the later five-case native experiment.
