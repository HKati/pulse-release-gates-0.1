#!/usr/bin/env python3
# Pulse Paradox Gate CLI – evaluates metrics against policy and exits fail-closed in active mode.
import os, sys, json, argparse, statistics, time

POLICY_DEFAULT = "pulse/gates/paradox/policy.yaml"
LOG_DEFAULT = "logs/decision_log.ndjson"
ARTIFACT_OUT = "artifacts/pulse_paradox_gate_summary.json"

def load_policy(path):
    th = {
        "paradox_density_max": 0.005,
        "settle_time_p95_ms": 50.0,
        "downstream_error_rate_max": 0.002,
    }
    if not os.path.exists(path):
        return th
    try:
        import yaml  # optional
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        th.update({k: float(data.get(k, th[k])) for k in th.keys()})
    except Exception:
        # minimal line parser: key: value
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                if ":" in line:
                    k, v = line.split(":", 1)
                    k = k.strip(); v = v.strip()
                    if k in th:
                        try:
                            th[k] = float(v)
                        except: pass
    return th

def pctl(vals, p):
    if not vals: return 0.0
    vals = sorted(vals)
    i = max(0, min(len(vals)-1, int(round((p/100.0)*(len(vals)-1)))))
    return float(vals[i])

def derive_from_log(path):
    # Produce rough metrics from DecisionLog NDJSON if available.
    keys_all, keys_p = set(), set()
    start_q = {}
    durations = []
    if not os.path.exists(path):
        return None
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line: continue
            try:
                e = json.loads(line)
            except Exception:
                continue
            k = e.get("key"); a = e.get("action"); ts = e.get("ts_ms", 0)
            if not k: continue
            keys_all.add(k)
            if a in ("ENTER_Q", "ENTER_P", "ENTER_O"):
                keys_p.add(k)
            if a == "ENTER_Q":
                start_q[k] = ts
            if a == "MERGE_TO_R" and k in start_q:
                dt = max(0, ts - start_q.pop(k))
                durations.append(dt)
    density = (len(keys_p) / max(1, len(keys_all)))
    settle_p95 = pctl(durations, 95)
    return {
        "paradox_density": float(density),
        "settle_time_p95_ms": float(settle_p95),
        "downstream_error_rate": 0.0,  # not derivable from this log
        "observations": {
            "keys_touched": len(keys_all),
            "keys_with_paradox": len(keys_p),
            "durations_count": len(durations)
        }
    }

def load_metrics(log_path):
    # 1) try env
    def envf(name, default=None):
        v = os.getenv(name)
        if v is None:
            return default
        try:
            return float(v)
        except:
            return default
    m_env = {
        "paradox_density": envf("PF_PARADOX_DENSITY"),
        "settle_time_p95_ms": envf("PF_SETTLE_P95_MS"),
        "downstream_error_rate": envf("PF_DOWNSTREAM_ERROR_RATE"),
    }
    if all(v is not None for v in m_env.values()):
        return m_env, {"source": "env"}
    # 2) try decision log
    m_log = derive_from_log(log_path)
    if m_log is not None:
        return {k: m_log[k] for k in ["paradox_density","settle_time_p95_ms","downstream_error_rate"]}, {"source": "log", **m_log.get("observations", {})}
    # 3) default zeros
    return {"paradox_density": 0.0, "settle_time_p95_ms": 0.0, "downstream_error_rate": 0.0}, {"source":"default"}

def decide(th, m):
    # Order of severity
    if m["downstream_error_rate"] > th["downstream_error_rate_max"]:
        return "ROLLBACK"
    if m["paradox_density"] > th["paradox_density_max"]:
        return "DEGRADE"
    if m["settle_time_p95_ms"] > th["settle_time_p95_ms"]:
        return "QUARANTINE_NEW_P"
    return "NORMAL"

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--policy", default=os.getenv("PF_POLICY", POLICY_DEFAULT))
    ap.add_argument("--log", default=os.getenv("PF_DECISION_LOG", LOG_DEFAULT))
    ap.add_argument("--mode", choices=["shadow","active"], default=os.getenv("PF_MODE","shadow"))
    args = ap.parse_args()

    th = load_policy(args.policy)
    m, meta = load_metrics(args.log)
    decision = decide(th, m)

    summary = {
        "decision": decision,
        "mode": args.mode,
        "metrics": m,
        "thresholds": th,
        "meta": meta,
        "ts": int(time.time()*1000)
    }
    os.makedirs(os.path.dirname(ARTIFACT_OUT), exist_ok=True)
    with open(ARTIFACT_OUT, "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)
    print("PULSE PARADOX GATE:", json.dumps(summary))

    if args.mode == "active" and decision in ("DEGRADE","QUARANTINE_NEW_P","ROLLBACK"):
        sys.exit(1)

if __name__ == "__main__":
    main()
