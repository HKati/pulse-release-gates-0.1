# Pulse Paradox Gate (CI)

Run a deterministic, fail-closed gate for the Paradox Field metrics.

## Usage

- Shadow mode (informational, never fails the job):
  ```bash
  python pulse/gates/paradox/gate.py --mode shadow
  ```

- Active mode (fail-closed):
  ```bash
  PF_MODE=active python pulse/gates/paradox/gate.py
  ```

### Metrics sources

- Environment variables:
  - `PF_PARADOX_DENSITY`
  - `PF_SETTLE_P95_MS`
  - `PF_DOWNSTREAM_ERROR_RATE`
- Or `logs/decision_log.ndjson` (auto-parsed).

### Policy

Edit thresholds in `pulse/gates/paradox/policy.yaml`.
