#!/usr/bin/env python3
"""Build PULSE Normative vs Shadow Inventory Report v0.

This script is a review carrier. It classifies repository workflows and selected
authority-relevant artifacts by mechanical carrier role. It does not alter
release authority, gate policy, workflow behavior, status artifacts, or release
decisions.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import hashlib
from pathlib import Path
from typing import Any


SCHEMA_ID = "pulse.normative_shadow_inventory.v0"
SCHEMA_VERSION = "0.1.0"

AUTHORITY_PATH = (
    "status.json -> declared gate policy -> workflow-effective materialized "
    "required gate set -> strict fail-closed CI enforcement"
)


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat().replace("+00:00", "Z")


def read_text_if_exists(path: Path) -> str:
    if not path.is_file():
        return ""
    return path.read_text(encoding="utf-8", errors="replace")


def entry(
    *,
    name: str,
    path: str,
    surface_type: str,
    primary_role: str,
    carrier_class: str,
    authority_impacting: str,
    authority_boundary: str,
    reads_artifacts: list[str] | None = None,
    writes_artifacts: list[str] | None = None,
    publishes_artifacts: list[str] | None = None,
    required_gate_participation: bool = False,
    attestation_participation: bool = False,
    release_path_participation: bool = False,
    notes: str = "",
) -> dict[str, Any]:
    return {
        "name": name,
        "path": path,
        "surface_type": surface_type,
        "primary_role": primary_role,
        "carrier_class": carrier_class,
        "authority_impacting": authority_impacting,
        "authority_boundary": authority_boundary,
        "reads_artifacts": reads_artifacts or [],
        "writes_artifacts": writes_artifacts or [],
        "publishes_artifacts": publishes_artifacts or [],
        "required_gate_participation": required_gate_participation,
        "attestation_participation": attestation_participation,
        "release_path_participation": release_path_participation,
        "notes": notes,
    }


def workflow_name(path: Path, text: str) -> str:
    for line in text.splitlines():
        if line.startswith("name:"):
            return line.split(":", 1)[1].strip().strip('"').strip("'")
    return path.stem


def classify_workflow(path: Path, *, repo_root: Path) -> dict[str, Any]:
    rel = path.relative_to(repo_root).as_posix()
    text = read_text_if_exists(path)
    name = workflow_name(path, text)

    rel_l = rel.lower()
    file_l = path.name.lower()
    stem_l = path.stem.lower()
    name_l = name.lower()
    identity_l = f"{rel_l}\n{file_l}\n{stem_l}\n{name_l}"

    if rel == ".github/workflows/q3_reference_acquisition_v0.yml":
        if (name != "Q3 native token preflight and capture v0"
                or hashlib.sha256(text.encode("utf-8")).hexdigest() != "460a49a8e90a30aa51ae6d322993e76f2b40ad8c07efde3634dba5a0c5f018f4"):
            return entry(name=name, path=rel, surface_type="workflow",
                         primary_role="unclassified workflow", carrier_class="advisory",
                         authority_impacting="conditional",
                         authority_boundary="Changed Q3 carrier requires exact source review")
        return entry(name=name, path=rel, surface_type="workflow",
                     primary_role="non-authorizing Q3 native token preflight and capture",
                     carrier_class="audit_preservation", authority_impacting="no",
                     authority_boundary="Separately consented zero-generation preflight or bounded capture; no gate admission.",
                     reads_artifacts=["fixed Q3 tasks, contexts and exact runtime input archive"],
                     writes_artifacts=["bounded original token/text evidence or explicit incompleteness"],
                     publishes_artifacts=["30-day owner-consented Actions evidence; not private storage"],
                     notes="No labeling, metric execution, required gate, attestation or release activation.")

    if rel == ".github/workflows/q3_reference_acquisition_v1.yml":
        expected_sha256 = "dc6dd7cbb660d6494e6fcc71bffe498623afaa0920098f5f64591f5ba2dcc24c"
        if (name != "Q3 bounded continuation preflight and capture v1"
                or path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
            return entry(name=name, path=rel, surface_type="workflow",
                         primary_role="unclassified workflow", carrier_class="advisory",
                         authority_impacting="conditional",
                         authority_boundary="Changed Q3 continuation carrier requires exact source review")
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing Q3 bounded continuation preflight and capture",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary=(
                "Separately consented zero-generation preflight or bounded 203-task continuation; "
                "no gate admission."
            ),
            reads_artifacts=["fixed Q3 inputs, continuation amendment and exact historical capture evidence"],
            writes_artifacts=["historical verification and bounded continuation evidence or explicit incompleteness"],
            publishes_artifacts=["30-day owner-consented Actions evidence; not private storage"],
            required_gate_participation=False, attestation_participation=False, release_path_participation=False,
            notes=("The historical session remains incomplete. No labeling, metric execution, "
                   "required gate, attestation or release activation."),
        )

    if rel == ".github/workflows/pulsemech_admission_rejection_verification_v0.yml":
        expected_sha256 = "571a0a8046e212adeb10107bcd7b9654e6eb244f3a14a948a14f265171686e03"
        if (name != "PULSEmech independent admission-rejection verification v0"
                or path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
            return entry(
                name=name, path=rel, surface_type="workflow",
                primary_role="unclassified workflow", carrier_class="advisory",
                authority_impacting="conditional",
                authority_boundary="Changed admission-rejection verification carrier requires exact source review",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing independent admission-rejection verification",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary=(
                "Read-only verification of one exact historical rejection run; "
                "no subject dispatch, model inference or release admission."
            ),
            reads_artifacts=["exact original plan, Q2 inputs and terminal-run evidence"],
            writes_artifacts=["fresh semantic and signature verification, two canonical reports or bounded failure"],
            publishes_artifacts=["owner-dispatched verification evidence with declared Actions retention"],
            required_gate_participation=False, attestation_participation=False, release_path_participation=False,
            notes=("Verifies an existing attestation without producing one. Historical rejection remains; "
                   "bounded observation acceptance does not close Step 5C/5D or grant release authority."),
        )

    if rel == ".github/workflows/required_gate_idempotence_entry_build_v0.yml":
        expected_sha256 = "cff2855863498f015564318ce0adda218e62d6d204a96ced343a473452252e88"
        if (name != "PULSEmech idempotence entry build provenance v0"
                or path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
            return entry(
                name=name, path=rel, surface_type="workflow",
                primary_role="unclassified workflow", carrier_class="advisory",
                authority_impacting="conditional",
                authority_boundary="Changed entry-build provenance carrier requires exact source review",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing fixed entry-build provenance workflow",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary=(
                "Manual owner-scoped preservation and attestation of two fixed entry builds; "
                "no produced-entry or selected-runtime execution, required-gate activation or release admission."
            ),
            reads_artifacts=[
                "exact reviewed source/workflow commit and pinned containment-entry C source",
                "selected compiler and before/after toolchain observations",
                "exact current-run build artifact and closed record manifest",
            ],
            writes_artifacts=[
                "two preserved entry binaries, source copies, raw build logs and bounded process records",
                "independent closed-record verification or incomplete attempt evidence",
                "original GitHub SLSA provenance bundle and bounded signature-verification output",
            ],
            publishes_artifacts=[
                "owner-dispatched build evidence and separate attestation evidence with 90-day retention",
            ],
            required_gate_participation=False, attestation_participation=True, release_path_participation=False,
            notes=(
                "Produces and verifies build provenance for the closed record without granting release authority. "
                "Same-host repeat builds do not establish compiler correctness, source/binary equivalence or "
                "host qualification. Static verification keeps github_build_provenance_verified=false; "
                "signature verification has its own preserved result and B2 remains incomplete."
            ),
        )

    if rel == ".github/workflows/required_gate_idempotence_exec_stop_v0.yml":
        expected_sha256 = "8f4ec694d60e455273d2e29bccae289a7821363781ddb8c5b05096b01534b182"
        if (name != "PULSEmech original launcher exec-stop observation v0"
                or path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
            return entry(
                name=name, path=rel, surface_type="workflow",
                primary_role="unclassified workflow", carrier_class="advisory",
                authority_impacting="conditional",
                authority_boundary="Changed original-launcher exec-stop carrier requires exact source review",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing original-launcher exec-stop observation workflow",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary=(
                "Manual owner-scoped acquisition at one original-launcher kernel exec checkpoint; "
                "no continuation or detach after PTRACE_EVENT_EXEC, selected-runtime execution, "
                "required-gate activation or release admission."
            ),
            reads_artifacts=[
                "exact reviewed source/workflow commit and same-attempt owner acknowledgement",
                "preserved original launcher/distribution inputs and pinned observation environment inputs",
                "exact current-run artifact ID and externally bound complete or incomplete attempt receipt",
            ],
            writes_artifacts=[
                "original exec-stop request, raw capture or bounded incomplete attempt prefix",
                "two independent-checker executions reconstructing the preserved original capture",
                "completed verification binding and original GitHub attestation and signature-verification evidence",
            ],
            publishes_artifacts=[
                "original observation and separate verification artifacts with 90-day retention",
            ],
            required_gate_participation=False, attestation_participation=True, release_path_participation=False,
            notes=(
                "Preserves failed prerequisites and incomplete captures without automatically repeating acquisition. "
                "Accepted reconstruction of an incomplete record is not completed observation. "
                "Hosted provenance and selected cp0 relationships do not establish complete native closure, "
                "host qualification, observed containment or release authority. Steps 6 and 7 remain separate; "
                "authority_effect=none; keep #2879 open."
            ),
        )

    if rel == ".github/workflows/required_gate_idempotence_entry_stop_v0.yml":
        expected_sha256 = "452972094f789a65b5933497be000d97c2ba7d896a7b41fad0dd028cfa7a9021"
        if (name != "PULSEmech original launcher entry-stop observation v0"
                or path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
            return entry(
                name=name, path=rel, surface_type="workflow",
                primary_role="unclassified workflow", carrier_class="advisory",
                authority_impacting="conditional",
                authority_boundary="Changed original-entry observation carrier requires exact source review",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing guarded original-entry observation workflow",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary=(
                "Manual owner-scoped capability qualification and one fresh original cp0-to-entry attempt; "
                "no continuation or detach after executable entry, selected-runtime execution, "
                "required-gate activation or release admission."
            ),
            reads_artifacts=[
                "exact reviewed source/workflow commit and same-attempt owner acknowledgement",
                "preserved original inputs, selected native objects and pinned observation environment",
                "separate task-guard and hardware-breakpoint qualification records from the acquisition context",
                "exact current-run artifact ID and externally bound complete or incomplete attempt receipt",
            ],
            writes_artifacts=[
                "both capability records and bounded failed-prerequisite or original-attempt prefixes",
                "original entry request and raw cp0/entry capture with owned-child cleanup evidence",
                "two independent reconstructions of preserved bytes and owned outer-container cleanup evidence",
                "completed verification binding and original GitHub attestation and signature-verification evidence",
            ],
            publishes_artifacts=[
                "original qualification/observation and separate verification artifacts with 90-day retention",
            ],
            required_gate_participation=False, attestation_participation=True, release_path_participation=False,
            notes=(
                "Both capability qualifications must complete before the original attempt. "
                "Failed prerequisites and incomplete captures remain incomplete; verification repeats neither "
                "qualification nor acquisition. Loader initialization can execute before entry; provider mappings "
                "do not establish per-consumer resolution, complete native closure, containment or release authority. "
                "B2 and Steps 6 and 7 remain separate; metric_pass=null; authority_effect=none; keep #2879 open."
            ),
        )

    if rel == ".github/workflows/required_gate_idempotence_loader_two_slot_qualification_v0.yml":
        expected_sha256 = "b0b889a3b6b8f8fa863e3ffba295dd9c295254ea7fdddb2066017f8c5d1e59ef"
        if (name != "PULSEmech loader two-slot qualification v0"
                or path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
            return entry(
                name=name, path=rel, surface_type="workflow",
                primary_role="unclassified workflow", carrier_class="advisory",
                authority_impacting="conditional",
                authority_boundary="Changed synthetic two-slot qualification carrier requires exact source review",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing synthetic loader two-slot qualification workflow",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary=(
                "Manual owner-scoped execution of one fixed synthetic probe with preserved evidence "
                "and independent data-only replay; no original-launcher or model execution, "
                "required-gate activation or release admission."
            ),
            reads_artifacts=[
                "exact reviewed source/workflow commit, fixed source closure and owner acknowledgement",
                "pinned Python base, six hash-locked verifier wheels and preserved build inputs",
                "exact current-run artifact ID/digest and externally bound complete or incomplete attempt receipt",
            ],
            writes_artifacts=[
                "context-bound synthetic request, native attempt and qualification bytes or incomplete prefix",
                "two canonical acquisition reports and two independent data-only replay reports",
                "fixed command/runtime records and verified owned container cleanup",
                "completed verification binding and original GitHub attestation and signature-verification evidence",
            ],
            publishes_artifacts=[
                "synthetic qualification and separate verification artifacts with 90-day retention",
            ],
            required_gate_participation=False, attestation_participation=True, release_path_participation=False,
            notes=(
                "Incomplete prefixes remain incomplete and cannot reach completed-statement attestation. "
                "The verifier rebuilds from preserved inputs without repeating native qualification. "
                "Hosted statement attestation does not establish physical execution authentication, "
                "future-host admission, original source/build acceptance, B2 completion or release authority. "
                "metric_pass=null; authority_effect=none; keep #2879 open with its complete whole-runtime scope."
            ),
        )

    if rel == ".github/workflows/required_gate_idempotence_loader_resolution_v0.yml":
        expected_sha256 = "ef4b6622ef0443452062e872f8d960658f0647723677ca8c1e5d0f2f8b4b7f97"
        if (name != "PULSEmech original loader resolution observation v0"
                or path.is_symlink() or not path.is_file()
                or hashlib.sha256(path.read_bytes()).hexdigest() != expected_sha256):
            return entry(
                name=name, path=rel, surface_type="workflow",
                primary_role="unclassified workflow", carrier_class="advisory",
                authority_impacting="conditional",
                authority_boundary="Changed original-loader resolution carrier requires exact source review",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing bounded original-loader resolution observation workflow",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary=(
                "Manual owner-scoped original-input and selected-policy admission, fresh guard and two-slot "
                "qualification, and one original attempt through nine selected dependency returns and entry; "
                "no continuation after entry, model execution, required-gate activation or release admission."
            ),
            reads_artifacts=[
                "exact reviewed source/workflow commit, independently selected policy digest and owner acknowledgement",
                "preserved original distribution and rebuild inputs, exact verifier and original native objects",
                "pinned Python base, verified Debian packages and hash-locked verifier wheels",
                "exact current-run artifact ID/digest and externally bound complete or incomplete attempt receipt",
            ],
            writes_artifacts=[
                "source-bound original request, raw nine-return and entry capture or bounded incomplete prefix",
                "fresh acquisition-context task-guard and two-slot qualification records",
                "two canonical acquisition reports and two independent data-only replay reports",
                "fixed command/runtime records and verified owned container cleanup",
                "completed verification binding and original GitHub attestation and signature-verification evidence",
            ],
            publishes_artifacts=[
                "original-loader observation and separate verification artifacts with 90-day retention",
            ],
            required_gate_participation=False, attestation_participation=True, release_path_participation=False,
            notes=(
                "Incomplete prefixes remain incomplete and cannot reach completed-statement attestation. "
                "The verifier rebuilds offline from preserved inputs without repeating probes or acquisition. "
                "The historical GPG selection remains exact; test-host verifier selection cannot replace it. "
                "Hosted statement attestation does not establish physical execution authentication, "
                "future-host admission, whole-runtime closure, B2 completion or release authority. "
                "metric_pass=null; authority_effect=none; keep #2879 open with its complete whole-runtime scope."
            ),
        )

    if rel == ".github/workflows/pulse_ci.yml":
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="primary release-authority workflow",
            carrier_class="authority",
            authority_impacting="yes",
            authority_boundary=AUTHORITY_PATH,
            reads_artifacts=[
                "status.json",
                "pulse_gate_policy_v0.yml",
                "pulse_gate_registry_v0.yml",
            ],
            writes_artifacts=[
                "status.json",
                "release_decision_v0.json",
                "release_authority_v0.json",
                "artifact_provenance_binding_v0.json",
            ],
            publishes_artifacts=[
                "pulse-report",
                "release-authority-v0",
                "release-authority-artifact-binding-v0",
            ],
            required_gate_participation=True,
            attestation_participation="actions/attest@" in text,
            release_path_participation=True,
            notes=(
                "Primary release-authority workflow. Produces, validates, "
                "materializes, enforces, binds, and may attest authority artifacts."
            ),
        )

    if rel == ".github/workflows/q2_release_host_worker_verification_v0.yml":
        # This exact reviewed carrier is non-authorizing, not every workflow
        # containing a Q2 name. Any byte change needs renewed carrier review.
        expected_sha256 = "e4babb03d3f2ef57ce17462a0719c47f43c67df0c8319e7e58a8fc4183d6c2eb"
        if (name != "Q2 native release-host worker verification v0"
                or hashlib.sha256(text.encode("utf-8")).hexdigest() != expected_sha256):
            return entry(
                name=name, path=rel, surface_type="workflow", primary_role="unclassified workflow",
                carrier_class="advisory", authority_impacting="conditional",
                authority_boundary="Changed Q2 worker workflow requires exact carrier review",
                notes="No workflow-name, permission or authority-path exemption.",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing Q2 capsule worker verification workflow",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary="One separately consented 150-call worker verification; no gate admission.",
            reads_artifacts=["exact original capture, preparation, capsule and roundtrip inputs"],
            writes_artifacts=["bounded source-bound worker evidence or rejection"],
            publishes_artifacts=["separately consented 30-day Actions evidence carrier, not private storage"],
            required_gate_participation=False, attestation_participation=False, release_path_participation=False,
            notes="Historical FAIL/BLOCK remains; actual native execution, comparison and preservation are separate.",
        )

    if rel == ".github/workflows/q2_release_host_tokenizer_verification_v0.yml":
        forbidden = ("actions/attest@", "materialize_release_decision", "release_authority_v0.json",
                     "release_decision_v0.json", "pulse_gate_registry", "pulse_gate_policy", "id-token: write")
        if (name != "Q2 native release-host tokenizer verification v0"
                or "verify_q2_release_host_tokenizer_v0.py" not in text
                or any(token in text for token in forbidden)):
            return entry(
                name=name, path=rel, surface_type="workflow", primary_role="unclassified workflow",
                carrier_class="advisory", authority_impacting="conditional",
                authority_boundary="Changed Q2 tokenizer boundary requires explicit carrier review",
                notes="No generic workflow-name or authority-path exemption.",
            )
        return entry(
            name=name, path=rel, surface_type="workflow",
            primary_role="non-authorizing Q2 native tokenizer verification workflow",
            carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary="Four owner-dispatched tokenizer/reduction checks; zero model calls and no gate admission.",
            reads_artifacts=["fixed capture, preparation, published capsule and observed roundtrip receipt"],
            writes_artifacts=["source/input/projection-bound native tokenizer metadata or bounded rejection"],
            publishes_artifacts=["non-authorizing Q2 tokenizer evidence"],
            required_gate_participation=False, attestation_participation=False, release_path_participation=False,
            notes="Historical FAIL/BLOCK remains; worker/model readiness and full release-host verification remain open.",
        )

    if rel == ".github/workflows/q2_reference_acquisition_v0.yml":
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="non-active Q2 preparation, diagnostic and selected capture workflow",
            carrier_class="diagnostic_shadow",
            authority_impacting="no",
            authority_boundary=(
                "Owner-dispatched preparation, one unscored diagnostic, or separately "
                "consented fixed 150-slot capture. Original token/text and terminal "
                "records are separately checked before Q2 reduction. This does not "
                "admit a production gate or create release authority."
            ),
            reads_artifacts=[
                "exact reviewed main source and selected Q2 workload bytes",
                "immutable model snapshot and upstream wheel metadata",
            ],
            writes_artifacts=[
                "model-file identity map and complete staged wheel candidates",
                "exact source/run-bound preparation manifest",
                "separate prepared-runtime checker result",
                "source-bound installation and external sandbox observations",
                "one original diagnostic token/text record and separate checker result",
                "non-authorizing qualification or bounded failure report",
                "complete capture-slot inventory, original responses and separate extraction check",
                "bound Q2 groups, dataset manifest, handoff and metric PASS/FAIL",
            ],
            publishes_artifacts=["verified Q2 runtime preparation review candidate",
                                 "separately consented native diagnostic evidence",
                                 "separately consented original 150-slot capture evidence"],
            required_gate_participation=False,
            attestation_participation=False,
            release_path_participation=False,
            notes=(
                "Preparation never runs a model. Only an explicit native-mode "
                "owner dispatch may run the one unscored diagnostic; never PR/push. "
                "Capture requires its own retention consent. Candidate preservation does not "
                "activate Q2 or establish Step 5C acceptance. "
                "authority_effect = none."
            ),
        )

    if rel == (
        ".github/workflows/"
        "pulsemech_compute_post_run_producer_input_capture_v0.yml"
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role=(
                "historical-reference post-run producer-input capture workflow"
            ),
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary=(
                "Manual historical-reference capture and preservation carrier. "
                "It preserves exact capture-time platform-response inputs for "
                "later offline validation and deterministic reference packet "
                "production. It does not produce a runtime observation, gate "
                "result, release decision, or release authority."
            ),
            reads_artifacts=[
                "one exact completed same-repository PULSE CI run attempt",
                "attempt-specific GitHub Actions run response",
                "complete attempt-specific GitHub Actions jobs page set",
                "exact capture contract and protected capture control plane",
            ],
            writes_artifacts=[
                "exact raw capture-time response entity bodies",
                "canonical request-response exchange metadata",
                "checksum-closed producer-input capture manifest",
                "offline validation diagnostic",
            ],
            publishes_artifacts=[
                "manual historical-reference producer-input capture artifact",
            ],
            required_gate_participation=False,
            attestation_participation=False,
            release_path_participation=False,
            notes=(
                "Step 4A historical-reference producer-input carrier. "
                "The capture is post-run and cannot be retroactively admitted "
                "to the completed subject run. Runtime-observation packet "
                "production and active authority participation remain absent; "
                "authority_effect = none."
            ),
        )

    if rel == (
        ".github/workflows/"
        "pulsemech_compute_current_run_export_candidate.yml"
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="non-active current-run compute candidate workflow",
            carrier_class="diagnostic_shadow",
            authority_impacting="conditional",
            authority_boundary=(
                "Manual candidate-only, non-active, pre-authority workflow. "
                "Its outputs can participate in release authority only after a "
                "separate change explicitly admits them as recorded evidence and "
                "enforces them through a separate declared required gate."
            ),
            reads_artifacts=[
                "selected successful same-repository PULSE CI source run",
                "complete release-grade reference package",
                "structural package-completeness report",
                "independent package-verification report",
                "exact subject and protected control-plane components",
                (
                    "declared policy, gate registry, final status, release decision, "
                    "schemas, and signer policies"
                ),
            ],
            writes_artifacts=[
                "deterministic finalized current-run carrier",
                "observed current-run export expectation",
                "observed current-run subject-input packet",
                "candidate-output manifest and checksum-bound candidate directory",
            ],
            publishes_artifacts=[
                "candidate-only GitHub Actions artifact bundle",
            ],
            required_gate_participation=False,
            attestation_participation=False,
            release_path_participation=False,
            notes=(
                "Step 3F current-run candidate carrier. Produces bounded observed "
                "inputs for later compute work without activating a gate, budget, "
                "runtime observation, release decision, or release authority."
            ),
        )

    if rel == (
        ".github/workflows/"
        "pulsemech_compute_current_run_artifact_observed_candidate.yml"
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="current-run artifact-observed compute proof workflow",
            carrier_class="diagnostic_shadow",
            authority_impacting="conditional",
            authority_boundary=(
                "Manual candidate-only, non-active, artifact-observed, "
                "pre-authority workflow. Its outputs can participate in release "
                "authority only after a separate change explicitly admits the "
                "generated proof as recorded evidence and enforces it through a "
                "separate declared required gate."
            ),
            reads_artifacts=[
                "selected successful same-repository Step 3F provider workflow run",
                "exact Step 3F current-run export candidate artifact",
                "verified current-run candidate-bundle intake",
                "exact current-run subject and protected control-plane components",
                (
                    "finalized carrier, observed expectation, observed subject-input "
                    "packet, policy, gate registry, schemas, and verifier inputs"
                ),
            ],
            writes_artifacts=[
                "artifact-observed compute-binding report",
                "deterministic current-run integration plan",
                "planned-observed relation",
                "candidate materializer report",
                "separate folded candidate status",
                (
                    "artifact-observed proof manifest and checksum-bound proof "
                    "directory"
                ),
            ],
            publishes_artifacts=[
                "candidate-only artifact-observed GitHub Actions proof bundle",
            ],
            required_gate_participation=False,
            attestation_participation=False,
            release_path_participation=False,
            notes=(
                "Step 3G current-run artifact-observed proof carrier. Preserves "
                "false, missing, partial, and unresolved states without activating "
                "a gate, compute budget, runtime observation, release decision, "
                "or release authority."
            ),
        )

    if rel == (
        ".github/workflows/"
        "pulsemech_compute_bounded_execution_reference.yml"
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="non-active bounded-execution reference workflow",
            carrier_class="diagnostic_shadow",
            authority_impacting="conditional",
            authority_boundary=(
                "Manual candidate-only, non-active, pre-authority bounded "
                "reference workflow. It executes the strict checker and a "
                "separate result consumer on controlled reference inputs, not "
                "the primary production release path. Authority participation "
                "requires a separate change admitting its outputs as recorded "
                "evidence and enforcing a separate declared required gate."
            ),
            reads_artifacts=[
                "exact reviewed main source commit and protected control-plane sources",
                "exact repository, workflow, run, attempt, and checkout context",
                "ordered core_required policy output and gate registry",
                "prelaunch specification and controlled status/pending-state inputs",
                "plan-only integration request, component manifest, and plan",
            ],
            writes_artifacts=[
                "prelaunch expectations and prepared source/input carrier",
                "bounded capture of three checker and three consumer processes",
                "bounded-reference subject-input packet and partial runtime packet",
                "artifact-only baseline and separate runtime-bound compute report",
                "planned-observed relation and separate non-active candidate state",
                "byte-identical reconstruction archives from two separate processes",
                "checksum-closed reference_capsule_v0.zip",
            ],
            publishes_artifacts=[
                "non-active bounded-reference GitHub Actions artifact bundle",
            ],
            required_gate_participation=False,
            attestation_participation=False,
            release_path_participation=False,
            notes=(
                "Step 5B bounded reference carrier. Checker exits 0/1/2 and "
                "consumer ready/held states are reference results, not production "
                "release decisions or deployment admission. Whole-packet coverage "
                "stays partial and resources unavailable. Inventory classification "
                "does not establish acquisition provenance, observed-reference "
                "acceptance, or full Step 5 closure. No resource measurement, "
                "compute budget, gate activation, or policy promotion; "
                "authority_effect = none; "
                "same_run_release_authority_eligible = false; "
                "active_gate_eligible = false."
            ),
        )

    if rel == (
        ".github/workflows/"
        "pulsemech_compute_whole_runtime_observation_reference.yml"
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role=(
                "non-active current-run whole-runtime observation reference workflow"
            ),
            carrier_class="diagnostic_shadow",
            authority_impacting="conditional",
            authority_boundary=(
                "Manual owner-dispatched, non-active observation and preservation "
                "workflow. It supervises one exact PULSE CI subject and one exact "
                "Step 3F provider, then independently verifies and reconstructs "
                "fixed evidence outside subject totals. It neither participates "
                "in nor changes the subject's existing release decision. Its "
                "outputs can participate in release authority only after a "
                "separate change admits them as recorded evidence and enforces "
                "a separate declared required gate."
            ),
            reads_artifacts=[
                (
                    "exact reviewed main source commit and protected "
                    "control-plane sources"
                ),
                (
                    "independently validated Step 5C prelaunch plan and exact "
                    "plan digest"
                ),
                (
                    "one exact attempt-1 PULSE CI subject run and complete "
                    "job/step metadata"
                ),
                (
                    "selected exact subject terminal artifacts and their "
                    "GitHub SHA-256 bindings"
                ),
                (
                    "one exact attempt-1 Step 3F provider run and current-run "
                    "candidate envelope"
                ),
                (
                    "exact reference-workflow context and cross-job handoff "
                    "bindings"
                ),
            ],
            writes_artifacts=[
                "deterministic prepared Step 5C input carrier",
                "exact capture carrier without a verifier verdict",
                (
                    "generic partial runtime-observation packet and existing-core "
                    "derived outputs"
                ),
                "two byte-identical deterministic reconstruction archives",
                "verification_record_v0.json and SHA256SUMS",
                "checksum-closed reference_capsule_v0.zip",
            ],
            publishes_artifacts=[
                "exact non-active verification-input handoff artifact",
                (
                    "verified non-active whole-runtime reference capsule "
                    "artifact"
                ),
            ],
            required_gate_participation=False,
            attestation_participation=False,
            release_path_participation=False,
            notes=(
                "Step 5C current-run whole-runtime observation carrier. "
                "Whole-runtime is bounded to the predeclared workflow, job, "
                "source-declared step, selected state, external-operation, and "
                "controlled inference graph; it is not host-wide tracing. I and "
                "E may become complete only after independent verification; R "
                "stays partial, C stays not complete, M stays unavailable, and "
                "generic runtime coverage stays partial. The observer remains "
                "outside subject totals and does not alter the subject decision; "
                "authority_effect = none; "
                "same_run_release_authority_eligible = false; "
                "active_gate_eligible = false."
            ),
        )

    if rel == ".github/workflows/pulsemech_ledger_swift.yml":   
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role=(
                "device-ledger Swift implementation verification workflow"
            ),
            carrier_class="advisory",
            authority_impacting="no",
            authority_boundary=(
                "Non-authorizing implementation-verification carrier. Its build "
                "and test results are repository verification signals only; they "
                "are not recorded device-observation evidence, are not materialized "
                "or enforced as a required gate, and do not participate in release "
                "authority."
            ),
            reads_artifacts=[
                "PULSEmechLedgerCore Package.swift",
                "PULSEmechLedgerCore Swift sources",
                "PULSEmechLedgerCore Swift tests",
            ],
            writes_artifacts=[
                "ephemeral SwiftPM build and test outputs",
            ],
            required_gate_participation=False,
            attestation_participation=False,
            release_path_participation=False,
            notes=(
                "Pinned Swift 6.2.4 Linux verification of the dependency-free "
                "device-ledger core. No real iPhone observation, physical-"
                "measurement claim, device-security claim, gate activation, "
                "release decision, or authority effect is created."
            ),
        )
  
    if file_l in {
        "core_baseline_capture.yml",
        "core_baseline_check.yml",
        "pulse_core_ci.yml",
    } or any(
        token in identity_l
        for token in (
            "core_baseline",
            "core-baseline",
            "core baseline",
            "pulse_core",
            "pulse-core",
            "pulse core",
            "core ci",
        )
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="core baseline workflow",
            carrier_class="advisory",
            authority_impacting="conditional",
            authority_boundary=(
                "Non-authorizing unless explicitly folded into recorded evidence "
                "and enforced as a required gate under declared policy."
            ),
            reads_artifacts=["status.json"],
            notes="Core baseline verification carrier; not a second release path.",
        )

    if (
        file_l in {"validate-status.yml", "validate_status.yml"}
        or "validate-status" in rel_l
        or "validate_status" in rel_l
        or "status validation" in name_l
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="status validation workflow",
            carrier_class="status_contract",
            authority_impacting="conditional",
            authority_boundary=(
                "Status-contract guard carrier. Authority participation requires "
                "explicit release-authority path wiring."
            ),
            reads_artifacts=["status.json", "schemas/status/*"],
            notes=(
                "Status validation carrier; not an independent release decision "
                "engine."
            ),
        )

    if (
        file_l in {"release_check.yml", "release-check.yml"}
        or "release_check" in rel_l
        or "release-check" in rel_l
        or "release check" in name_l
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="release check workflow",
            carrier_class="advisory",
            authority_impacting="conditional",
            authority_boundary=(
                "Review / guard carrier. Authority participation requires explicit "
                "required-gate wiring under declared policy."
            ),
            notes="Release-check carrier; not a second release-decision engine.",
        )

    if (
        file_l in {"public_surface_audit.yml", "public-surface-audit.yml"}
        or "public_surface_audit" in rel_l
        or "public surface audit" in name_l
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="public surface audit workflow",
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary="Audit / reader-boundary review carrier",
            reads_artifacts=["Quality Ledger", "public reader surfaces"],
            notes="Public-surface audit carrier; non-authorizing.",
        )

    if any(
        token in identity_l
        for token in (
            "theory_overlay",
            "theory-overlay",
            "theory overlay",
            "overlay_schema",
            "overlay-schema",
            "overlay schema",
            "overlay",
        )
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="diagnostic / overlay workflow",
            carrier_class="diagnostic_shadow",
            authority_impacting="conditional",
            authority_boundary=(
                "Authority participation requires recorded evidence inclusion and "
                "required-gate enforcement under declared policy."
            ),
            notes="Diagnostic / overlay carrier.",
        )

    if file_l in {
        "publish_report_pages.yml",
        "cancel_pages_deployment.yml",
        "pages_paradox_core_publish_shadow.yml",
        "pages_paradox_core_publish_case_study_shadow.yml",
        "paradox_core_pages_preview_shadow.yml",
    } or any(
        token in identity_l
        for token in (
            "pages",
            "publish_report",
            "publish-report",
            "publication",
            "badges",
            "seo",
            "make_org",
            "deployment",
            "report_pages",
            "report-pages",
        )
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="publication workflow",
            carrier_class="publication",
            authority_impacting="no",
            authority_boundary="Derived carrier only",
            publishes_artifacts=["Pages", "badges", "reader artifacts"],
            notes="Publication / reader carrier. Does not create release authority.",
        )

    if any(
        token in identity_l
        for token in ("secret", "gitleaks", "sarif", "security", "scan")
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="security / code scanning workflow",
            carrier_class="advisory",
            authority_impacting="no",
            authority_boundary=(
                "Non-authorizing security / repository hygiene carrier"
            ),
            publishes_artifacts=["security signals", "SARIF"],
            notes="Security / code scanning carrier.",
        )

    if any(
        token in identity_l
        for token in (
            "hygiene",
            "lint",
            "link-check",
            "link_check",
            "docs_link",
            "docs-link",
            "semantic_pr",
            "semantic-pr",
            "semantic pr",
            "changelog",
            "dco",
        )
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="repository hygiene workflow",
            carrier_class="advisory",
            authority_impacting="no",
            authority_boundary="Non-authorizing guard carrier",
            notes="Repository hygiene / review signal carrier.",
        )

    if any(token in identity_l for token in ("reproduce", "reproduction")):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="reproducibility workflow",
            carrier_class="audit_preservation",
            authority_impacting="conditional",
            authority_boundary=(
                "Reproduction / review carrier. Authority participation requires "
                "explicit required-gate wiring under declared policy."
            ),
            notes="Reproducibility carrier; does not create release authority.",
        )

    if any(
        token in identity_l
        for token in (
            "bundle",
            "reviewer bundle",
            "evidence packet",
            "package verifier",
        )
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="audit / preservation workflow",
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary="Audit / preservation carrier; non-authorizing",
            publishes_artifacts=["review bundles", "evidence packets"],
            notes="Review package / preservation carrier.",
        )

    if any(
        token in identity_l
        for token in (
            "stability",
            "separation_phase",
            "separation-phase",
            "separation phase",
            "topology",
            "epf",
            "field",
            "snapshot",
            "history_drift",
            "history-drift",
            "drift",
            "relational_gain",
            "relational-gain",
            "openai_evals",
            "openai-evals",
            "refusal",
            "parameter_golf",
            "parameter-golf",
            "paradox",
            "gpt_external",
            "gpt-external",
            "gravity_record",
            "gravity-record",
            "shadow_layer_registry",
            "shadow-layer-registry",
            "pulse-paradox-gate",
            "pulse paradox gate",
            "pulse_pd",
            "pulse-pd",
            "pulse pd",
            "pd_smoke",
            "pd-smoke",
            "pd smoke",
            "shadow",
            "experiment",
            "demo",
        )
    ):
        return entry(
            name=name,
            path=rel,
            surface_type="workflow",
            primary_role="diagnostic / shadow workflow",
            carrier_class="diagnostic_shadow",
            authority_impacting="conditional",
            authority_boundary=(
                "Authority participation requires recorded evidence inclusion and "
                "required-gate enforcement under declared policy."
            ),
            notes="Diagnostic / shadow carrier.",
        )

    return entry(
        name=name,
        path=rel,
        surface_type="workflow",
        primary_role="unclassified workflow",
        carrier_class="advisory",
        authority_impacting="conditional",
        authority_boundary="Requires maintainer classification before authority use",
        notes="Workflow requires explicit carrier-role review if authority-adjacent.",
    )


def static_authority_entries(repo_root: Path) -> list[dict[str, Any]]:
    candidates = [
        entry(
            name="Declared gate policy",
            path="pulse_gate_policy_v0.yml",
            surface_type="policy",
            primary_role="declared gate policy",
            carrier_class="policy",
            authority_impacting="yes",
            authority_boundary="Defines required gate sets by lane",
            required_gate_participation=True,
        ),
        entry(
            name="Gate registry",
            path="pulse_gate_registry_v0.yml",
            surface_type="registry",
            primary_role="gate identity registry",
            carrier_class="policy",
            authority_impacting="yes",
            authority_boundary="Defines gate identity and interpretation",
            required_gate_participation=True,
        ),
        entry(
            name="Status schema directory",
            path="schemas/status",
            surface_type="schema",
            primary_role="status contract carrier",
            carrier_class="status_contract",
            authority_impacting="yes",
            authority_boundary="Defines admissible release-state artifacts",
        ),
        entry(
            name="check_gates.py",
            path="PULSE_safe_pack_v0/tools/check_gates.py",
            surface_type="tool",
            primary_role="strict fail-closed gate enforcement",
            carrier_class="enforcement",
            authority_impacting="yes",
            authority_boundary="Enforces literal true-only required gate semantics",
            required_gate_participation=True,
        ),
        entry(
            name="Release decision materializer",
            path="PULSE_safe_pack_v0/tools/materialize_release_decision.py",
            surface_type="tool",
            primary_role="release-decision materialization",
            carrier_class="authority",
            authority_impacting="yes",
            authority_boundary=(
                "Materializes release-decision labels from recorded status, "
                "declared policy, and target context"
            ),
            reads_artifacts=["status.json", "pulse_gate_policy_v0.yml"],
            writes_artifacts=["release_decision_v0.json"],
            required_gate_participation=True,
        ),
        entry(
            name="Artifact provenance binding builder",
            path="PULSE_safe_pack_v0/tools/build_artifact_provenance_binding_v0.py",
            surface_type="tool",
            primary_role="binding carrier materialization",
            carrier_class="binding",
            authority_impacting="yes",
            authority_boundary="Builds digest-backed artifact relation carrier",
        ),
        entry(
            name="Artifact provenance binding verifier",
            path="PULSE_safe_pack_v0/tools/verify_artifact_provenance_binding_v0.py",
            surface_type="tool",
            primary_role="binding carrier verification",
            carrier_class="binding",
            authority_impacting="yes",
            authority_boundary="Verifies digest-backed artifact relation carrier",
        ),
        entry(
            name="Quality Ledger renderer",
            path="PULSE_safe_pack_v0/tools/render_quality_ledger.py",
            surface_type="tool",
            primary_role="reader carrier renderer",
            carrier_class="reader",
            authority_impacting="conditional",
            authority_boundary=(
                "Non-authorizing carrier; must preserve public reader boundary"
            ),
        ),
        entry(
            name="Release authority cryptographic binding boundary",
            path="docs/RELEASE_AUTHORITY_CRYPTOGRAPHIC_BINDING_v0.md",
            surface_type="documentation",
            primary_role="cryptographic binding boundary documentation",
            carrier_class="binding",
            authority_impacting="no",
            authority_boundary="Documentation carrier for binding boundary",
        ),
        entry(
            name="Authority impact audit checklist",
            path="docs/AUTHORITY_IMPACT_AUDIT_CHECKLIST_v0.md",
            surface_type="documentation",
            primary_role="authority-impact human review checklist",
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary="Review carrier",
        ),
        entry(
            name="External verification path",
            path="docs/EXTERNAL_VERIFICATION_PATH_v0.md",
            surface_type="documentation",
            primary_role="external verification path",
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary="External verification carrier",
        ),
        entry(
            name="Maintainer authority boundary",
            path="docs/MAINTAINER_AUTHORITY_BOUNDARY_v0.md",
            surface_type="documentation",
            primary_role="maintainer authority boundary",
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary="Repository change-control carrier",
        ),
    ]

    candidates.extend([
        entry(
            name="Q2 runtime preparation producer",
            path="PULSE_safe_pack_v0/tools/acquire_q2_reference_inputs_v0.py",
            surface_type="tool",
            primary_role="non-active Q2 preparation and selected capture orchestration",
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary="Preparation does not infer; separate capture consent permits the fixed workload, never production admission.",
        ),
        entry(
            name="Q2 prepared-runtime separate checker",
            path="PULSE_safe_pack_v0/tools/check_q2_reference_capture_v0.py",
            surface_type="tool",
            primary_role="separate Q2 prepared-runtime and original-capture verification",
            carrier_class="audit_preservation",
            authority_impacting="no",
            authority_boundary=(
                "Verifies fixed bytes and offline dependency resolution, "
                "plus original capture, occurrence and extraction records; no model generation or release authority."
            ),
        ),
    ])

    for filename, role in (
        ("qualify_q2_reference_runtime_v0.py", "external Q2 diagnostic supervisor and bounded capture service primitives"),
        ("run_q2_reference_subject_v0.py", "separate one-diagnostic and fixed 150-slot local Q2 worker"),
        ("check_q2_reference_qualification_v0.py", "separate Q2 native qualification checker"),
    ):
        candidates.append(entry(
            name=role,
            path="PULSE_safe_pack_v0/tools/" + filename,
            surface_type="tool",
            primary_role=role,
            carrier_class="diagnostic_shadow",
            authority_impacting="no",
            authority_boundary=(
                "Native diagnostic or explicitly selected capture service support; "
                "the qualification checker remains diagnostic-only. "
                "No Q2 gate admission or release authority."
            ),
        ))

    for filename, role in (
        ("verify_q2_release_host_tokenizer_v0.py", "external Q2 tokenizer-only execution supervisor"),
        ("check_q2_release_host_tokenizer_v0.py", "independent Q2 tokenizer input, replay and evidence checker"),
    ):
        candidates.append(entry(
            name=role, path="PULSE_safe_pack_v0/tools/" + filename, surface_type="tool",
            primary_role=role, carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary="No worker/model launch, fresh inference, production gate, certificate or release authority.",
            required_gate_participation=False, attestation_participation=False, release_path_participation=False,
        ))

    for filename, role in (
        ("q2_release_host_worker_contract_v0.py", "closed Q2 worker request constructor"),
        ("verify_q2_release_host_worker_v0.py", "external Q2 capsule worker execution supervisor"),
        ("check_q2_release_host_worker_v0.py", "independent Q2 worker input, token, metric and carrier checker"),
        ("check_q2_release_host_worker_protocol_v0.py", "Q2 worker protocol reconstruction component"),
    ):
        candidates.append(entry(
            name=role, path="PULSE_safe_pack_v0/tools/" + filename, surface_type="tool",
            primary_role=role, carrier_class="audit_preservation", authority_impacting="no",
            authority_boundary="No active gate, policy, certificate or release authority; actual owner consent precedes calls.",
            required_gate_participation=False, attestation_participation=False, release_path_participation=False,
        ))

    existing: list[dict[str, Any]] = []
    for item in candidates:
        path = repo_root / item["path"]
        if path.exists():
            existing.append(item)
    return existing


def collect_workflow_entries(repo_root: Path) -> list[dict[str, Any]]:
    workflows_dir = repo_root / ".github" / "workflows"
    if not workflows_dir.is_dir():
        return []
    return [
        classify_workflow(path, repo_root=repo_root)
        for path in sorted(workflows_dir.glob("*.yml"))
    ] + [
        classify_workflow(path, repo_root=repo_root)
        for path in sorted(workflows_dir.glob("*.yaml"))
    ]


def drift_findings(entries: list[dict[str, Any]]) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []

    for item in entries:
        if item["primary_role"] == "unclassified workflow":
            findings.append(
                {
                    "severity": "warning",
                    "path": item["path"],
                    "finding": (
                        "workflow requires explicit carrier-role classification"
                    ),
                }
            )

        if (
            item["carrier_class"]
            in {"publication", "reader", "diagnostic_shadow"}
            and item["authority_impacting"] == "yes"
        ):
            findings.append(
                {
                    "severity": "error",
                    "path": item["path"],
                    "finding": (
                        "non-authorizing carrier classified as authority-impacting"
                    ),
                }
            )

    return findings


def build_inventory(repo_root: Path) -> dict[str, Any]:
    repo_root = repo_root.resolve()
    entries = collect_workflow_entries(repo_root) + static_authority_entries(
        repo_root
    )

    return {
        "schema_id": SCHEMA_ID,
        "schema_version": SCHEMA_VERSION,
        "generated_utc": utc_now(),
        "repository_root": repo_root.as_posix(),
        "authority_carrier": AUTHORITY_PATH,
        "entry_count": len(entries),
        "entries": entries,
        "drift_findings": drift_findings(entries),
    }


def markdown_table(inventory: dict[str, Any]) -> str:
    lines = [
        "# Normative vs Shadow Inventory Report v0",
        "",
        "## Summary",
        "",
        f"- schema_id: `{inventory['schema_id']}`",
        f"- schema_version: `{inventory['schema_version']}`",
        f"- generated_utc: `{inventory['generated_utc']}`",
        f"- entry_count: `{inventory['entry_count']}`",
        "",
        "Authority carrier:",
        "",
        "```text",
        inventory["authority_carrier"],
        "```",
        "",
        "## Inventory",
        "",
        (
            "| Surface / workflow | Path | Carrier class | Authority-impacting | "
            "Boundary |"
        ),
        "|---|---|---|---|---|",
    ]

    for item in inventory["entries"]:
        lines.append(
            "| {name} | `{path}` | `{carrier}` | `{impact}` | {boundary} |".format(
                name=str(item["name"]).replace("|", "\\|"),
                path=str(item["path"]).replace("|", "\\|"),
                carrier=str(item["carrier_class"]).replace("|", "\\|"),
                impact=str(item["authority_impacting"]).replace("|", "\\|"),
                boundary=str(item["authority_boundary"]).replace("|", "\\|"),
            )
        )

    lines.extend(["", "## Drift findings", ""])

    findings = inventory.get("drift_findings") or []
    if not findings:
        lines.append("No drift findings recorded.")
    else:
        lines.extend(
            [
                "| Severity | Path | Finding |",
                "|---|---|---|",
            ]
        )
        for finding in findings:
            lines.append(
                "| {severity} | `{path}` | {finding} |".format(
                    severity=finding["severity"],
                    path=finding["path"],
                    finding=finding["finding"].replace("|", "\\|"),
                )
            )

    lines.append("")
    return "\n".join(lines)


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(payload, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repo-root", default=".")
    parser.add_argument("--out-json", required=True)
    parser.add_argument("--out-md", required=True)
    args = parser.parse_args()

    repo_root = Path(args.repo_root)
    inventory = build_inventory(repo_root)

    write_json(Path(args.out_json), inventory)
    write_text(Path(args.out_md), markdown_table(inventory))

    print(f"Wrote {args.out_json}")
    print(f"Wrote {args.out_md}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
