#!/usr/bin/env python3
"""Replay this example from preserved inputs and pinned verifier-source copies.

The executing Python environment and its verification libraries are external
trusted tools, recorded in CASE_INPUTS.json. No evidence input is recollected
from the host. No payload, package script, launcher, entry or runtime executes.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import socket
import stat
import subprocess
import sys
import urllib.request

sys.dont_write_bytecode = True
CASE = Path(__file__).resolve().parent
MANIFEST = json.loads((CASE / "CASE_INPUTS.json").read_text("utf-8"))

def read_case(name):
    relative = PurePosixPath(name)
    assert not relative.is_absolute() and relative.as_posix() == name
    assert all(part not in {"", ".", ".."} for part in relative.parts) and "\\" not in name
    expected = MANIFEST["files"][name]
    target = CASE / name
    for parent in target.parents:
        if parent == CASE:
            break
        assert not parent.is_symlink()
    fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(fd)
        assert stat.S_ISREG(before.st_mode) and before.st_nlink == 1
        assert before.st_size == expected["size_bytes"]
        data = bytearray()
        while len(data) <= before.st_size:
            raw = os.read(fd, min(65536, before.st_size + 1 - len(data)))
            if not raw:
                break
            data.extend(raw)
        after = os.fstat(fd)
        assert (before.st_dev, before.st_ino, before.st_mode, before.st_nlink,
                before.st_size, before.st_mtime_ns, before.st_ctime_ns) == (
                after.st_dev, after.st_ino, after.st_mode, after.st_nlink,
                after.st_size, after.st_mtime_ns, after.st_ctime_ns)
    finally:
        os.close(fd)
    result = bytes(data)
    assert len(result) == expected["size_bytes"]
    assert hashlib.sha256(result).hexdigest() == expected["sha256"]
    return result

PRESERVED = {name: read_case(name) for name in MANIFEST["files"]}

def forbidden(*_args, **_kwargs):
    raise AssertionError("Offline example replay attempted process or network execution")

subprocess.Popen = forbidden
subprocess.run = forbidden
os.system = forbidden
os.execve = forbidden
os.execv = forbidden
socket.create_connection = forbidden
urllib.request.urlopen = forbidden
sys.path.insert(0, str(CASE / "verifier-source/tools"))
import check_required_gate_idempotence_launch_host_v0 as checker
import required_gate_idempotence_containment_v0 as containment

def control(name):
    return PRESERVED["controls/" + name]

bootstrap_inputs = {}
for stem in ("runtime_selection", "operator_selection", "bootstrap_selection"):
    value = control(stem.replace("_", "-") + ".json")
    bootstrap_inputs[stem + "_bytes"] = value
    bootstrap_inputs["expected_" + stem + "_sha256"] = checker.sha(value)
bootstrap_inputs["capsule_bytes"] = PRESERVED[MANIFEST["capsule"]]
bootstrap_inputs["expected_capsule_sha256"] = MANIFEST["files"][MANIFEST["capsule"]]["sha256"]
bootstrap = containment.bootstrap.prepare_bootstrap(**bootstrap_inputs)
containment.bootstrap.verify_bootstrap_plan(plan_bytes=control("bootstrap-plan.json"),
    expected_plan_sha256=MANIFEST["files"]["controls/bootstrap-plan.json"]["sha256"], **bootstrap_inputs)
prepared = containment.prepare_containment(bootstrap_prepared=bootstrap,
    expected_bootstrap_plan_sha256=MANIFEST["files"]["controls/bootstrap-plan.json"]["sha256"],
    selection_bytes=control("containment-selection.json"),
    expected_selection_sha256=MANIFEST["files"]["controls/containment-selection.json"]["sha256"],
    launcher_bytes=PRESERVED["native/bwrap"], entry_bytes=PRESERVED["entry-build/build-1/entry"])
containment.verify_request(prepared, request_bytes=control("containment-request.json"),
    expected_request_sha256=MANIFEST["files"]["controls/containment-request.json"]["sha256"])
report = checker.verify_plan(
    plan_bytes=PRESERVED["launch-host-plan.json"],
    expected_plan_sha256=MANIFEST["files"]["launch-host-plan.json"]["sha256"],
    containment_prepared=prepared,
    expected_containment_request_sha256=MANIFEST["files"]["controls/containment-request.json"]["sha256"],
    selection_bytes=control("launch-host-selection.json"),
    expected_selection_sha256=MANIFEST["files"]["controls/launch-host-selection.json"]["sha256"],
    entry_build_payload={name: PRESERVED["entry-build/" + name] for name in MANIFEST["entry_build_paths"]},
    launcher_package_bytes=PRESERVED[MANIFEST["package"]],
    native_payload={name: PRESERVED[name] for name in MANIFEST["native_paths"]},
    host_observation_bytes=control("host-observation.json"))
assert report["status"] == "accepted" and report["record_status"] == "example"
assert all(type(report[key]) is type(value) and report[key] == value
           for key, value in checker.BOUNDARY.items())
sys.stdout.buffer.write(checker.canonical(report))
