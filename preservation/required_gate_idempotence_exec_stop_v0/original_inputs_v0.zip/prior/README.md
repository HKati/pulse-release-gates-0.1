# Real preserved inputs in an offline launch-host example

This is an **example record**, not a selected-runtime execution or a qualified host.
The exact entry bytes and all 15 entry-build evidence files come from original
GitHub run **43854478248, attempt 1**, at source commit
`f290aee20cd610e4fdb358dbf34d054ec351d390`. Both original build/attestation ZIPs
are preserved unchanged under `original-artifacts/`.

The original Debian `bubblewrap_0.12.0-1~deb13u1_amd64.deb` is preserved under
`origin/`. Its selected `usr/bin/bwrap` member equals the explicitly read local
`/usr/bin/bwrap` bytes. The six selected native files total **3,262,624 bytes**,
with **12** complete per-consumer interpreter/dependency bindings. Their selected
lookup paths and resolved file-copy paths are recorded separately. This does not
observe which files a running launcher would actually load.

The bootstrap/runtime capsule is an **authored inert fixture**, constructed using
the repository's existing `Example` helper. No entry was compiled for this
example. No entry, launcher, selected runtime, original operator, model or package
script was executed. The hosted build host and the local observer are distinct
contexts; this record does not claim they are the same host.

All five selected local copyright/notice files are preserved under `notices/`.
Their inclusion records the available notices and does not claim a legal review.

## Fresh replay result

Two separate fresh checker processes accepted the same preserved inputs, returned
exit code **0** and empty stderr, and produced byte-identical canonical reports:

- Each report: **4,284 bytes**.
- SHA-256: `720a2cf4ade0e2b575440e4b3e02bee8df9ef754d2f120ac4632fa9fc1ce9806`.
- Plan: **10,792 bytes**, SHA-256
  `314acd23ea1ba43dc3ccf337d0171473c43422c7c026d9548d104d88c968bcf5`.

The fixed 16 passive results contain **7 satisfied**, **7 observed**, and
**2 unknown** results. The unknown values concern the optional
`unprivileged_userns_clone` and `apparmor_restrict_unprivileged_userns` sysctls,
which were absent in the retained observation. Their absence is not a successful
capability test. Existing namespace identifiers and observer NNP/seccomp/capability
fields remain observations, not evidence that this launcher created a boundary or
installed the intended filter.

`host_environment_qualified`, `loader_resolution_verified`, origin/host
observation authentication, execution readiness and authorization remain false;
`metric_pass` remains null and `authority_effect` remains `none`. The preserved
hosted signature result is not freshly cryptographically verified by this replay.

## Preserved inputs and replay

`CASE_INPUTS.json` binds 78 preserved input/source files, including all selections,
the authored capsule, original entry evidence, native bytes, package, host snapshot,
plan, notices and **39** verifier source/data files. The latter are exact copies of
the reviewed implementation and its local admission dependencies. They are separate
from the inert runtime capsule. `results/processes.json` records the two actual
checker processes, and `VALIDATION.json` records the result and its scope.

From this directory, using a Python environment with the repository's verification
dependencies, run:

```bash
python -I -B replay.py
```

The replay reads the preserved files and imports the pinned verifier-source copies.
It does not recollect host facts or read native payloads from their original host
paths. The executing Python interpreter and verification libraries remain external
trusted tools; their actual versions are recorded in `CASE_INPUTS.json`. Process
and network launch guards are active during this example replay. The same independent
checker implementation is executed twice, not two independently implemented checkers.

The wider validation package retains the generation script separately as
`build_real_input_example.py`; regeneration is not required for this offline replay.
