#!/usr/bin/env python3
"""Freshly replay an original-byte distribution example from pinned local files.

The copied independent checker and admission dependencies read preserved inputs.
Only the externally selected GPG verifier may launch, using sealed original bytes
and the fixed offline signature profile. Python, verification libraries, GPG's
dynamic dependencies and the kernel remain external trusted verification tools.
"""
from __future__ import annotations

import argparse
import fcntl
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import socket
import stat
import subprocess
import sys
import urllib.request

sys.dont_write_bytecode = True
CASE = Path(__file__).resolve().parent
CONTROL_LIMIT = 1024 * 1024
FILE_LIMIT = 128 * 1024 * 1024
TOTAL_LIMIT = 256 * 1024 * 1024
HEX = re.compile(r"[0-9a-f]{64}\Z")


def require(condition, code):
    if not condition:
        raise ValueError(code)


def binding(raw):
    return {"sha256": hashlib.sha256(raw).hexdigest(), "size_bytes": len(raw)}


def canonical(value):
    return (json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")) + "\n").encode("ascii")


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, "example_duplicate_json_key")
        result[key] = value
    return result


def parse(raw):
    def invalid(_value):
        raise ValueError("example_noninteger_json_number")
    return json.loads(raw.decode("utf-8"), object_pairs_hook=unique_object,
                      parse_float=invalid, parse_constant=invalid)


def relative_name(name):
    require(type(name) is str and 0 < len(name) <= 500 and "\\" not in name,
            "example_path_invalid")
    path = PurePosixPath(name)
    require(not path.is_absolute() and path.as_posix() == name
            and all(part not in {"", ".", ".."} for part in path.parts),
            "example_path_invalid")
    return path


def read_regular(path, maximum):
    path = Path(path)
    for parent in (path, *path.parents):
        require(not parent.is_symlink(), "example_symlink_input")
    descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK | os.O_CLOEXEC)
    try:
        before = os.fstat(descriptor)
        require(stat.S_ISREG(before.st_mode) and before.st_nlink == 1
                and 0 <= before.st_size <= maximum, "example_input_type_or_size")
        result = bytearray()
        while len(result) <= before.st_size:
            block = os.read(descriptor, min(65536, before.st_size + 1 - len(result)))
            if not block:
                break
            result.extend(block)
        after = os.fstat(descriptor)
        fields = ("st_dev", "st_ino", "st_mode", "st_nlink", "st_size", "st_mtime_ns", "st_ctime_ns")
        require(all(getattr(before, field) == getattr(after, field) for field in fields)
                and len(result) == before.st_size, "example_input_changed")
    finally:
        os.close(descriptor)
    return bytes(result)


def load_case(expected_manifest_sha256):
    require(type(expected_manifest_sha256) is str and HEX.fullmatch(expected_manifest_sha256),
            "example_external_manifest_digest_required")
    manifest_raw = read_regular(CASE / "CASE_INPUTS.json", CONTROL_LIMIT)
    require(binding(manifest_raw)["sha256"] == expected_manifest_sha256,
            "example_manifest_digest_mismatch")
    manifest = parse(manifest_raw)
    require(manifest["record_type"] == "launcher_distribution_original_byte_example_v0"
            and manifest["record_status"] == "example", "example_manifest_profile")
    files = manifest["files"]
    require(type(files) is dict and 1 <= len(files) <= 256, "example_file_roster_invalid")
    originals, total = {}, 0
    for name, expected in files.items():
        relative_name(name)
        require(type(expected) is dict and set(expected) == {"sha256", "size_bytes"}
                and type(expected["sha256"]) is str and HEX.fullmatch(expected["sha256"])
                and type(expected["size_bytes"]) is int and 0 <= expected["size_bytes"] <= FILE_LIMIT,
                "example_file_binding_invalid")
        total += expected["size_bytes"]
        require(total <= TOTAL_LIMIT, "example_total_size_limit")
        raw = read_regular(CASE / name, expected["size_bytes"])
        require(binding(raw) == expected, "example_file_binding_mismatch:" + name)
        originals[name] = raw
    sources = [name for name in files if name.startswith("verifier-source/")]
    require(len(sources) == manifest["source_file_count"] == 43,
            "example_source_roster_mismatch")
    require(originals["replay.py"] == read_regular(Path(__file__), CONTROL_LIMIT),
            "example_replay_source_mismatch")
    return manifest, originals


def forbidden(*_args, **_kwargs):
    raise RuntimeError("example_forbidden_process_or_network_operation")


def install_guards(manifest, originals):
    """Admit one exact sealed-verifier invocation; this is not containment proof."""
    policy = parse(originals["controls/distribution-trust-policy.json"])
    real_popen = subprocess.Popen
    state = {"allowed_process_count": 0, "verifier_pids": []}

    def fd_number(path):
        require(type(path) is str and re.fullmatch(r"/proc/self/fd/[0-9]+", path),
                "example_verifier_descriptor_path")
        return int(path.rsplit("/", 1)[1])

    def check_sealed(descriptor, expected):
        observed = os.fstat(descriptor)
        required_seals = (getattr(fcntl, "F_SEAL_SEAL", 0x0001) |
                          getattr(fcntl, "F_SEAL_GROW", 0x0004) |
                          getattr(fcntl, "F_SEAL_SHRINK", 0x0002) |
                          getattr(fcntl, "F_SEAL_WRITE", 0x0008))
        require(stat.S_ISREG(observed.st_mode) and observed.st_size == expected["size_bytes"]
                and fcntl.fcntl(descriptor, getattr(fcntl, "F_GET_SEALS", 1034)) & required_seals == required_seals,
                "example_verifier_input_unsealed")
        raw = bytearray()
        while len(raw) < expected["size_bytes"]:
            block = os.pread(descriptor, min(65536, expected["size_bytes"] - len(raw)), len(raw))
            require(bool(block), "example_verifier_input_short_read")
            raw.extend(block)
        require(binding(bytes(raw)) == expected, "example_verifier_descriptor_binding_mismatch")

    def selected_popen(argv, *args, **kwargs):
        require(not args and type(argv) is list and state["allowed_process_count"] == 0,
                "example_extra_process_attempt")
        require(set(kwargs) == {"executable", "stdin", "stdout", "stderr", "env", "cwd",
                               "close_fds", "pass_fds", "shell", "start_new_session"},
                "example_verifier_process_options")
        executable_fd = fd_number(kwargs["executable"])
        require(len(argv) == 25, "example_verifier_argv_length")
        keyring_path, signature_path, release_path = argv[8], argv[-2], argv[-1]
        keyring_fd, signature_fd, release_fd = map(fd_number, (keyring_path, signature_path, release_path))
        expected_argv = [policy["verifier"]["path"], "--no-options", "--homedir", ".", "--batch", "--no-tty",
                         "--no-default-keyring", "--keyring", keyring_path,
                         "--disable-dirmngr", "--no-autostart", "--no-auto-key-retrieve",
                         "--no-auto-key-import", "--auto-key-locate", "clear", "--disable-signer-uid",
                         "--no-auto-check-trustdb", "--faked-system-time", str(policy["evaluation_time"]) + "!",
                         "--exit-on-status-write-error", "--status-fd", "1", "--verify",
                         signature_path, release_path]
        require(argv == expected_argv, "example_verifier_argv_mismatch")
        require(kwargs["stdin"] == subprocess.DEVNULL and kwargs["stdout"] == subprocess.PIPE
                and kwargs["stderr"] == subprocess.PIPE and kwargs["shell"] is False
                and kwargs["close_fds"] is True and kwargs["start_new_session"] is True
                and kwargs["env"] == {"PATH": "/usr/bin:/bin", "LC_ALL": "C", "LANG": "C", "TZ": "UTC"},
                "example_verifier_process_profile")
        require(type(kwargs["pass_fds"]) is tuple and len(kwargs["pass_fds"]) == 4
                and set(kwargs["pass_fds"]) == {executable_fd, keyring_fd, signature_fd, release_fd},
                "example_verifier_descriptor_roster")
        directory = Path(kwargs["cwd"])
        require(directory.is_absolute() and not directory.is_symlink()
                and stat.S_IMODE(directory.stat().st_mode) == 0o700,
                "example_verifier_private_directory")
        check_sealed(executable_fd, {key: policy["verifier"][key] for key in ("sha256", "size_bytes")})
        check_sealed(keyring_fd, binding(originals["distribution-origin/debian-archive-keyring.gpg"]))
        check_sealed(signature_fd, binding(originals["distribution-origin/Release.gpg"]))
        check_sealed(release_fd, binding(originals["distribution-origin/Release"]))
        state["allowed_process_count"] += 1
        process = real_popen(argv, **kwargs)
        state["verifier_pids"].append(process.pid)
        return process

    subprocess.Popen = selected_popen
    for name in ("run", "call", "check_call", "check_output"):
        setattr(subprocess, name, forbidden)
    for name in ("system", "execve", "execv", "execl", "execlp", "execvp", "execvpe", "fork", "forkpty",
                 "posix_spawn", "posix_spawnp", "spawnl", "spawnle", "spawnlp", "spawnlpe", "spawnv",
                 "spawnve", "spawnvp", "spawnvpe", "popen"):
        if hasattr(os, name):
            setattr(os, name, forbidden)
    socket.create_connection = forbidden
    socket.socket.connect = forbidden
    socket.socket.connect_ex = forbidden
    urllib.request.urlopen = forbidden
    return state


class EvidenceSink:
    def __init__(self, path):
        self.path = Path(path).absolute()
        self.path.mkdir(mode=0o700, parents=False, exist_ok=False)
        self.fd = os.open(self.path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC)
        self.calls = 0

    def __call__(self, payload):
        require(self.calls == 0 and set(payload) == {"stdout_bytes", "stderr_bytes", "process_record"},
                "example_verifier_capture_roster")
        process = payload["process_record"]
        for name, raw, maximum in (("gpg.status.bin", payload["stdout_bytes"], 65536),
                                  ("gpg.stderr.bin", payload["stderr_bytes"], 65536),
                                  ("gpg.process.json", canonical(process), CONTROL_LIMIT)):
            require(type(raw) is bytes and len(raw) <= maximum, "example_verifier_capture_limit")
            descriptor = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
                                 0o600, dir_fd=self.fd)
            try:
                view = memoryview(raw)
                while view:
                    written = os.write(descriptor, view)
                    require(written > 0, "example_capture_short_write")
                    view = view[written:]
                os.fsync(descriptor)
            finally:
                os.close(descriptor)
        os.fsync(self.fd)
        self.calls += 1

    def close(self):
        os.close(self.fd)


def original_inputs(manifest, originals, sink):
    sys.path.insert(0, str(CASE / "verifier-source/tools"))
    import check_required_gate_idempotence_launcher_distribution_v0 as checker
    containment = checker.host.containment

    def control(name):
        return originals["controls/" + name]

    bootstrap_inputs = {}
    for stem in ("runtime_selection", "operator_selection", "bootstrap_selection"):
        name = "controls/" + stem.replace("_", "-") + ".json"
        bootstrap_inputs[stem + "_bytes"] = originals[name]
        bootstrap_inputs["expected_" + stem + "_sha256"] = manifest["files"][name]["sha256"]
    bootstrap_inputs["capsule_bytes"] = originals[manifest["capsule"]]
    bootstrap_inputs["expected_capsule_sha256"] = manifest["files"][manifest["capsule"]]["sha256"]
    bootstrap = containment.bootstrap.prepare_bootstrap(**bootstrap_inputs)
    containment.bootstrap.verify_bootstrap_plan(plan_bytes=control("bootstrap-plan.json"),
        expected_plan_sha256=manifest["files"]["controls/bootstrap-plan.json"]["sha256"], **bootstrap_inputs)
    prepared = containment.prepare_containment(bootstrap_prepared=bootstrap,
        expected_bootstrap_plan_sha256=manifest["files"]["controls/bootstrap-plan.json"]["sha256"],
        selection_bytes=control("containment-selection.json"),
        expected_selection_sha256=manifest["files"]["controls/containment-selection.json"]["sha256"],
        launcher_bytes=originals["native/bwrap"], entry_bytes=originals["entry-build/build-1/entry"])
    containment.verify_request(prepared, request_bytes=control("containment-request.json"),
        expected_request_sha256=manifest["files"]["controls/containment-request.json"]["sha256"])
    host_inputs = {
        "containment_prepared": prepared,
        "expected_containment_request_sha256": manifest["files"]["controls/containment-request.json"]["sha256"],
        "selection_bytes": control("launch-host-selection.json"),
        "expected_selection_sha256": manifest["files"]["controls/launch-host-selection.json"]["sha256"],
        "entry_build_payload": {name: originals["entry-build/" + name] for name in manifest["entry_build_paths"]},
        "launcher_package_bytes": originals[manifest["package"]],
        "native_payload": {name: originals[name] for name in manifest["native_paths"]},
        "host_observation_bytes": control("host-observation.json"),
    }
    return checker, {
        "launch_host_inputs": host_inputs,
        "launch_host_plan_bytes": originals["launch-host-plan.json"],
        "expected_launch_host_plan_sha256": manifest["files"]["launch-host-plan.json"]["sha256"],
        "selection_bytes": control("distribution-selection.json"),
        "expected_selection_sha256": manifest["files"]["controls/distribution-selection.json"]["sha256"],
        "trust_policy_bytes": control("distribution-trust-policy.json"),
        "expected_trust_policy_sha256": manifest["files"]["controls/distribution-trust-policy.json"]["sha256"],
        "release_bytes": originals["distribution-origin/Release"],
        "release_signature_bytes": originals["distribution-origin/Release.gpg"],
        "packages_xz_bytes": originals["distribution-origin/Packages.xz"],
        "keyring_bytes": originals["distribution-origin/debian-archive-keyring.gpg"],
        "verifier_path": Path(manifest["external_verifier"]["path"]),
        "signature_evidence_sink": sink,
    }


def check_unchanged_sources(manifest):
    for name, expected in manifest["files"].items():
        if name.startswith("verifier-source/") or name == "replay.py":
            require(binding(read_regular(CASE / name, FILE_LIMIT)) == expected,
                    "example_source_changed:" + name)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest-sha256", required=True)
    parser.add_argument("--evidence-directory", required=True, type=Path)
    args = parser.parse_args()
    manifest, originals = load_case(args.manifest_sha256)
    guard = install_guards(manifest, originals)
    sink = EvidenceSink(args.evidence_directory)
    try:
        checker, inputs = original_inputs(manifest, originals, sink)
        record = originals["launcher-distribution-record.json"]
        report = checker.verify_record(record_bytes=record,
            expected_record_sha256=manifest["files"]["launcher-distribution-record.json"]["sha256"], **inputs)
        parsed_record = checker.parse(record)
        require(parsed_record["bindings"]["launch_host_verification"] ==
                manifest["files"]["launch-host-verification.json"], "example_old_report_changed")
        require(parsed_record["bindings"]["packages_decoded"] ==
                manifest["files"]["distribution-origin/Packages"], "example_decoded_index_changed")
        require(report["status"] == "accepted" and report["record_status"] == "example"
                and sink.calls == guard["allowed_process_count"] == 1, "example_replay_not_accepted")
        require(all(type(report[key]) is type(value) and report[key] == value
                    for key, value in checker.BOUNDARY.items()), "example_boundary_changed")
        check_unchanged_sources(manifest)
        sys.stdout.buffer.write(checker.canonical(report))
        return 0
    finally:
        sink.close()


if __name__ == "__main__":
    raise SystemExit(main())
