from pathlib import Path
p=Path('/mnt/data/step5b_reference_verification/tools/verify_reference.py');src=p.read_text()
exec(compile(src[:src.index('require(subprocess.check_output')],str(p),'exec'),globals())
import copy
sys.path.insert(0,str(REPO/'tools'))
import check_pulsemech_compute_bounded_execution_v0 as v
MUT=BASE/'mutations';MUT.mkdir(exist_ok=False)
original=(IN/'capture.zip').read_bytes();members=v.unpack(original);cap=v.parse(members['capture.json'])
context=v.parse((IN/'expected_context_external.json').read_bytes());h=(IN/'expected_prelaunch_external.sha256').read_text().strip()
results=[]
def save_mut(name,m,c):
 # Repair the manifest/ZIP to reach semantic rejection rather than accidental CRC damage.
 c['member_inventory']=[v.descriptor(n,b) for n,b in sorted(m.items()) if n!='capture.json']
 m['capture.json']=v.canonical(c)
 path=MUT/(name+'.zip');path.write_bytes(v.pack(m));return path
cases=[]
wrong=dict(context);wrong['run_id']+=1;wrong['acquisition_id']=f"github:{wrong['repository']}:{wrong['run_id']}:1"
cp=MUT/'wrong_run_context.json';cp.write_bytes(v.canonical(wrong))
cases.append(('cross_run_context',IN/'capture.zip',cp,h))
cases.append(('wrong_prelaunch_digest',IN/'capture.zip',IN/'expected_context_external.json','0'*64))
m=dict(members);c=copy.deepcopy(cap);m['sources/'+v.CHECKER]+=b'\n# mutation for verifier rejection\n'
cases.append(('altered_committed_source_bytes',save_mut('altered_committed_source_bytes',m,c),IN/'expected_context_external.json',h))
m=dict(members);c=copy.deepcopy(cap);c['executions'].pop()
cases.append(('missing_execution',save_mut('missing_execution',m,c),IN/'expected_context_external.json',h))
m=dict(members);c=copy.deepcopy(cap);c['executions'][0],c['executions'][2]=c['executions'][2],c['executions'][0]
cases.append(('wrong_occurrence_order',save_mut('wrong_occurrence_order',m,c),IN/'expected_context_external.json',h))
m=dict(members);c=copy.deepcopy(cap)
for item in c['executions'][1]['sealed_inputs']:
 if item['logical_role']=='result':
  other=m['results/block_false/process_result.json'];item['sha256']=sha(other);item['size_bytes']=len(other)
cases.append(('cross_case_consumer_input',save_mut('cross_case_consumer_input',m,c),IN/'expected_context_external.json',h))
m=dict(members);c=copy.deepcopy(cap);c['executions'][0]['source_sha256']='0'*64
cases.append(('forged_execution_source_digest',save_mut('forged_execution_source_digest',m,c),IN/'expected_context_external.json',h))
m=dict(members);c=copy.deepcopy(cap);name='results/block_false/terminal_state.json'
t=v.parse(m[name]);t['state']='ready';m[name]=v.canonical(t);c['executions'][3]['stdout']=v.descriptor(name,m[name])
cases.append(('block_promoted_to_ready',save_mut('block_promoted_to_ready',m,c),IN/'expected_context_external.json',h))
for label,carrier,ctx,ph in cases:
 args=[sys.executable,'-I','-B',str(REPO/v.VALIDATOR),'--repository-root',str(REPO),'--expected-context',str(ctx),'--expected-prelaunch-sha256',ph,'--carrier',str(carrier)]
 r,out,err=command('negative_'+label,args,120)
 d=json.loads(out);require(r['exit_code']==2 and d.get('ok') is False,'Negative accepted: '+label)
 results.append({'scenario':label,'entrypoint':'capture_validator_cli','exit_code':r['exit_code'],'error':d.get('error'),
  'carrier_sha256':sha(carrier.read_bytes()),'context_sha256':sha(ctx.read_bytes()),'expected_prelaunch_sha256':ph,'rejected':True})
# Full connected reconstruction must propagate a consumer-binding failure without output.
label='connected_reconstruction_rejects_wrong_consumer';dest=OUT/'must_not_exist_after_rejection.zip';require(not dest.exists(),'Preexisting rejection path')
carrier=MUT/'cross_case_consumer_input.zip'
args=[sys.executable,'-I','-B',str(REPO/v.ADAPTER),'reconstruct','--repository-root',str(REPO),'--expected-context',str(IN/'expected_context_external.json'),'--expected-prelaunch-sha256',h,'--carrier',str(carrier),'--analysis-run-key','analysis:bounded:'+sha(carrier.read_bytes()),'--output',str(dest)]
r,out,err=command('negative_'+label,args,180);require(r['exit_code']==2 and not dest.exists(),'Rejected reconstruction left output')
results.append({'scenario':label,'entrypoint':'reconstruction_cli','exit_code':2,'error':err.decode().strip(),'no_output':True,'rejected':True})
# A valid full reconstruction may not replace an unrelated pre-existing output.
label='existing_output_preserved';dest=OUT/'publication_sentinel.zip';sentinel=b'UNRELATED EXISTING OUTPUT -- MUST REMAIN BYTE IDENTICAL\n';dest.write_bytes(sentinel)
args=[sys.executable,'-I','-B',str(REPO/v.ADAPTER),'reconstruct','--repository-root',str(REPO),'--expected-context',str(IN/'expected_context_external.json'),'--expected-prelaunch-sha256',h,'--carrier',str(IN/'capture.zip'),'--analysis-run-key','analysis:bounded:'+sha(original),'--output',str(dest)]
r,out,err=command('negative_'+label,args,480);require(r['exit_code']==2 and dest.read_bytes()==sentinel,'Publication replaced unrelated output')
results.append({'scenario':label,'entrypoint':'reconstruction_cli','exit_code':2,'error':err.decode().strip(),'sentinel_sha256':sha(sentinel),'existing_bytes_preserved':True,'rejected':True})
require((IN/'capture.zip').read_bytes()==original,'Original capture changed')
require(sha(ART.read_bytes())=='2601a68b864779b8cf99a6a2bc0fdb48c994b95067f098354d35e86e7ff178f6','Original artifact changed')
require(subprocess.check_output(['git','status','--porcelain'],cwd=REPO)==b'','Source changed')
save('negative_verification_record.json',{'status':'passed','scenario_count':len(results),'cases':results,'permanent_repository_test_registration_changed':False,'original_artifact_unchanged':True,'source_checkout_clean':True})
print(json.dumps(results,indent=2),flush=True)
