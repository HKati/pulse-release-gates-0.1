"""Verify preserved acquisition without invoking capture/run-reference.
External metadata below comprises selected connector fields, not raw HTTP bytes.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,os,platform,subprocess,sys,time,zipfile,importlib.metadata
BASE=Path('/mnt/data/step5b_reference_verification');REPO=BASE/'source/repository';IN=BASE/'inputs';OUT=BASE/'outputs';EV=BASE/'evidence'
REV='c32508f8afb58381225fec0b426b85b00e32fe11';TREE='74dd65d82124170b7d8f459925962bb8bc09fe2b'
ART=Path('/mnt/data/pulsemech-bounded-reference-34402387728-1.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
canonical=lambda d:(json.dumps(d,sort_keys=True,indent=2,ensure_ascii=False)+'\n').encode()
def now():return datetime.now(timezone.utc).isoformat()
def save(n,v): (EV/n).write_bytes(canonical(v))
def require(ok,m):
 if not ok:raise RuntimeError(m)
def command(label,args,timeout=480):
 start=now();t=time.monotonic()
 try:
  p=subprocess.run(args,cwd=OUT,stdin=subprocess.DEVNULL,capture_output=True,timeout=timeout,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1','GIT_NO_REPLACE_OBJECTS':'1','GIT_CONFIG_NOSYSTEM':'1','GIT_CONFIG_GLOBAL':'/dev/null'})
  rc,stdout,stderr=p.returncode,p.stdout,p.stderr
 except subprocess.TimeoutExpired as e:rc,stdout,stderr=None,e.stdout or b'',e.stderr or b''
 (EV/(label+'.stdout')).write_bytes(stdout);(EV/(label+'.stderr')).write_bytes(stderr)
 r={'label':label,'args':args,'cwd':str(OUT),'started_at':start,'finished_at':now(),'elapsed_seconds':round(time.monotonic()-t,6),'exit_code':rc,'stdout_sha256':sha(stdout),'stderr_sha256':sha(stderr)}
 save(label+'.command.json',r);print(label,'exit',rc,'seconds',r['elapsed_seconds'],flush=True)
 return r,stdout,stderr
require(subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO).decode().strip()==REV,'Wrong checkout')
require(subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO).decode().strip()==TREE,'Wrong tree')
require(subprocess.check_output(['git','status','--porcelain'],cwd=REPO)==b'','Dirty checkout')
save('environment.json',{'python':sys.version,'executable':sys.executable,'platform':platform.platform(),'git':subprocess.check_output(['git','--version']).decode().strip(),'dependencies':{n:importlib.metadata.version(n) for n in ('jsonschema','PyYAML','pytest')},'recorded_at':now()})
run={'id':34402387728,'run_number':1,'run_attempt':1,'repository':'HKati/pulse-release-gates-0.1','repository_id':1061766508,'head_branch':'main','head_sha':REV,'tree':TREE,'name':'PULSEmech bounded execution reference','path':'.github/workflows/pulsemech_compute_bounded_execution_reference.yml','event':'workflow_dispatch','status':'completed','conclusion':'success','actor':'HKati','created_at':'2026-09-09T20:39:49Z','updated_at':'2026-09-09T20:40:38Z'}
artifact={'id':10123984621,'name':'pulsemech-bounded-reference-34402387728-1','size_in_bytes':3270026,'digest':'sha256:2601a68b864779b8cf99a6a2bc0fdb48c994b95067f098354d35e86e7ff178f6','workflow_run_id':run['id'],'head_sha':REV,'head_branch':'main','expired':False,'created_at':'2026-09-09T20:40:34Z','expires_at':'2026-12-08T20:39:51Z'}
job={'id':102637163024,'run_id':run['id'],'run_attempt':1,'head_sha':REV,'name':'Capture and verify non-active bounded reference','conclusion':'success','started_at':'2026-09-09T20:39:54Z','completed_at':'2026-09-09T20:40:37Z','execution_step':{'number':5,'name':'Execute reviewed finite reference and reconstruct outputs','started_at':'2026-09-09T20:40:06Z','completed_at':'2026-09-09T20:40:32Z','conclusion':'success'},'preservation_step':{'number':6,'name':'Preserve non-active reference evidence','conclusion':'success'}}
api='https://api.github.com/repos/'+run['repository']
save('github_metadata_selected.json',{'record_type':'selected_connector_fields_not_raw_HTTP','retrieved_in_this_review':True,'source_endpoints':[api+'/actions/runs/34402387728/attempts/1',api+'/actions/runs/34402387728/attempts/1/jobs?per_page=10',api+'/actions/runs/34402387728/artifacts?per_page=10'],'run':run,'job':job,'artifact':artifact,'authentication_boundary':'Connected GitHub API metadata; not a signed execution attestation'})
# Derived from the independent GitHub fields above, not from the artifact context.
context={'acquisition_id':f"github:{run['repository']}:{run['id']}:{run['run_attempt']}",'event_name':run['event'],'record_status':'observed','repository':run['repository'],'run_attempt':run['run_attempt'],'run_id':run['id'],'run_number':run['run_number'],'source_commit':run['head_sha'],'workflow_name':run['name'],'workflow_path':run['path']}
(IN/'expected_context_external.json').write_bytes(canonical(context))
raw=ART.read_bytes();require(len(raw)==artifact['size_in_bytes'] and sha(raw)==artifact['digest'].split(':')[1],'Artifact metadata mismatch')
with zipfile.ZipFile(io.BytesIO(raw)) as z:
 require(z.namelist()==['reference_capsule_v0.zip'],'Outer artifact membership')
 i=z.infolist()[0];require(i.file_size<16*1024*1024 and not i.flag_bits&1,'Outer artifact limits');capsule=z.read(i)
(IN/'reference_capsule_v0.zip').write_bytes(capsule)
# Modules are read from the complete Git-authenticated tree, not executed from ZIP.
sys.path.insert(0,str(REPO/'tools'))
import check_pulsemech_compute_bounded_execution_v0 as v
members=v.unpack(capsule)
require(set(members)=={'SHA256SUMS','capture.zip','expected_context.json','expected_prelaunch.sha256','prepared.zip','reconstruction.zip'},'Capsule inventory')
require(members['SHA256SUMS']==''.join(sha(b)+'  '+n+'\n' for n,b in sorted(members.items()) if n!='SHA256SUMS').encode(),'Payload hashes')
require(members['expected_context.json']==canonical(context),'External context mismatch')
for n,b in members.items():(IN/n).write_bytes(b)
prepared=v.unpack(members['prepared.zip']);capture=v.unpack(members['capture.zip'])
require(set(prepared).issubset(capture) and all(capture[n]==b for n,b in prepared.items()),'Preparation/capture mismatch')
prelaunch=v.parse(prepared['prelaunch.json']);h=sha(prepared['prelaunch.json'])
require(members['expected_prelaunch.sha256']==(h+'\n').encode(),'Prelaunch digest file mismatch')
sources=v.git_source_inventory(REPO,REV,tuple(v.SOURCE_PATHS));rows=[]
for path,b in sorted(sources.items()):
 require((REPO/path).read_bytes()==b==prepared['sources/'+path]==capture['sources/'+path],'Source mismatch: '+path)
 rows.append({'path':path,'size_bytes':len(b),'sha256':sha(b),'git_blob':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'all_four_views_match':True})
save('source_inventory_check.json',{'commit':REV,'tree':TREE,'source_count':len(rows),'sources':rows,'full_tree_available':True,'full_ancestor_history_claimed':False})
# Preserve the recorded creation timestamp as a declared scalar, not a new clock observation.
prep_code='import sys\nfrom pathlib import Path\nsys.path.insert(0,sys.argv[1]+"/tools")\nimport build_pulsemech_compute_bounded_execution_inputs_v0 as a\nv=a.verify\nc=v.parse(Path(sys.argv[2]).read_bytes())\nr=a.prepare(repository_root=Path(sys.argv[1]),context=c,created_at_utc=sys.argv[3])\nv.publish_new(Path(sys.argv[4]),r,repository_root=Path(sys.argv[1]))\nprint(v.sha(r))\n'
wrapper=BASE/'tools/replay_preparation.py';wrapper.write_text(prep_code)
r,_,err=command('preparation_replay',[sys.executable,'-I','-B',str(wrapper),str(REPO),str(IN/'expected_context_external.json'),prelaunch['created_at_utc'],str(OUT/'prepared_replayed.zip')])
require(r['exit_code']==0,'Preparation failed: '+err.decode())
require((OUT/'prepared_replayed.zip').read_bytes()==members['prepared.zip'],'Prepared bytes differ')
external_h=sha(v.unpack((OUT/'prepared_replayed.zip').read_bytes())['prelaunch.json']);require(external_h==h,'Reconstructed prelaunch identity')
(IN/'expected_prelaunch_external.sha256').write_text(external_h+'\n')
common=['--repository-root',str(REPO),'--expected-context',str(IN/'expected_context_external.json'),'--expected-prelaunch-sha256',external_h,'--carrier',str(IN/'capture.zip')]
for n in (1,2):
 r,out,err=command(f'capture_validation_{n}',[sys.executable,'-I','-B',str(REPO/v.VALIDATOR),*common])
 require(r['exit_code']==0 and json.loads(out)['ok'] is True,'Capture validation failed: '+out.decode())
for n in (1,2):
 r,out,err=command(f'reconstruction_{n}',[sys.executable,'-I','-B',str(REPO/v.ADAPTER),'reconstruct',*common,'--analysis-run-key','analysis:bounded:'+sha(members['capture.zip']),'--output',str(OUT/f'reconstruction_{n}.zip')])
 require(r['exit_code']==0,'Reconstruction failed: '+err.decode())
 rr=(OUT/f'reconstruction_{n}.zip').read_bytes();require(out.decode().strip()==sha(rr),'Reconstruction output digest');require(rr==members['reconstruction.zip'],'Reconstruction differs from acquired bytes')
original=v.unpack(members['reconstruction.zip']);one=v.unpack((OUT/'reconstruction_1.zip').read_bytes());two=v.unpack((OUT/'reconstruction_2.zip').read_bytes())
require(set(original)==set(one)==set(two),'Derived inventories differ');results=[]
for name,b in original.items():
 require(b==one[name]==two[name],'Derived bytes differ: '+name)
 results.append({'path':name,'size_bytes':len(b),'sha256':sha(b),'matches_acquired':True,'replay_1_equals_replay_2':True})
checked=v.verify_capture(members['capture.zip'],repository_root=REPO,expected_context=context,expected_prelaunch_sha256=external_h)
start=datetime.fromisoformat(checked.capture['started_at_utc']);end=datetime.fromisoformat(checked.capture['completed_at_utc'])
require(datetime.fromisoformat(job['execution_step']['started_at'])<=datetime.fromisoformat(prelaunch['created_at_utc'])<=start<=end<=datetime.fromisoformat(job['execution_step']['completed_at']),'Time outside GitHub execution step')
record={'record_type':'local_source_bound_reference_verification_v0','recorded_at':now(),'status':'passed','source_commit':REV,'source_tree':TREE,'run_id':run['id'],'attempt':1,'job_id':job['id'],'artifact_id':artifact['id'],'artifact':{'size_bytes':len(raw),'sha256':sha(raw),'github_metadata_match':True},'capsule':{'size_bytes':len(capsule),'sha256':sha(capsule),'members':len(members),'payload_hashes_verified':5},'prepared':{'size_bytes':len(members['prepared.zip']),'sha256':sha(members['prepared.zip']),'member_count':len(prepared),'exact_recipe_reconstruction':True},'capture':{'size_bytes':len(members['capture.zip']),'sha256':sha(members['capture.zip']),'member_count':len(capture),'execution_count':len(checked.capture['executions']),'started_at_utc':checked.capture['started_at_utc'],'completed_at_utc':checked.capture['completed_at_utc']},'prelaunch':{'sha256':external_h,'recorded_creation_timestamp':prelaunch['created_at_utc'],'anchor_method':'Preparation replay using authenticated sources, external GitHub context and preserved declared creation timestamp','independent_pre_acquisition_timestamp_attestation':False},'source_count':len(sources),'cases':list(checked.case_outcomes),'reconstruction':{'size_bytes':len(members['reconstruction.zip']),'sha256':sha(members['reconstruction.zip']),'separate_cli_processes':2,'full_zip_matches_acquired':True,'derived_members':results},'local_runtime':platform.python_version(),'no_new_subject_acquisition':True,'authority_effect':'none','same_run_release_authority_eligible':False,'active_gate_eligible':False}
save('positive_verification_record.json',record)
require(ART.read_bytes()==raw,'Original artifact changed');require(subprocess.check_output(['git','status','--porcelain'],cwd=REPO)==b'','Checkout changed')
print(json.dumps({'status':'PASS','sources':len(sources),'derived_members':len(results),'cases':record['cases']},indent=2),flush=True)
