"""Transport the exact GitHub-returned signed commit; fail on any byte mismatch.
The payload/signature below were transcribed from GitHub Git-data GET in this
review, not manufactured as a replacement commit. Root tree is independently
fixed by the same GitHub response. PGP verification itself is GitHub-reported.
"""
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/mnt/data/step5b_reference_verification')
REPO=ROOT/'source/repository'
REV='c32508f8afb58381225fec0b426b85b00e32fe11'
TREE='74dd65d82124170b7d8f459925962bb8bc09fe2b'
message='''feat(compute): observe bounded reference execution (#2876)

Implement the Step 5B bounded reference execution path from #2875
and implementation-decision comment 5590191931.

Connect actual executions of the unchanged strict checker and a
separate result consumer to the existing subject-input producer,
immutable bridge, single analyzer core, source-aware report/relation
validators and separate non-active candidate materializer.

Bind exact source and input bytes, sealed-descriptor execution,
predeclared occurrences, actual process results and downstream
consumption within the finite reference boundary.

Preserve checker exits 0, 1 and 2 and their distinct reference outcomes.
Successful consumer execution or candidate materialization does not
turn a checker BLOCK into ALLOW or authorize a production release.

Include the manual-only reference workflow, independent evidence
validation, deterministic reconstruction and permanent regressions.

Include the review and CI integration corrections:
- Commit the required workflow at its canonical source-inventory path.
- Capture bounded expected-context bytes before parsing and reuse the
  same immutable snapshot through downstream validation.
- Isolate verified historical dependencies in the private producer
  test fixture without changing frozen source pins or evidence.
- Support the original and profiled subject-schema layouts while
  preserving complete-schema and selected-branch validation.
- Align the reference workflow with the repository's Python 3.11
  requirement without weakening the hygiene guard.
- Classify the exact bounded-reference workflow as a non-active
  diagnostic carrier while retaining unknown-workflow warnings.

Final scope: 39 paths, comprising 31 modifications and eight additions.
No deletions or file-mode changes.
The smoke registry contains 154 unique programs; the separate targeted
pytest manifest remains unchanged at 15 programs.

Preserve the generic checker, active policy and gate registry,
historical #6066 evidence and producer pins, existing Step 3F/3G
workflows, ledgers, iPhone code, README and Zenodo/DOI metadata.

This is an implementation merge, not reference-acquisition acceptance.
Keep #2875 open for the separately reviewed manual execution,
exact evidence preservation, independent replay and bounded acceptance.

The merge does not dispatch the reference workflow, activate a compute
gate, introduce resource measurement or budgeting, grant deployment
admission, or declare full Step 5 or Steps 6/7 complete.

authority_effect: none
same_run_release_authority_eligible: false
active_gate_eligible: false

Refs #2875.
Implements decision comment 5590191931.'''
headers='''tree 74dd65d82124170b7d8f459925962bb8bc09fe2b
parent 0abfe6a2b000ad02545d4128115b17c13f9bf8e3
author EPLabsAI <128643840+HKati@users.noreply.github.com> 1788968213 +0200
committer GitHub <noreply@github.com> 1788968213 +0200'''
signature='''-----BEGIN PGP SIGNATURE-----

wsFcBAABCAAQBQJqoX0VCRC1aQ7uu5UhlAAAEFoQAGbXOECsGAy0hvWbeG9OkdwU
H+lLG/mZMjR2J59gUIC4FC7YgAdgOnsCMcYjQKp5s2qnSKU5MuMW3rONU0PQvy6r
DzRdbAXvRZbPX6Q/VQh++l/M2nKSeIL5r3LVVGMuwLONUrCYDv9sju1nZuWeHqvg
XYQFnc8cvl/KNzJ3ShOmr9HmmxclCJzXXRw+5gYxnO60fZ+9gQhNRs/vtTxIWRin
fY0UduLY/34DK3jxmJZeBg8DnFiAOEbHOdK/mzc93J5K5VkSGsBdlXN0TKMFtenA
yfz3fQZ6aZl2KnUOa2Y9lVT/JCNBj8qpLYZTKYKLQxcZhiQK+Ul03tvsDDdhdnWK
tn1nAcwLxFDG9mqnPzUzOkXSzMlxQ2V+3bSCP42E1jhCZOGWWk8lWZ99UR+4UOb2
kcex2Uv05ksnkm8Q8riZTKsud6M1iyeRJrOsSUnc9Tjmx9GgMr4jQ83XBY4dVTx0
/11ROSr+knmd8KB1PgpX8hcQYQvrouGaHVMw7AkycnzvJrAkyLcf9Qfv/CXtwgJZ
EUL2WswnKSX57AGjBt9DDZSauvW8L5ts8v9F0PqZbziKmH1mYwYuNIB2l7+aBIV1
yLsTK5ncYn3FE+OimawSnejzCsbKwsr9aZa5/8aF1eiuhu6NVznDBzy13DsvQhew
ywxi4gRQCbCDNJ3DNkxV
=sOOq
-----END PGP SIGNATURE-----
'''
payload=headers+'\n\n'+message
# Git continuation lines preserve the final empty signature line.
raw=(headers+'\ngpgsig '+signature.replace('\n','\n ')+'\n\n'+message).encode()
# GitHub's signature ends LF, which becomes a trailing continuation ' ' line.
actual=hashlib.sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
print('commit object',actual,len(raw))
if actual!=REV:
 raise RuntimeError('Exact commit transport mismatch; no import permitted')
(ROOT/'evidence/github_commit_signature.asc').write_text(signature)
(ROOT/'evidence/github_commit_payload.txt').write_text(payload)
(ROOT/'evidence/source_commit.raw').write_bytes(raw)
record={'record_type':'connector_commit_field_transcription','source_endpoint':f'https://api.github.com/repos/HKati/pulse-release-gates-0.1/git/commits/{REV}',
        'sha':REV,'tree':TREE,'verification':{'verified':True,'reason':'valid','verified_at':'2026-09-09T15:36:54Z','signature':signature,'payload':payload},
        'raw_commit_size':len(raw),'raw_commit_sha256':hashlib.sha256(raw).hexdigest(),
        'local_git_object_hash_matches':actual==REV,'local_pgp_verification_performed':False}
(ROOT/'evidence/source_commit_transport.json').write_text(json.dumps(record,indent=2)+'\n')
r=subprocess.run(['git','hash-object','-w','-t','commit','--stdin'],cwd=REPO,input=raw,capture_output=True,check=True)
assert r.stdout.decode().strip()==REV
assert subprocess.check_output(['git','rev-parse',REV+'^{tree}'],cwd=REPO).decode().strip()==TREE
# Prepared index already matches this exact upstream tree; no source edits now.
subprocess.run(['git','checkout','--detach',REV],cwd=REPO,check=True)
assert subprocess.check_output(['git','status','--porcelain'],cwd=REPO)==b''
print('Pinned genuine commit and complete matching tree, clean checkout')
