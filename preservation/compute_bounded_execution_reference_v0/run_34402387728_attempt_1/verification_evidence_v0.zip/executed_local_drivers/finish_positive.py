from pathlib import Path
# Reuse only the definitions preceding the first runtime check, not the driver.
p=Path('/mnt/data/step5b_reference_verification/tools/verify_reference.py')
source=p.read_text();cut=source.index('require(subprocess.check_output')
exec(compile(source[:cut],str(p),'exec'),globals())
import concurrent.futures
sys.path.insert(0,str(REPO/'tools'))
import check_pulsemech_compute_bounded_execution_v0 as v
context=v.parse((IN/'expected_context_external.json').read_bytes())
h=(IN/'expected_prelaunch_external.sha256').read_text().strip()
raw=ART.read_bytes();capsule=(IN/'reference_capsule_v0.zip').read_bytes();members=v.unpack(capsule)
prepared=v.unpack(members['prepared.zip']);capture=v.unpack(members['capture.zip']);prelaunch=v.parse(prepared['prelaunch.json'])
metadata=json.loads((EV/'github_metadata_selected.json').read_bytes());run=metadata['run'];job=metadata['job'];artifact=metadata['artifact']
rows=json.loads((EV/'source_inventory_check.json').read_bytes())['sources'];sources={r['path']:r for r in rows}
save('initial_interrupted_reconstruction.json',{'status':'interrupted_by_tool_execution_timeout','tool_wall_clock_limit_seconds':120,
 'driver_log':'verification_driver.log','completed_commands':['preparation_replay','capture_validation_1','capture_validation_2'],
 'unfinished_command':'reconstruction_1','reconstruction_exit_code':None,'output_file_present':(OUT/'reconstruction_1.zip').exists(),
 'disposition':'not_pass; fresh reconstruction processes below have separate recorded results'})
common=['--repository-root',str(REPO),'--expected-context',str(IN/'expected_context_external.json'),'--expected-prelaunch-sha256',h,'--carrier',str(IN/'capture.zip')]
def replay(n):
 label=f'reconstruction_{n}_completed_attempt'
 dest=OUT/f'reconstruction_{n}.zip'
 require(not dest.exists(),'Output already exists')
 r,out,err=command(label,[sys.executable,'-I','-B',str(REPO/v.ADAPTER),'reconstruct',*common,
   '--analysis-run-key','analysis:bounded:'+sha(members['capture.zip']),'--output',str(dest)],timeout=600)
 require(r['exit_code']==0,'Reconstruction failed: '+err.decode())
 b=dest.read_bytes();require(out.decode().strip()==sha(b),'Output digest');require(b==members['reconstruction.zip'],'Acquired bytes differ')
 return b
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 rr=list(pool.map(replay,(1,2)))
original=v.unpack(members['reconstruction.zip']);one=v.unpack(rr[0]);two=v.unpack(rr[1]);results=[]
require(set(original)==set(one)==set(two),'Derived inventory')
for n,b in original.items():
 require(b==one[n]==two[n],'Derived bytes differ')
 results.append({'path':n,'size_bytes':len(b),'sha256':sha(b),'matches_acquired':True,'replay_1_equals_replay_2':True})
checked=v.verify_capture(members['capture.zip'],repository_root=REPO,expected_context=context,expected_prelaunch_sha256=h)
start=datetime.fromisoformat(checked.capture['started_at_utc']);end=datetime.fromisoformat(checked.capture['completed_at_utc'])
require(datetime.fromisoformat(job['execution_step']['started_at'])<=datetime.fromisoformat(prelaunch['created_at_utc'])<=start<=end<=datetime.fromisoformat(job['execution_step']['completed_at']),'Time outside GitHub step')
record={'record_type':'local_source_bound_reference_verification_v0','recorded_at':now(),'status':'passed','source_commit':REV,'source_tree':TREE,
 'run_id':run['id'],'attempt':1,'job_id':job['id'],'artifact_id':artifact['id'],
 'artifact':{'size_bytes':len(raw),'sha256':sha(raw),'github_metadata_match':True},
 'capsule':{'size_bytes':len(capsule),'sha256':sha(capsule),'members':len(members),'payload_hashes_verified':5},
 'prepared':{'size_bytes':len(members['prepared.zip']),'sha256':sha(members['prepared.zip']),'member_count':len(prepared),'exact_recipe_reconstruction':True},
 'capture':{'size_bytes':len(members['capture.zip']),'sha256':sha(members['capture.zip']),'member_count':len(capture),'execution_count':len(checked.capture['executions']),
  'started_at_utc':checked.capture['started_at_utc'],'completed_at_utc':checked.capture['completed_at_utc']},
 'prelaunch':{'sha256':h,'recorded_creation_timestamp':prelaunch['created_at_utc'],
  'anchor_method':'Exact preparation replay using authenticated source, external GitHub context and preserved declared creation timestamp',
  'independent_pre_acquisition_timestamp_attestation':False},'source_count':len(sources),'cases':list(checked.case_outcomes),
 'reconstruction':{'size_bytes':len(members['reconstruction.zip']),'sha256':sha(members['reconstruction.zip']),
  'completed_separate_cli_processes':2,'earlier_interrupted_process_count':1,'full_zip_matches_acquired':True,'derived_members':results},
 'local_runtime':platform.python_version(),'no_new_subject_acquisition':True,'authority_effect':'none',
 'same_run_release_authority_eligible':False,'active_gate_eligible':False}
save('positive_verification_record.json',record)
require(ART.read_bytes()==raw,'Original changed');require(subprocess.check_output(['git','status','--porcelain'],cwd=REPO)==b'','Checkout changed')
print(json.dumps({'status':'PASS','sources':len(sources),'derived_members':len(results),'cases':record['cases']},indent=2),flush=True)
