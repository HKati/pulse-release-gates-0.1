from pathlib import Path
import hashlib,json,os,subprocess
b=Path('/mnt/data/step5b_reference_verification');r=b/'source/repository';out=b/'evidence/reviewed_source_snapshot.pack'
rev='c32508f8afb58381225fec0b426b85b00e32fe11';tree='74dd65d82124170b7d8f459925962bb8bc09fe2b'
entries=subprocess.check_output(['git','ls-tree','-r','-t','-z',rev],cwd=r).split(b'\0')
ids={rev,tree}; files=0
for e in entries:
 if not e:continue
 meta,path=e.split(b'\t',1);mode,kind,oid=meta.split();ids.add(oid.decode())
 if kind==b'blob':files+=1
assert files==1396
with out.open('wb') as f:
 p=subprocess.run(['git','pack-objects','--stdout'],cwd=r,input=('\n'.join(sorted(ids))+'\n').encode(),stdout=f,stderr=subprocess.PIPE,check=True)
test=b/'source/snapshot_transport_test';assert not test.exists()
subprocess.run(['git','init','-q',str(test)],check=True)
with out.open('rb') as f:
 p=subprocess.run(['git','index-pack','--stdin'],cwd=test,stdin=f,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=True)
subprocess.run(['git','checkout','-q','--detach',rev],cwd=test,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=test).decode().strip()==tree
assert subprocess.check_output(['git','status','--porcelain'],cwd=test)==b''
assert subprocess.check_output(['git','ls-tree','-r','-t','-z',rev],cwd=r)==subprocess.check_output(['git','ls-tree','-r','-t','-z',rev],cwd=test)
# Read every object by the original ID and compare exact bytes. No substitute commit.
for oid in ids:
 typ=subprocess.check_output(['git','cat-file','-t',oid],cwd=test).decode().strip()
 a=subprocess.check_output(['git','cat-file',typ,oid],cwd=r);c=subprocess.check_output(['git','cat-file',typ,oid],cwd=test)
 assert a==c
record={'record_type':'exact_source_snapshot_transport','source_commit':rev,'source_tree':tree,'object_count':len(ids),'tracked_file_count':files,
 'pack_size_bytes':out.stat().st_size,'pack_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
 'complete_tree_and_blob_snapshot':True,'includes_ancestors':False,'not_a_full_history_clone':True,'independent_unpack_checkout_and_all_object_byte_comparison':'passed',
 'source_identity_anchor':'GitHub git/commits response; exact signed commit object matches upstream SHA-1; complete root tree matches GitHub-returned tree',
 'prior_preparation_bundle_is_only_a_content_transport':True,'synthetic_preparation_commits_in_pack':False}
(b/'evidence/reviewed_source_snapshot.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
