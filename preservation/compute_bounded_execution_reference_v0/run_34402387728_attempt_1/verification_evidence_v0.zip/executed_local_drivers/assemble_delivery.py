from pathlib import Path
from datetime import datetime,timezone
import hashlib,io,json,os,subprocess,zipfile,shutil
B=Path('/mnt/data/step5b_reference_verification');E=B/'evidence';R=B/'source/repository'
A=Path('/mnt/data/pulsemech-bounded-reference-34402387728-1.zip')
sha=lambda b:hashlib.sha256(b).hexdigest()
cj=lambda d:(json.dumps(d,ensure_ascii=False,sort_keys=True,indent=2)+'\n').encode()
positive=json.loads((E/'positive_verification_record.json').read_bytes());negative=json.loads((E/'negative_verification_record.json').read_bytes())
assert positive['status']==negative['status']=='passed'
assert negative['scenario_count']==10
with zipfile.ZipFile(B/'outputs/reconstruction_1.zip') as z:
 docs={n:json.loads(z.read(n)) for n in ['baseline.json','runtime.json','runtime_report.json','relation.json','candidate.json','report_diagnostic.json','relation_diagnostic.json','materialization.json']}
interp={'scope':docs['relation.json']['bounded_comparison']['scope'],
 'bounded_predicates':{'I':docs['relation.json']['bounded_comparison']['packet_integrity'],'E':docs['relation.json']['bounded_comparison']['extent_status'],'R':docs['relation.json']['bounded_comparison']['relational_coverage_status'],'C':docs['relation.json']['summary']['comparison_complete'],'M':docs['relation.json']['bounded_comparison']['resource_coverage_status']},
 'relation_summary':docs['relation.json']['summary'],'whole_runtime_packet_coverage':docs['runtime.json']['coverage'],
 'runtime_report_summary':docs['runtime_report.json']['summary'],'artifact_baseline_summary':docs['baseline.json']['summary'],
 'non_active_candidate_gates':docs['candidate.json']['gates'],
 'report_diagnostic':{'ok':docs['report_diagnostic.json']['ok'],'checks_true':sum(x is True for x in docs['report_diagnostic.json']['checks'].values()),'checks_total':len(docs['report_diagnostic.json']['checks'])},
 'relation_diagnostic':{'ok':docs['relation_diagnostic.json']['ok'],'checks_true':sum(x is True for x in docs['relation_diagnostic.json']['checks'].values()),'checks_total':len(docs['relation_diagnostic.json']['checks'])},
 'baseline_digest_bound_into_runtime_report':docs['runtime_report.json']['bounded_binding']['baseline_sha256']==sha(zipfile.ZipFile(B/'outputs/reconstruction_1.zip').read('baseline.json'))}
assert interp['bounded_predicates']=={'I':'complete','E':'complete','R':'complete','C':True,'M':'unavailable'}
(E/'derived_interpretation.json').write_bytes(cj(interp))
# Explicitly label field selections and earlier log excerpts rather than claiming raw HTTP/log preservation.
(E/'workflow_log_selected.txt').write_text('''Selected decoded lines from the connected GitHub job-log result in the preceding acquisition check.
Not a raw HTTP response, not the complete log, and not a separately signed attestation.
Job: 102637163024, run: 34402387728, attempt: 1.

2026-09-09T20:39:56.8828184Z   EXPECTED_SOURCE_COMMIT: c32508f8afb58381225fec0b426b85b00e32fe11
2026-09-09T20:39:56.8828649Z   CONTROL_PLANE_REVISION: c32508f8afb58381225fec0b426b85b00e32fe11
2026-09-09T20:39:56.8829390Z   CONTROL_PLANE_WORKFLOW_REF: HKati/pulse-release-gates-0.1/.github/workflows/pulsemech_compute_bounded_execution_reference.yml@refs/heads/main
2026-09-09T20:39:59.4666428Z c32508f8afb58381225fec0b426b85b00e32fe11
2026-09-09T20:39:59.7389857Z Successfully set up CPython (3.11.16)
2026-09-09T20:40:32.3519162Z f726c9c240512e6f13d34bebbcfa549696adff560ee718abae84f4f121d2bc7a
2026-09-09T20:40:33.8131606Z SHA256 digest of uploaded artifact is 2601a68b864779b8cf99a6a2bc0fdb48c994b95067f098354d35e86e7ff178f6
2026-09-09T20:40:34.2485640Z Artifact pulsemech-bounded-reference-34402387728-1 has been successfully uploaded! Final size is 3270026 bytes. Artifact ID is 10123984621
''')
transport=json.loads((E/'reviewed_source_snapshot.json').read_bytes())
readme='''# Step 5B — observed reference preservation and source-bound replay

## Record boundary

This directory preserves the actual owner-dispatched reference from work order
#2875 and the subsequent local verification of that exact artifact. It does not
change the Step 5B implementation, active policy, the original strict checker,
historical #6066 evidence, or any existing workflow.

Acquisition and verification are separate evidence events. The source is the
actual #2876 merge, not a preparation commit or a temporary PR test merge.
This preservation handoff does not predeclare its own future CI/review result,
issue closure or canonical-documentation acceptance.

## Acquired identities

| Field | Value |
| --- | --- |
| Repository | `HKati/pulse-release-gates-0.1` |
| Workflow | `PULSEmech bounded execution reference` |
| Event / branch | `workflow_dispatch` / `main` |
| Run / number / attempt | `34402387728` / `1` / `1` |
| Job | `102637163024` |
| Artifact | `10123984621` |
| Source commit | `c32508f8afb58381225fec0b426b85b00e32fe11` |
| Source tree | `74dd65d82124170b7d8f459925962bb8bc09fe2b` |

GitHub's independently retrieved attempt, job and artifact metadata agree on the
source and run. Both acquisition/reconstruction and artifact upload steps report
success. Selected connector fields and decoded log excerpts are in the evidence
archive. They are explicitly not presented as preserved raw HTTP response bytes
or a complete raw job log. Their trust root is the connected GitHub API/log view,
not a new signed execution attestation.

| Exact byte object | Bytes | SHA-256 |
| --- | ---: | --- |
'''
for label,key in [('Downloaded GitHub artifact','artifact'),('Inner reference capsule','capsule'),('Prepared input carrier','prepared'),('Captured evidence carrier','capture'),('Acquired reconstruction carrier','reconstruction')]:
 x=positive[key];readme+=f"| {label} | {x['size_bytes']} | `{x['sha256']}` |\n"
readme+='''
Prelaunch SHA-256:

```text
0c3e602d54036e5825bf3a9aaf98fdeb98d1ac907c4427512a31dc02fa77ba80
```

The artifact ZIP is copied without byte changes. Its inner capsule is not
repacked. The six capsule members and five payload checksums were checked.
`prepared.zip` has 39 members; `capture.zip` has 55; the reconstruction has 12.
The capture's prepared inputs exactly equal the separately preserved preparation.

## Fresh local verification

The local environment was CPython 3.13.5, jsonschema 4.26.0 and PyYAML 6.0.3.
The acquisition log reports CPython 3.11.16. The compared output identity is a
result for these exact inputs and executions, not a universal cross-version claim.

All 28 source-inventory files matched the authenticated commit's Git blobs, the
clean installed source tree, the prepared carrier and the captured carrier.
Expected acquisition context was formed from separately retrieved GitHub fields,
not trusted merely because the capsule supplied an `expected_context.json`.

The preparation recipe was rerun from those exact sources and external context,
reusing only its preserved declared creation timestamp. It reproduced the entire
1,456,425-byte prepared carrier. Its reconstructed prelaunch digest was supplied
outside the capture to subsequent validation. This is not an independent
pre-acquisition timestamp attestation; ordering remains within the declared
supervisor/control-plane trust boundary.

Two complete independent-validator CLI invocations returned exit 0. Two further
separate reconstruction processes returned exit 0 and reproduced the entire
322,567-byte reconstruction ZIP exactly, including all 12 members. The reconstructed
report diagnostic contains 10/10 true checks; the relation diagnostic contains
34/34 true checks. These are diagnostic checks, not counts of pytest tests.

A first local reconstruction attempt was interrupted by the tool's 120-second
wall-clock limit before a completed exit record. It is retained as interrupted,
not PASS. The two later completed invocations have separate command, timing,
stdout, stderr and output identities. No fresh subject capture was performed.

## Observed cases and predicate separation

| Case | Actual checker exit | Consumer terminal state | Expected result matched |
| --- | ---: | --- | --- |
| `allow` | 0 | ready | true |
| `block_false` | 1 | held | true |
| `missing_required` | 2 | held | true |

Exactly six checker/consumer occurrences are bound. The resulting relation has
six expectations, six observations and six decisive planned/observed relations.
There are zero unresolved relations within this declared boundary.

```text
scope: six_declared_direct_processes_and_their_bound_io
I — bounded packet integrity: complete
E — bounded observation extent: complete
R — bounded relational coverage: complete
C — comparison_complete: true
M — resource coverage: unavailable
```

Whole-runtime-packet coverage remains `partial`; its seventh execution record is
the explicitly partial projection collector, not a seventh observed subject.
There are no resource-measurement records. The generic runtime-report summary
retains `authority_binding_complete: false` and `decision_closure_complete: false`.
This is separate from the bounded comparison's qualified relationships.

```text
compute_transition_path_complete: true
compute_transition_authority_binding_ok: true
compute_transition_unbound_mutation_absent: true
```

These three values belong only to the non-active compute candidate. They neither
change the two observed blocking checker results nor grant production authority.
The artifact-only baseline remains distinct and is hash-bound into the runtime
report. This local comparison does not claim a new complete #6066 historical replay
or completion of every wider fixed-source/runtime comparison in Step 5.

## Fresh negative checks on the acquired evidence

All ten local scenarios met their rejection/preservation assertions. Each actual
CLI returned exit 2 where rejection was expected. These are local review probes,
not newly registered permanent tests. Mutants are stored separately; the original
artifact and source checkout remain unchanged.

| Scenario | Observed rejection |
| --- | --- |
'''
for x in negative['cases']:readme+=f"| `{x['scenario']}` | `{x['error']}` |\n"
readme+='''
The connected wrong-consumer reconstruction produced no output. A complete valid
reconstruction directed at a pre-existing unrelated file rejected publication and
left that file byte-identical. Manifest and ZIP repairs in the mutation probes
avoid confusing intended semantic rejection with accidental CRC corruption.

## Source-object availability and offline transport

Direct Git network access from the local container failed DNS resolution. The
connected GitHub Git-data API did supply the source commit's signed payload,
signature and tree. The exact 3,728-byte commit object was transported from those
fields and its Git object hash matched `c32508f8...`. GitHub reported its PGP
signature valid; this review did not perform separate local PGP verification.

The full file tree was recovered through the earlier content bundle and the two
inventory replacements, then checked against the independently retrieved upstream
root tree. No local preparation commit was relabelled as the GitHub commit.

For portability, the evidence archive contains a source-object pack with the
actual source commit and its complete tree/blob closure: 1,569 objects and 1,396
tracked files. A fresh repository imported it, checked out the genuine commit and
matched all 1,569 object bodies and the complete tree. It deliberately contains no
ancestor history and no synthetic preparation commits. It is a complete source
snapshot, not a full-history clone and not enough for an unrelated historical
#6066 campaign. Instructions are in `REPLAY.md` inside the evidence archive.

## Files and preservation scope

```text
pulsemech-bounded-reference-34402387728-1.zip
verification_record_v0.json
verification_evidence_v0.zip
preservation_manifest_v0.json
README.md
```

The preservation manifest hashes the other four files and excludes itself.
Neither that manifest nor the evidence archive's manifest is an authority verdict.
The top-level repository README is not modified by this directory's README.
No source, schema, test, workflow, policy or registry file changes are included.

After repository preservation and its review, the canonical workstream surfaces
still need their separate state update and a bounded work-order completion record.
Do not treat this handoff alone as already-merged preservation or full Step 5 closure.

```text
authority_effect: none
same_run_release_authority_eligible: false
active_gate_eligible: false
```

No resource measurement, compute budgeting, deployment admission or Step 7 gate
promotion is introduced. The trusted acquisition boundary remains the reviewed
supervisor, interpreter/runtime, kernel and GitHub control-plane metadata.

```text
A tényleges referenciafutás pontos csomagját külön, Git-forráshoz kötötten
ellenőriztük. A két befejezett rekonstrukció mind a tizenkét kimeneti fájlban
és a teljes ZIP bájtjaiban megegyezik a GitHubon előállított eredménnyel.
A tíz ellenpróba a megfelelő elutasítást vagy kimenetmegőrzést adta.
Ez a hat megfigyelt folyamat körülhatárolt bizonyítása; nem erőforrásmérés,
nem aktív compute-gate és nem produkciós release-engedély.
```

Refs #2875. Implementation: #2876.
'''
(Path('/mnt/data/PULSEmech_Step5B_reference_verification_report_v0.md')).write_text(readme)
replay='''# Replaying the preserved source-bound reference

Use a disposable Linux working directory and a Python environment with jsonschema
4.26.0 and PyYAML 6.0.3. The preserved local results used CPython 3.13.5; the original
GitHub acquisition used 3.11.16. Do not dispatch `run-reference` or execute capture.

First compare the sibling original GitHub artifact against its externally checked
SHA-256: `2601a68b864779b8cf99a6a2bc0fdb48c994b95067f098354d35e86e7ff178f6`.
Verify this archive's `EVIDENCE_SHA256SUMS.json` before using its inputs. Its manifest
is a transport integrity aid, not a new provenance trust root.

Set EVIDENCE to the extracted evidence archive directory and WORK to a new,
non-existing disposable directory. The commands below only create local files.

```sh
set -eu
EVIDENCE=/absolute/path/to/extracted-evidence
WORK=/absolute/path/to/new-disposable-review
[ ! -e "$WORK" ]
mkdir "$WORK"
git init -q "$WORK/repository"
git -C "$WORK/repository" index-pack --stdin < "$EVIDENCE/source/reviewed_source_snapshot.pack"
git -C "$WORK/repository" checkout -q --detach c32508f8afb58381225fec0b426b85b00e32fe11
[ "$(git -C "$WORK/repository" rev-parse HEAD^{tree})" = 74dd65d82124170b7d8f459925962bb8bc09fe2b ]
mkdir "$WORK/outputs"
python -I -B "$WORK/repository/tools/check_pulsemech_compute_bounded_execution_v0.py" \
  --repository-root "$WORK/repository" \
  --expected-context "$EVIDENCE/inputs/expected_context_external.json" \
  --expected-prelaunch-sha256 0c3e602d54036e5825bf3a9aaf98fdeb98d1ac907c4427512a31dc02fa77ba80 \
  --carrier "$EVIDENCE/inputs/capture.zip"
for n in 1 2; do
  python -I -B "$WORK/repository/tools/build_pulsemech_compute_bounded_execution_inputs_v0.py" reconstruct \
    --repository-root "$WORK/repository" \
    --expected-context "$EVIDENCE/inputs/expected_context_external.json" \
    --expected-prelaunch-sha256 0c3e602d54036e5825bf3a9aaf98fdeb98d1ac907c4427512a31dc02fa77ba80 \
    --carrier "$EVIDENCE/inputs/capture.zip" \
    --analysis-run-key analysis:bounded:8097b20f4ae41686d81f113f1a06cb5eb8289b4e6ccc19a4a1e38fc09c82ab8c \
    --output "$WORK/outputs/reconstruction_$n.zip"
  cmp "$WORK/outputs/reconstruction_$n.zip" "$EVIDENCE/inputs/reconstruction.zip"
done
cmp "$WORK/outputs/reconstruction_1.zip" "$WORK/outputs/reconstruction_2.zip"
```

The source snapshot intentionally omits the parent commit and earlier history.
A whole-history fsck/campaign may report missing ancestry; do not manufacture it
or substitute preparation commits. The bounded reference needs the exact source
commit/tree/blobs, all of which are present. Full historical regression is a
separate task requiring the genuine earlier history.

The external context and prelaunch digest here are the recorded review anchors.
Their origin is documented in `logs/github_metadata_selected.json` and the main
README. Re-establish GitHub provenance separately when making a new acceptance
assessment; successful internal replay alone is not authenticated acquisition.

`executed_local_drivers/` preserves the actual local review scripts, including
their original absolute paths. Use the portable commands above for a new replay,
not those historical path-specific scripts without adaptation.
'''
# Five new repository files only. Evidence content does not include live PID files.
rel=Path('preservation/compute_bounded_execution_reference_v0/run_34402387728_attempt_1')
assert not (R/rel).exists()
stage=Path('/mnt/data/PULSEmech_Step5B_preservation_upload');dest=stage/rel;dest.mkdir(parents=True,exist_ok=False)
shutil.copyfile(A,dest/A.name)
payload={'REPLAY.md':replay.encode()}
for p in E.iterdir():
 if p.is_file() and p.suffix!='.pid':
  if p.name=='reviewed_source_snapshot.pack':payload['source/'+p.name]=p.read_bytes()
  else:payload['logs/'+p.name]=p.read_bytes()
for folder,label in [('inputs','inputs'),('outputs','outputs'),('mutations','mutations'),('tools','executed_local_drivers')]:
 for p in (B/folder).iterdir():
  if p.is_file():payload[label+'/'+p.name]=p.read_bytes()
evidence_manifest={'format':'review_evidence_transport_inventory_v0','self_excluded':'EVIDENCE_SHA256SUMS.json',
 'files':[{'path':n,'size_bytes':len(b),'sha256':sha(b)} for n,b in sorted(payload.items())]}
payload['EVIDENCE_SHA256SUMS.json']=cj(evidence_manifest)
def packed(path,contents):
 with zipfile.ZipFile(path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
  for n,b in sorted(contents.items()):
   info=zipfile.ZipInfo(n,(1980,1,1,0,0,0));info.create_system=3;info.external_attr=0o100644<<16;info.compress_type=zipfile.ZIP_DEFLATED
   z.writestr(info,b)
packed(dest/'verification_evidence_v0.zip',payload)
commands=[json.loads(p.read_bytes()) for p in sorted(E.glob('*.command.json'))]
limits=['Trusted supervisor, interpreter/runtime, kernel and GitHub API/log context; not protection against a compromised trusted producer.',
 'No independently signed execution attestation or local PGP signature verification.',
 'Preserved declared preparation timestamp reused; no separate pre-acquisition timestamp attestation.',
 'One interrupted local reconstruction is not PASS; two later completed commands are reported separately.',
 'Local CPython 3.13.5 verification is not a new Python 3.11 CI campaign.',
 'Source snapshot omits ancestry; no complete #6066 historical regression or full 154-program CI campaign was run here.',
 'Repository upload/review, canonical state update and bounded issue closure remain separate owner handoffs.']
record={'record_type':'step5b_observed_reference_verification_record_v0','recorded_at':datetime.now(timezone.utc).isoformat(),
 'positive_verification':positive,'negative_verification':negative,'derived_interpretation':interp,
 'source_transport':transport,'command_records':commands,'evidence_archive':{'path':'verification_evidence_v0.zip','size_bytes':(dest/'verification_evidence_v0.zip').stat().st_size,'sha256':sha((dest/'verification_evidence_v0.zip').read_bytes())},
 'limitations':limits,'repository_preservation_status':'prepared_not_uploaded','canonical_state_update_status':'pending',
 'bounded_acceptance_status':'verification_passed_owner_preservation_review_pending',
 'authority_effect':'none','same_run_release_authority_eligible':False,'active_gate_eligible':False}
(dest/'verification_record_v0.json').write_bytes(cj(record));(dest/'README.md').write_text(readme)
manifest={'manifest_type':'step5b_reference_preservation_inventory_v0','source_commit':positive['source_commit'],
 'run_id':positive['run_id'],'run_attempt':positive['attempt'],'artifact_id':positive['artifact_id'],
 'authority_effect':'none','self_excluded':'preservation_manifest_v0.json',
 'files':[{'path':p.name,'size_bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(dest.iterdir()) if p.is_file()]}
(dest/'preservation_manifest_v0.json').write_bytes(cj(manifest))
upload={p.relative_to(stage).as_posix():p.read_bytes() for p in dest.iterdir() if p.is_file()};assert len(upload)==5
upload_path=Path('/mnt/data/PULSEmech_Step5B_reference_preservation_5_files.zip');packed(upload_path,upload)
# Byte checks after final packaging.
assert sha((dest/A.name).read_bytes())==positive['artifact']['sha256']==sha(A.read_bytes())
with zipfile.ZipFile(dest/'verification_evidence_v0.zip') as z:
 for item in evidence_manifest['files']:
  b=z.read(item['path']);assert len(b)==item['size_bytes'] and sha(b)==item['sha256']
for item in manifest['files']:
 b=(dest/item['path']).read_bytes();assert len(b)==item['size_bytes'] and sha(b)==item['sha256']
with zipfile.ZipFile(upload_path) as z:
 assert sorted(z.namelist())==sorted(upload)
 for n,b in upload.items():assert z.read(n)==b
shutil.copyfile(dest/'verification_record_v0.json','/mnt/data/PULSEmech_Step5B_reference_verification_record_v0.json')
shutil.copyfile(dest/'verification_evidence_v0.zip','/mnt/data/PULSEmech_Step5B_reference_verification_evidence_v0.zip')
summary={'upload_zip':str(upload_path),'upload_zip_size':upload_path.stat().st_size,'upload_zip_sha256':sha(upload_path.read_bytes()),
 'paths':sorted(upload),'new_files':5,'modified_existing_files':0,'deletions':0,'evidence_archive_bytes':(dest/'verification_evidence_v0.zip').stat().st_size,
 'positive_status':positive['status'],'negative_count':negative['scenario_count'],'evidence_member_count':len(payload),'source_snapshot_objects':transport['object_count']}
(E/'delivery_summary.json').write_bytes(cj(summary));print(json.dumps(summary,indent=2))
