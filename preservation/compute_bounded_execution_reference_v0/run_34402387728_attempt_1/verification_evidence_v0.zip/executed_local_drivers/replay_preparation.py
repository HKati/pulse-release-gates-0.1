import sys
from pathlib import Path
sys.path.insert(0,sys.argv[1]+"/tools")
import build_pulsemech_compute_bounded_execution_inputs_v0 as a
v=a.verify
c=v.parse(Path(sys.argv[2]).read_bytes())
r=a.prepare(repository_root=Path(sys.argv[1]),context=c,created_at_utc=sys.argv[3])
v.publish_new(Path(sys.argv[4]),r,repository_root=Path(sys.argv[1]))
print(v.sha(r))
