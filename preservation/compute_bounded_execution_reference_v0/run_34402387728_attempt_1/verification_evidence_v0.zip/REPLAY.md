# Replaying the preserved source-bound reference

Use a disposable Linux working directory and a Python environment with jsonschema
4.26.0 and PyYAML 6.0.3. The preserved local results used CPython 3.13.5; the original
GitHub acquisition used 3.11.16. Do not dispatch `run-reference` or execute capture.

First compare the sibling original GitHub artifact against its externally checked
SHA-256: `2601a68b864779b8cf99a6a2bc0fdb48c994b95067f098354d35e86e7ff178f6`.
Verify this archive's `EVIDENCE_SHA256SUMS.json` before using its inputs. Its manifest
is a transport integrity aid, not a new provenance trust root.

Set EVIDENCE to the extracted evidence archive directory and WORK to a new,
non-existing disposable directory. The commands below only create local files.

```sh
set -eu
EVIDENCE=/absolute/path/to/extracted-evidence
WORK=/absolute/path/to/new-disposable-review
[ ! -e "$WORK" ]
mkdir "$WORK"
git init -q "$WORK/repository"
git -C "$WORK/repository" index-pack --stdin < "$EVIDENCE/source/reviewed_source_snapshot.pack"
git -C "$WORK/repository" checkout -q --detach c32508f8afb58381225fec0b426b85b00e32fe11
[ "$(git -C "$WORK/repository" rev-parse HEAD^{tree})" = 74dd65d82124170b7d8f459925962bb8bc09fe2b ]
mkdir "$WORK/outputs"
python -I -B "$WORK/repository/tools/check_pulsemech_compute_bounded_execution_v0.py"   --repository-root "$WORK/repository"   --expected-context "$EVIDENCE/inputs/expected_context_external.json"   --expected-prelaunch-sha256 0c3e602d54036e5825bf3a9aaf98fdeb98d1ac907c4427512a31dc02fa77ba80   --carrier "$EVIDENCE/inputs/capture.zip"
for n in 1 2; do
  python -I -B "$WORK/repository/tools/build_pulsemech_compute_bounded_execution_inputs_v0.py" reconstruct     --repository-root "$WORK/repository"     --expected-context "$EVIDENCE/inputs/expected_context_external.json"     --expected-prelaunch-sha256 0c3e602d54036e5825bf3a9aaf98fdeb98d1ac907c4427512a31dc02fa77ba80     --carrier "$EVIDENCE/inputs/capture.zip"     --analysis-run-key analysis:bounded:8097b20f4ae41686d81f113f1a06cb5eb8289b4e6ccc19a4a1e38fc09c82ab8c     --output "$WORK/outputs/reconstruction_$n.zip"
  cmp "$WORK/outputs/reconstruction_$n.zip" "$EVIDENCE/inputs/reconstruction.zip"
done
cmp "$WORK/outputs/reconstruction_1.zip" "$WORK/outputs/reconstruction_2.zip"
```

The source snapshot intentionally omits the parent commit and earlier history.
A whole-history fsck/campaign may report missing ancestry; do not manufacture it
or substitute preparation commits. The bounded reference needs the exact source
commit/tree/blobs, all of which are present. Full historical regression is a
separate task requiring the genuine earlier history.

The external context and prelaunch digest here are the recorded review anchors.
Their origin is documented in `logs/github_metadata_selected.json` and the main
README. Re-establish GitHub provenance separately when making a new acceptance
assessment; successful internal replay alone is not authenticated acquisition.

`executed_local_drivers/` preserves the actual local review scripts, including
their original absolute paths. Use the portable commands above for a new replay,
not those historical path-specific scripts without adaptation.
