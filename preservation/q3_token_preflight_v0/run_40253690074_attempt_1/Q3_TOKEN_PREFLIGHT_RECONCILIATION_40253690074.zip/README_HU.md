# Q3 — ellenőrzési és megőrzési munkacsomag

Dátum: 2026. október 29.

## Eredmény

A történeti token-preflight belső ellenőrzése ismét sikeres. Az eredeti ZIP
változatlan, 204 feladatot és 0 generálási hívást rögzít. A 21 fájlos forráskészletből
20 azonos a most ellenőrzött main állapotával; csak a workflow artifact-feltöltő
pinje változott.

A runner-image eltérésének oka nem bizonyított:

- GitHub acquire-job induló naplója: `20261012.334.1`.
- Eredeti `platform.json`: `20261023.334.3`.

**A jelenlegi bizonyíték alapján a token-mapot nem hagyjuk jóvá capture-átadásra.**
A szakmai disposition: `REJECT_AND_REQUIRE_NEW_TOKEN_PREFLIGHT`. Ez a következő
átadásra vonatkozó konzervatív értékelés, nem az eredeti `complete` rekord átírása,
nem új repópolicy és nem futtatási engedély. Új kortárs bizonyíték külön új
értékeléssel feloldhatja a történeti eltérést; egy új sikeres futás önmagában nem.

## Mi készült el most?

Az eredeti bájtok, a korábbi postflight-csomag és napló megőrzése; a teljes 21
kijelölt forrásfájl összevetése; a változatlan történeti checker offline futtatása;
egy hordozható, külön platformegyeztető ellenőrző; 28 sikeres helyi regressziós
teszt; valamint a következő implementáció pontos munkautasítása.

A külső GitHub-metaadatok friss lekérése megtörtént. A csomagban ezek kiválasztott
mezőinek kifejezetten megjelölt átirata szerepel, nem eredeti HTTP-válasznak vagy
hitelesített attestationnek álcázott rekord. Az új logválasz teljes bájtjait nem
exportáltuk; a korábban megőrzött eredeti napló változatlanul megtalálható.

## A következő konkrét lépés

A külső postflight-egyeztető bekötésének és a capture előtti átadási kötésnek az
elkészítése következik, **először csak külön javított fájlokként**. A teljes,
átadható feladat a `NEXT_TASK_EN.txt` fájlban van. Ez megköveteli a tényleges
kód és a két tesztmanifest ellenőrzését, az eredeti formátum megőrzését, valamint
az elfogadási rekord és a konkrét preflight/token-map ellenőrizhető összekötését.

A mostani ellenőrző még nincs a repó folyamatába bekötve. Ezért a csomag nem
állít új natív kikényszerítést, lezárt repo-bound megőrzést vagy capture-készséget.
Új zero-generation preflight csak a következő javítás felülvizsgálata után,
külön tulajdonosi engedéllyel indulhat. Capture, Q1-címkézés és Q3-mérés nem indult.

## Fontos fájlok

`original/q3-reference-capture-40253690074-1.zip`: az eredeti GitHub-artifact.

`prior_review/Q3_TOKEN_PREFLIGHT_POSTFLIGHT_40253690074.zip`: az előző,
változatlan ellenőrzési csomag, benne a történeti forrásokkal és naplóval.

`REVIEW.md`: részletes angol vizsgálati jelentés és bizonyítéki határok.

`source/source_delta.json` és `source/source_delta.diff`: 21 fájlos összevetés
és az egyetlen tényleges workflow-soreltérés. A `source/` könyvtár vizsgálati
bemenet, nem feltöltendő repójavítás.

`verify_package.py`, `tests/test_review.py`, `checks/`: helyi, offline ellenőrző,
28 regresszió és rögzített eredmények. Ezek nem a repository CI eredményei.

`NEXT_TASK_EN.txt`: a következő, fájlokban szállítandó javítás munkautasítása.

## Offline ellenőrzés

A ZIP-et külön könyvtárba kell kicsomagolni. A csomag nem telepít csomagot, nem
hív hálózatot, modellt vagy tokenizert, és nem igényel repository-hozzáférést.
A két hash-ellenőrzött történeti checker-modult ideiglenes könyvtárban tölti be,
amelyet a futás végén eltávolít. Más archívumbeli kódot nem futtat.

```text
python -B verify_package.py
python -B -m unittest discover -s tests -v
```

A történeti csomagnál a verifier **elvárt kilépési kódja 2**, mert a belső
ellenőrzés sikeres, de a külső image-egyeztetés nem. Ez nem a regressziós tesztek
hibája. A tesztparancs elvárt kódja 0. A verifier 1-es kódja integritási vagy
bemeneti hibát jelent; a 0 csak sikeres kivonatellenőrzést és image-egyezést
jelentene, önmagában akkor sem capture-engedélyt.

A helyi ellenőrzés CPython 3.13.5 alatt futott; nem a GitHubon rögzített
CPython 3.11.16 környezet újrajátszása. Windows alatt a `python` parancs helyett
a telepített Python-indító használható; Windows-futtatást ebben a vizsgálatban
nem teszteltünk. Nem szükséges neked futtatni a további munka folytatásához.

## Munkahatár

Repository-írás, commit, PR, külső komment, workflow-dispatch, új preflight,
modellhívás, tokenizálás vagy metrikaszámítás nem történt. Dependabot-módosítás
nem történt. #2879 lezárása nincs ebben a feladatban. `authority_effect = none`.

A csomagot most **ne töltsd fel egyben a repóba**: megőrzési és ellenőrzési
munkacsomag, nem jóváhagyott repository-patch.
