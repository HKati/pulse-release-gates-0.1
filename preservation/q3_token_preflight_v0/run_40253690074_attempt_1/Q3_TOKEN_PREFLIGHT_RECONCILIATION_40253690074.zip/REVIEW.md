# Q3 token-preflight reconciliation and preservation review

Review date: 2026-10-29. Repository: `HKati/pulse-release-gates-0.1`.
Run `40253690074`, attempt `1`, acquire job `121350855532`.

## Disposition and exact scope

**The selected historical token-map is not approved for capture handoff.**
The review disposition is `REJECT_AND_REQUIRE_NEW_TOKEN_PREFLIGHT` on the evidence
currently available. The runner-image discrepancy remains `UNRESOLVED_MISMATCH`;
no cause is asserted. This is a conservative review recommendation for the next
handoff, not a mutation of the repository policy and not release authority.

The original receipt and result remain `complete`. The historical source-bound
carrier checker passes. Neither original is rewritten, repaired, normalized or
relabeled as an unsuccessful execution. Internal carrier validity, external
platform consistency, authorization for a new experiment, and release authority
remain separate.

A new run is **not authorized or started** by this package. Before a fresh
zero-generation preflight, prepare the external postflight comparison and its
capture-handoff binding. A later review may supersede this disposition if new,
independently preserved, contemporaneous evidence resolves the old discrepancy.
A successful future run by itself cannot repair the historical record.

## Original archive and custody

`original/q3-reference-capture-40253690074-1.zip` is the unchanged original:

- Size: `5897022` bytes.
- SHA-256: `7228d89f93ea69a7129c7d1bc915f5a8b3b800f0ef862280605178c602e6f317`.
- GitHub artifact ID: `12621038763`.
- Members: `evidence.zip`, `receipt.json`.
- Inner evidence size: `5895980` bytes.
- Inner evidence SHA-256: `b792a17d63142f0378af19a8ed7c65176356b91d7c9de3e0c9943f72db46a60a`.

The original bytes were reread and hashed in this review. The current GitHub
artifact metadata reports the same artifact identity, size and digest. The
artifact was not downloaded again in this review. Its recorded expiry remains
`2026-11-25T01:21:00Z`; durable custody here depends on the owner retaining this
package or another verified copy, not on GitHub's temporary retention.

`prior_review/Q3_TOKEN_PREFLIGHT_POSTFLIGHT_40253690074.zip` is also unchanged:
size `1609924`, SHA-256
`1455bb7dfdc45f96be7eadeddd609292b53d4451d0031631b91965a9e3aa1f5f`.
It preserves the prior report, exact historical source snapshot, external job log,
metadata, token map and original inner evidence. It is not the original Actions
archive. Its old verification script contains historical absolute workspace paths;
it is preserved as history, not advertised as a portable command. The new
`verify_package.py` supplies the portable, locally tested offline verification.

This package is an owner-held preservation candidate. It has not been committed
or published and does not establish completed repository-bound preservation.

## Source-closure comparison

Historical source: `a9de035d1b3ac227359ca78a98274abe4c9ee186`.
Reviewed main: `72e8973e54d8f94422c0dabb264b8316ac8e4de6`.

All 21 paths declared by the preserved Q3 profile were checked. Twenty retain the
same Git blob identities. This includes the five Q3 Python sources, four stimulus
files, selected runtime/model input records and lockfiles, Q3 profile, both
schemas, and two bound reference documents.

The sole difference is one line in
`.github/workflows/q3_reference_acquisition_v0.yml`:

```diff
-        uses: actions/upload-artifact@043fb46d1a93c77aae656e7c1c64a875d1fc6a0a
+        uses: actions/upload-artifact@cf430e030ddbb5b0abf93d22962f4752f3646cd9
```

The old workflow blob is `6dce1ce2a877ecd5a386d8792017e446c54b2743`;
the reviewed current blob is `a5adfa8f9c883760acc694f32951ae6a4c788d76`.
Both have 4203 bytes. The current file reconstructed by this exact replacement
matches the newly fetched current Git blob identity.

Method: retained historical source bytes were checked against their stored blob
IDs. Fresh commit-pinned GitHub metadata was read for every selected path. For
unchanged paths, current blob equality permits reuse of the held historical
bytes; those 20 file bodies were not independently downloaded again. The selected
metadata in `source/source_delta.json` is a transcription of connector results,
not an untouched API-response archive, signature, or offline Git tree proof.
The complete per-file comparison and the exact diff are included.

This is a comparison of the declared 21-file closure, not a claim that the whole
repository or all transitive external action code is unchanged. No execution of
the newly selected upload action was performed. Its presence after the native
phase does not explain an image mismatch already bound into the historical
prelaunch record. The old request cannot be rebound by merely changing its
source commit or keeping its old digest.

## Runner-image investigation

Two preserved records identify different image versions:

| Record | Value |
| --- | --- |
| Acquire job startup, `Runner Image` group | `20261012.334.1` |
| Original `evidence.zip/platform.json`, `runner_image` | `20261023.334.3` |

The fresh attempt-specific jobs response contains one job: acquire
`121350855532`, for run `40253690074`, attempt 1, at the historical source commit.
The job log was freshly read through the connector and again showed the older
startup image. The new response was not exported as raw bytes; this package
preserves the prior raw log unchanged. Fresh byte-for-byte log equality is not
claimed.

The retained log also identifies the historical source, acquire job name,
published artifact name, artifact ID, uploaded byte count and SHA-256. All match
the original archive and selected external identifiers. These checks rule out
using a different recorded job or artifact as the comparison input on the
available evidence; they are not organizationally independent attestation.

The static source trace is:

1. Historical workflow line 74 passes `ImageVersion` through `sudo --preserve-env`.
2. `q3_native_runtime_v0.py`, lines 363–376, reads
   `os.environ.get('ImageVersion', '')` and stores it as `runner_image`.
3. `acquire_q3_reference_inputs_v0.py`, line 411, records that platform object
   before downloading and installing the selected Q3 runtime.
4. The original checker validates the field and its hash bindings, but does not
   compare it with the external GitHub startup job log.

`evidence/source_trace.json` contains extracted line locations from the exact
historical source. There is no direct, preserved, before-and-after supervisor
boundary observation of `ImageVersion` that explains the difference. The presence
of a value in platform.json and the source code that reads that variable is not
an independent measurement of the historical parent environment. The prior
external checkout/setup-python execution and hosted provisioning are not fully
reconstructed here. No GitHub fault, repository overwrite, tampering or tokenizer
fault is diagnosed.

The new offline checker selects the exact `Runner Image` group; it does not
confuse the separate `Runner Image Provisioner` version with the OS image. Missing,
duplicate or ambiguous image groups and mismatched job/source/artifact bindings
fail closed. Even matching image strings alone never authorize capture.

## Verification performed now

The unchanged historical checker and contract were loaded from digest-checked
held bytes in an isolated temporary directory. `check_carrier` ran on the original
inner archive with external expected archive, request and source-commit anchors.
It returned `complete=true`, mode `token-preflight`, with all non-authorizing
claims retained.

Recorded input facts were rechecked from the retained data: 204 unique tasks,
471–925 prompt tokens, 144752 total prompt tokens, zero attempted generation
calls, and 204 `not_requested` occurrence states. The original native independent
tokenization record is preserved and checked by the carrier checker; this review
did not execute the tokenizer or a model. Installation and cleanup records are
checked as retained records, not reobserved on the now-discarded hosted runner.

`checks/verification.json` is the new reconstructed review result.
`checks/carrier_replay.json` is the historical-checker replay result.
The standalone review's 28 local regressions passed, including malformed/missing
log identities, duplicate JSON/ZIP members, traversal/symlinks, source mutation,
false equality, package-manifest mutations and no authorization from an image
match. These are local audit-tool regressions, not the full repository suite or
a fresh GitHub Actions run.

## Remaining boundary and next work

Prepare a generic external postflight verifier and its explicit pre-capture
handoff binding using `NEXT_TASK_EN.txt`. Do not weaken the historical source or
image check to obtain acceptance. Do not treat the upload-action pin change as a
reason to discard internally valid historical records.

After that preparation is reviewed and any intended repository changes are
merged by the owner, construct a fresh zero-generation preflight request for the
then-reviewed exact commit. Dispatch requires separate explicit owner consent.
Only a complete, externally reconciled preflight can proceed to a separate
capture decision. The 204-response capture, Q1 labeling and Q3 scoring have not
been performed by this work. Keep #2879 open.

`authority_effect=none`; no production-gate eligibility, current-run release
evidence, policy activation, metric evaluation or repository mutation.

## Source locators

Historical source and retained evidence are included in the unchanged prior
review archive. Fresh GitHub reads were made at:

- https://api.github.com/repos/HKati/pulse-release-gates-0.1/branches/main
- https://api.github.com/repos/HKati/pulse-release-gates-0.1/actions/runs/40253690074/attempts/1/jobs?per_page=100
- https://api.github.com/repos/HKati/pulse-release-gates-0.1/actions/runs/40253690074/artifacts
- https://api.github.com/repos/HKati/pulse-release-gates-0.1/actions/jobs/121350855532/logs

Per-path commit-pinned GitHub locators and connector observation references are
recorded in `source/source_delta.json`. `evidence/fresh_github_observations.json`
explicitly distinguishes transcribed fresh observations from unchanged historical
raw artifacts. The source comparison API was also read, but its oversized response
was not used as a substitute for the individual 21-path metadata checks.
