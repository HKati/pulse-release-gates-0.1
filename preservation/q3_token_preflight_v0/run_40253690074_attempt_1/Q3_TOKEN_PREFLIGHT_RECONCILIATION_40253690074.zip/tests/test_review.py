"""Local review regressions only; not repository CI or a hosted Q3 execution."""
import copy
import importlib.util
import io
from pathlib import Path
import stat
import tempfile
import unittest
import warnings
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('review', ROOT / 'verify_package.py')
M = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(M)
LOG = (ROOT / 'evidence/workflow_job_121350855532.log').read_bytes()
PRIOR = M.zip_members((ROOT / 'prior_review/Q3_TOKEN_PREFLIGHT_POSTFLIGHT_40253690074.zip').read_bytes())
SNAPSHOT = M.strict_json(PRIOR['reviewed_source_snapshot.json'])
DELTA = M.strict_json((ROOT / 'source/source_delta.json').read_bytes())
CURRENT_WORKFLOW = (ROOT / 'source/current_q3_reference_acquisition_v0.yml').read_bytes()

class ReviewTests(unittest.TestCase):
    def log_reject(self, old, new, code):
        self.assertIn(old, LOG)
        with self.assertRaisesRegex(M.ReviewError, code):
            M.inspect_log(LOG.replace(old, new))

    def test_preserved_package_replay_is_blocked_not_promoted(self):
        result = M.verify(ROOT, check_manifest=False)
        self.assertEqual(result['source_bound_carrier_check'], 'PASS')
        self.assertEqual(result['source_paths_compared'], 21)
        self.assertEqual(result['prompt_tokens']['total'], 144752)
        self.assertEqual(result['runner_image_review']['review_disposition'],
                         'REJECT_AND_REQUIRE_NEW_TOKEN_PREFLIGHT')
        self.assertFalse(result['runner_image_review']['capture_handoff_approved'])
        self.assertFalse(result['this_review_tokenizer_executed'])

    def test_matching_images_do_not_authorize_capture(self):
        row = M.compare_images('20261023.334.3', '20261023.334.3')
        self.assertTrue(row['match'])
        self.assertFalse(row['capture_handoff_approved'])
        self.assertFalse(row['new_execution_authorized'])
        self.assertEqual(row['authority_effect'], 'none')

    def test_missing_image_fails_closed(self):
        for value in ('', None, 0, True, 'bad image'):
            with self.subTest(value=value), self.assertRaises(M.ReviewError):
                M.compare_images(value, '20261023.334.3')

    def test_original_log_startup_image_is_selected(self):
        self.assertEqual(M.inspect_log(LOG), '20261012.334.1')

    def test_runner_provisioner_version_is_not_image_version(self):
        changed = LOG.replace(b'Version: 20261021.618', b'Version: unrelated-provisioner')
        self.assertEqual(M.inspect_log(changed), '20261012.334.1')

    def test_missing_image_group_rejected(self):
        self.log_reject(b'##[group]Runner Image\n', b'##[group]Not Runner Image\n', 'LOG_IMAGE_GROUP')

    def test_duplicate_image_group_rejected(self):
        with self.assertRaisesRegex(M.ReviewError, 'LOG_IMAGE_GROUP'):
            M.inspect_log(LOG + b'\n##[group]Runner Image\nVersion: wrong\n##[endgroup]')

    def test_ambiguous_image_version_rejected(self):
        self.log_reject(b'Version: 20261012.334.1', b'Version: 20261012.334.1 Version: other', 'LOG_IMAGE_VERSION')

    def test_wrong_image_os_rejected(self):
        self.log_reject(b'Image: ubuntu-24.04', b'Image: windows-2025', 'LOG_IMAGE_OS')

    def test_wrong_job_rejected(self):
        self.log_reject(b'Complete job name: acquire', b'Complete job name: verify', 'LOG_JOB')

    def test_wrong_source_commit_rejected(self):
        self.log_reject(('EXPECTED_SOURCE_SHA: ' + M.OLD).encode(),
                        ('EXPECTED_SOURCE_SHA: ' + '0'*40).encode(), 'LOG_SOURCE')

    def test_wrong_upload_digest_rejected(self):
        self.log_reject(('SHA256 digest of uploaded artifact is ' + M.OUTER).encode(),
                        ('SHA256 digest of uploaded artifact is ' + '0'*64).encode(), 'LOG_ARTIFACT_DIGEST')

    def test_wrong_artifact_id_rejected(self):
        self.log_reject(b'successfully finalized. Artifact ID 12621038763',
                        b'successfully finalized. Artifact ID 123456789', 'LOG_ARTIFACT_IDENTITY')

    def test_wrong_run_artifact_name_rejected(self):
        self.log_reject(b'Artifact q3-reference-capture-40253690074-1 successfully finalized.',
                        b'Artifact q3-reference-capture-40253690075-1 successfully finalized.', 'LOG_ARTIFACT_IDENTITY')

    def test_wrong_attempt_artifact_name_rejected(self):
        self.log_reject(b'Artifact q3-reference-capture-40253690074-1 successfully finalized.',
                        b'Artifact q3-reference-capture-40253690074-2 successfully finalized.', 'LOG_ARTIFACT_IDENTITY')

    def test_wrong_uploaded_size_rejected(self):
        self.log_reject(b'Uploaded bytes 5897022', b'Uploaded bytes 5897023', 'LOG_ARTIFACT_SIZE')

    def test_duplicate_json_key_rejected(self):
        with self.assertRaisesRegex(M.ReviewError, 'DUPLICATE_JSON_KEY'):
            M.strict_json(b'{"ok":false,"ok":true}')

    def test_nonfinite_json_rejected(self):
        with self.assertRaisesRegex(M.ReviewError, 'NONFINITE_JSON'):
            M.strict_json(b'{"v":NaN}')

    def test_zip_traversal_rejected(self):
        raw = io.BytesIO()
        with zipfile.ZipFile(raw, 'w') as z:
            z.writestr('../bad', b'x')
        with self.assertRaisesRegex(M.ReviewError, 'ZIP_PATH'):
            M.zip_members(raw.getvalue())

    def test_duplicate_zip_member_rejected(self):
        raw = io.BytesIO()
        with warnings.catch_warnings():
            warnings.simplefilter('ignore')
            with zipfile.ZipFile(raw, 'w') as z:
                z.writestr('same', b'x'); z.writestr('same', b'y')
        with self.assertRaisesRegex(M.ReviewError, 'ZIP_DUPLICATE'):
            M.zip_members(raw.getvalue())

    def test_zip_symlink_rejected(self):
        raw = io.BytesIO(); entry = zipfile.ZipInfo('link')
        entry.create_system = 3; entry.external_attr = (stat.S_IFLNK | 0o777) << 16
        with zipfile.ZipFile(raw, 'w') as z:
            z.writestr(entry, b'elsewhere')
        with self.assertRaisesRegex(M.ReviewError, 'ZIP_TYPE'):
            M.zip_members(raw.getvalue())

    def test_historical_source_mutation_rejected(self):
        snapshot = copy.deepcopy(SNAPSHOT)
        snapshot['files'][M.WORKFLOW]['content'] += '# changed\n'
        with self.assertRaisesRegex(M.ReviewError, 'HISTORICAL_BLOB'):
            M.verify_sources(snapshot, DELTA, CURRENT_WORKFLOW)

    def test_current_workflow_mutation_rejected(self):
        with self.assertRaisesRegex(M.ReviewError, 'DELTA_CURRENT_BINDING'):
            M.verify_sources(SNAPSHOT, DELTA, CURRENT_WORKFLOW + b'# changed\n')

    def test_missing_source_path_rejected(self):
        delta = copy.deepcopy(DELTA); delta['rows'].pop()
        with self.assertRaisesRegex(M.ReviewError, 'SOURCE_CLOSURE'):
            M.verify_sources(SNAPSHOT, delta, CURRENT_WORKFLOW)

    def test_false_source_equality_rejected(self):
        delta = copy.deepcopy(DELTA); delta['rows'][0]['byte_identity_by_git_blob'] = True
        with self.assertRaisesRegex(M.ReviewError, 'DELTA_EQUALITY'):
            M.verify_sources(SNAPSHOT, delta, CURRENT_WORKFLOW)

    def test_changed_comparison_commit_rejected(self):
        delta = copy.deepcopy(DELTA); delta['reviewed_main_commit'] = '0' * 40
        with self.assertRaisesRegex(M.ReviewError, 'SOURCE_COMMITS'):
            M.verify_sources(SNAPSHOT, delta, CURRENT_WORKFLOW)

    def test_manifest_detects_missing_extra_and_modified(self):
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            (root/'a').write_bytes(b'a')
            (root/'SHA256SUMS.txt').write_text(M.digest(b'a')+'  a\n')
            M.verify_file_manifest(root)
            (root/'a').write_bytes(b'changed')
            with self.assertRaisesRegex(M.ReviewError, 'PACKAGE_MANIFEST'):
                M.verify_file_manifest(root)
            (root/'a').unlink()
            with self.assertRaisesRegex(M.ReviewError, 'PACKAGE_MANIFEST'):
                M.verify_file_manifest(root)
            (root/'a').write_bytes(b'a'); (root/'extra').write_bytes(b'x')
            with self.assertRaisesRegex(M.ReviewError, 'PACKAGE_MANIFEST'):
                M.verify_file_manifest(root)

    def test_nested_manifest_is_not_ignored(self):
        with tempfile.TemporaryDirectory() as folder:
            root=Path(folder);(root/'nested').mkdir()
            (root/'SHA256SUMS.txt').write_text('')
            (root/'nested/SHA256SUMS.txt').write_text('unlisted')
            with self.assertRaisesRegex(M.ReviewError, 'PACKAGE_MANIFEST'):
                M.verify_file_manifest(root)

if __name__ == '__main__':
    unittest.main()
