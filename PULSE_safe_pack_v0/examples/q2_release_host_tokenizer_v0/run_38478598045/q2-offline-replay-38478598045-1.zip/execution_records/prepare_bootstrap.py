from pathlib import Path, PurePosixPath
import hashlib, json, os, shutil, subprocess, sys, tarfile, time
BASE=Path('/workspace/scratch/418db56a1289/q2_offline_replay')
REPO=Path('/workspace/scratch/418db56a1289/q2_source_d44bf963')
p=json.loads((REPO/'PULSE_safe_pack_v0/profiles/q2_release_host_tokenizer_verification_v0.json').read_bytes())
archive=BASE/'inputs/bootstrap.tar.gz'
assert archive.stat().st_size==p['bootstrap']['archive_size_bytes']
assert hashlib.file_digest(archive.open('rb'),'sha256').hexdigest()==p['bootstrap']['archive_sha256']
prefix=Path(p['bootstrap_prefix'])
assert not prefix.exists() and not prefix.is_symlink(), 'Refuse to overwrite an existing bootstrap'
for parent in prefix.parents:
    assert not parent.is_symlink(), 'Unexpected linked prefix ancestor'
with tarfile.open(archive,'r:gz') as a:
    items=a.getmembers()
    assert len(items)==10545 and sum(i.size for i in items)==305323346
    seen=set()
    for i in items:
        name=i.name.removeprefix('./')
        if name=='.':
            assert i.isdir(); continue
        path=PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts and name not in seen
        seen.add(name)
        assert i.isreg() or i.isdir() or i.issym()
        if i.issym():
            target=path.parent/PurePosixPath(i.linkname)
            assert not PurePosixPath(i.linkname).is_absolute() and '..' not in target.parts
    prefix.mkdir(parents=True)
    a.extractall(prefix,filter='data')
binary=prefix/'bin/python3.11'
assert hashlib.file_digest(binary.open('rb'),'sha256').hexdigest()==p['bootstrap_python_sha256']
log=BASE/'delivery/logs'
log.mkdir(exist_ok=True)
cmd=[str(binary),'-I','-B','-c','import sys, platform, unicodedata, json; print(json.dumps({"python":platform.python_version(),"prefix":sys.prefix,"base_prefix":sys.base_prefix,"unicode":unicodedata.unidata_version,"executable":sys.executable}))']
r=subprocess.run(cmd,capture_output=True)
(log/'bootstrap_probe.stdout').write_bytes(r.stdout)
(log/'bootstrap_probe.stderr').write_bytes(r.stderr)
(log/'bootstrap_probe.command.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode},indent=2)+'\n')
print('bootstrap_probe exit:',r.returncode,flush=True)
print(r.stdout.decode(),end='')
print(r.stderr.decode(),end='')
assert r.returncode==0,'Original bootstrap cannot launch unchanged'
info=json.loads(r.stdout)
assert info['python']=='3.11.16' and info['base_prefix']==str(prefix) and info['unicode']=='14.0.0'
cmd=[str(binary),'-I','-B','-m','venv','--copies','--without-pip',str(BASE/'verifier')]
r=subprocess.run(cmd,capture_output=True)
(log/'venv_creation.stdout').write_bytes(r.stdout)
(log/'venv_creation.stderr').write_bytes(r.stderr)
(log/'venv_creation.command.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode},indent=2)+'\n')
print('venv_creation exit:',r.returncode,flush=True)
print(r.stderr.decode(),end='')
assert r.returncode==0
print('Original bootstrap installed without setup.sh, binary changes or RUNPATH changes.',flush=True)

