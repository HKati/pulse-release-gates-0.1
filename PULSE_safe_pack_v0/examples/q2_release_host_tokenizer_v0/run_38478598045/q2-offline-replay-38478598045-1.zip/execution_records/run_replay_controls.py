from pathlib import Path
from datetime import datetime, timezone
import hashlib, json, os, shutil, subprocess, time
BASE=Path('/workspace/scratch/418db56a1289/q2_offline_replay')
REPO=Path('/workspace/scratch/418db56a1289/q2_source_d44bf963')
EVIDENCE=BASE/'delivery/evidence'
LOGS=BASE/'delivery/logs'
PIN='d44bf963cbac377366e95ae7ac9e3603fff894a4'
assert json.loads((BASE/'delivery/environment_inventory.json').read_text())['status']=='PASS'
before={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in EVIDENCE.iterdir()}
records=[]
def run(name,evidence,mutation=None):
    cmd=[str(BASE/'verifier/bin/python'),'-I','-B',
         'PULSE_safe_pack_v0/tools/check_q2_release_host_tokenizer_v0.py',
         'replay','--repo-root',str(REPO),'--evidence',str(evidence),'--inputs',str(BASE/'inputs')]
    out=LOGS/(name+'.stdout'); err=LOGS/(name+'.stderr')
    started=datetime.now(timezone.utc).isoformat(); tick=time.monotonic()
    with out.open('xb') as stdout,err.open('xb') as stderr:
        result=subprocess.run(cmd,cwd=REPO,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,timeout=1900)
    record={'name':name,'argv':cmd,'cwd':str(REPO),'started_at_utc':started,
            'completed_at_utc':datetime.now(timezone.utc).isoformat(),
            'duration_seconds':time.monotonic()-tick,'exit_code':result.returncode,
            'stdout_file':out.name,'stderr_file':err.name,
            'stdout_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
            'stderr_sha256':hashlib.sha256(err.read_bytes()).hexdigest(),
            'stdout_text':out.read_text(),'stderr_text':err.read_text(),'mutation':mutation}
    (LOGS/(name+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
    records.append(record)
    (BASE/'delivery/replay_results.json').write_text(json.dumps(records,indent=2)+'\n')
    print(name+': exit='+str(result.returncode)+' stdout='+repr(record['stdout_text'])+' stderr='+repr(record['stderr_text']),flush=True)
    return record
positive=run('positive',EVIDENCE)
assert positive['exit_code']==0 and positive['stdout_text']=='q2_tokenizer_evidence_reconstructed\n', 'Canonical replay did not succeed'
controls=BASE/'work/negative_controls'
controls.mkdir()
def copy(name):
    target=controls/name
    shutil.copytree(EVIDENCE,target)
    return target
changed=copy('changed_request_source')
path=changed/'request.json'; raw=path.read_bytes()
old=('"source_commit":"'+PIN+'"').encode()
new=b'"source_commit":"0000000000000000000000000000000000000000"'
assert raw.count(old)==1
path.write_bytes(raw.replace(old,new))
assert run('negative_changed_request_source',changed,{'file':'request.json','field':'source_commit','new_value':'0'*40,'bound_digest_recomputed':False})['exit_code']!=0
changed=copy('production_claim_true')
path=changed/'result.json'; raw=path.read_bytes()
old=b'"production_gate_eligible":false'
assert raw.count(old)==1
path.write_bytes(raw.replace(old,b'"production_gate_eligible":true'))
assert run('negative_production_claim_true',changed,{'file':'result.json','field':'claims.production_gate_eligible','old_value':False,'new_value':True})['exit_code']!=0
changed=copy('extra_evidence_file')
(changed/'undeclared.txt').write_bytes(b'negative control: undeclared evidence file\n')
assert run('negative_extra_evidence_file',changed,{'added_file':'undeclared.txt'})['exit_code']!=0
assert {p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in EVIDENCE.iterdir()}==before
(BASE/'delivery/negative_control_mutations.json').write_text(json.dumps([
    {'name':r['name'],'mutation':r['mutation'],'exit_code':r['exit_code']}
    for r in records if r['mutation']],indent=2)+'\n')
print('Canonical positive replay and all three negative controls: PASS. Original evidence unchanged.',flush=True)

