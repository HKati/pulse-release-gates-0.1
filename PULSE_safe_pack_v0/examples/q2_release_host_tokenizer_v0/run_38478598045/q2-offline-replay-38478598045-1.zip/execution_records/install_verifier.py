from pathlib import Path
import hashlib, json, os, subprocess, zipfile
BASE=Path('/workspace/scratch/418db56a1289/q2_offline_replay')
REPO=Path('/workspace/scratch/418db56a1289/q2_source_d44bf963')
p=json.loads((REPO/'PULSE_safe_pack_v0/profiles/q2_release_host_tokenizer_verification_v0.json').read_bytes())
pub=json.loads((REPO/p['publication_profile']).read_bytes())
wheelhouse=BASE/'work/preserved_wheels'
wheelhouse.mkdir()
bindings=[]
with zipfile.ZipFile(BASE/'inputs/preparation.zip') as z:
    infos=z.infolist()
    assert len(infos)==pub['limits']['preparation_members']
    assert sum(i.file_size for i in infos)==pub['limits']['preparation_expanded_bytes']
    assert len({i.filename for i in infos})==len(infos)
    for row in p['verifier_wheels']:
        name='q2-runtime-preparation/'+row['path']
        data=z.read(name)
        assert len(data)==row['size'] and hashlib.sha256(data).hexdigest()==row['sha256']
        dest=wheelhouse/Path(row['path']).name
        with dest.open('xb') as f: f.write(data)
        bindings.append({**row,'extracted_from':name,'extracted_wheel_path':str(dest)})
requirements=BASE/'work/verifier_requirements.txt'
requirements.write_text(''.join(r['name']+'=='+r['version']+' --hash=sha256:'+r['sha256']+'\n' for r in p['verifier_wheels']))
(BASE/'work/wheel_bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
pipwheel=BASE/'work'/pub['pip']['filename']
assert pipwheel.stat().st_size==pub['pip']['archive_size_bytes']
assert hashlib.file_digest(pipwheel.open('rb'),'sha256').hexdigest()==pub['pip']['archive_sha256']
script='import runpy,sys; sys.path.insert(0, sys.argv.pop(1)); runpy.run_module("pip",run_name="__main__")'
cmd=[str(BASE/'verifier/bin/python'),'-I','-B','-c',script,str(pipwheel),'--isolated','install',
     '--no-index','--no-deps','--require-hashes','--no-compile','--no-cache-dir','--disable-pip-version-check',
     '--only-binary=:all:','--find-links',str(wheelhouse),'-r',str(requirements),
     '--report',str(BASE/'delivery/logs/pip_install_report.json')]
r=subprocess.run(cmd,capture_output=True)
logs=BASE/'delivery/logs'
(logs/'wheel_install.stdout').write_bytes(r.stdout)
(logs/'wheel_install.stderr').write_bytes(r.stderr)
(logs/'wheel_install.command.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode},indent=2)+'\n')
print(r.stdout.decode(),end='')
print(r.stderr.decode(),end='')
print('wheel_install exit:',r.returncode)
raise SystemExit(r.returncode)

