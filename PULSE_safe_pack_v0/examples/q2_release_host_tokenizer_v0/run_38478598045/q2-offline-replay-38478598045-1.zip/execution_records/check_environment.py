from pathlib import Path
import hashlib, importlib, importlib.metadata, json, os, platform, site, sys, unicodedata
BASE=Path('/workspace/scratch/418db56a1289/q2_offline_replay')
REPO=Path('/workspace/scratch/418db56a1289/q2_source_d44bf963')
p=json.loads((REPO/'PULSE_safe_pack_v0/profiles/q2_release_host_tokenizer_verification_v0.json').read_bytes())
prefix=BASE/'verifier'
assert sys.prefix==str(prefix) and sys.base_prefix==p['bootstrap_prefix']
assert platform.python_version()=='3.11.16' and unicodedata.unidata_version=='14.0.0'
assert sys.flags.isolated and sys.dont_write_bytecode and not site.ENABLE_USER_SITE
cfg=(prefix/'pyvenv.cfg').read_text()
assert 'include-system-site-packages = false' in cfg and 'home = '+p['bootstrap_home'] in cfg
sys.path.insert(0,str(REPO/'PULSE_safe_pack_v0/tools'))
c=importlib.import_module('check_q2_release_host_tokenizer_v0')
assert Path(c.__file__).resolve()==REPO/'PULSE_safe_pack_v0/tools/check_q2_release_host_tokenizer_v0.py'
verifier_site=c.verifier_dependencies(prefix,p)
base_digest=c.verify_bootstrap(BASE/'inputs/bootstrap.tar.gz',p,c.Budget(180))
pre=json.loads((BASE/'delivery/evidence/prelaunch.json').read_bytes())
assert base_digest==pre['bootstrap_lib_sha256']
modules={}
for name in c.VERIFIER_MODULES:
    m=importlib.import_module(name)
    origin=Path(m.__file__).resolve()
    assert origin.is_relative_to(verifier_site)
    modules[name]=str(origin)
inventory=[]
for path in sorted(prefix.rglob('*')):
    if path.is_symlink():
        inventory.append({'path':path.relative_to(prefix).as_posix(),'kind':'symlink','target':os.readlink(path)})
    elif path.is_file():
        raw=path.read_bytes()
        inventory.append({'path':path.relative_to(prefix).as_posix(),'kind':'file','size_bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'mode':path.stat().st_mode&0o777})
        if path.relative_to(prefix).as_posix() in p['verifier_interpreter_entries']:
            assert hashlib.sha256(raw).hexdigest()==p['bootstrap_python_sha256']
source=c.source_closure(REPO,'d44bf963cbac377366e95ae7ac9e3603fff894a4',c.Budget(180))
assert source==pre['source_bindings']
record={'record_type':'q2_offline_replay_environment_inventory_v0','status':'PASS',
 'implementation':platform.python_implementation(),'python_version':platform.python_version(),
 'unicode_version':unicodedata.unidata_version,'platform':platform.platform(),
 'sys_prefix':sys.prefix,'sys_base_prefix':sys.base_prefix,'sys_executable':sys.executable,
 'isolated':bool(sys.flags.isolated),'dont_write_bytecode':sys.dont_write_bytecode,
 'enable_user_site':site.ENABLE_USER_SITE,'pyvenv_cfg':cfg,
 'bootstrap_archive':p['bootstrap'],'bootstrap_interpreter_sha256':p['bootstrap_python_sha256'],
 'bootstrap_lib_sha256':base_digest,'recorded_bootstrap_lib_match':True,
 'distributions':sorted([{'name':d.metadata['Name'],'version':d.version} for d in importlib.metadata.distributions(path=[str(verifier_site)])],key=lambda d:d['name']),
 'module_origins':modules,'verifier_files':inventory,'source_bindings':source,
 'native_execution':False,'tokenizer_reexecution':False,'model_weights_loaded':False}
(BASE/'delivery/environment_inventory.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:record[k] for k in ('status','python_version','unicode_version','sys_prefix','sys_base_prefix','bootstrap_interpreter_sha256','bootstrap_lib_sha256','distributions')},indent=2))

